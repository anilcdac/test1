/*    */ package com.appiancorp.ps.automatedtest.tempo.report;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.TimeoutException;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoReport extends AppianObject
/*    */   implements Clickable
/*    */ {
/* 17 */   private static final Logger LOG = Logger.getLogger(TempoReport.class);
/* 18 */   private static final String XPATH_ABSOLUTE_REPORT_LINK = Settings.getByConstant("xpathAbsoluteReportLink");
/* 19 */   private static final String XPATH_ABSOLUTE_REPORT_LINK_INDEX = "(" + XPATH_ABSOLUTE_REPORT_LINK + ")[%2$d]";
/*    */ 
/*    */   public static TempoReport getInstance(Settings settings) {
/* 22 */     return new TempoReport(settings);
/*    */   }
/*    */ 
/*    */   private TempoReport(Settings settings) {
/* 26 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 31 */     String report = getParam(0, params);
/*    */ 
/* 33 */     if (isFieldIndex(report)) {
/* 34 */       int rNum = getIndexFromFieldIndex(report);
/* 35 */       String rName = getFieldFromFieldIndex(report);
/* 36 */       return xpathFormat(XPATH_ABSOLUTE_REPORT_LINK_INDEX, new Object[] { rName, Integer.valueOf(rNum) });
/*    */     }
/* 38 */     return xpathFormat(XPATH_ABSOLUTE_REPORT_LINK, new Object[] { report });
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 44 */     String reportName = getParam(0, params);
/*    */ 
/* 46 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK REPORT [" + reportName + "]");
/*    */     try
/*    */     {
/* 49 */       WebElement report = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 50 */       clickElement(report);
/*    */     } catch (Exception e) {
/* 52 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Report", reportName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 59 */     String reportName = getParam(0, params);
/*    */ 
/* 61 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR [" + reportName + "]");
/*    */     try
/*    */     {
/* 64 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/* 65 */         .until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getXpath(params))));
/*    */     }
/*    */     catch (Exception e) {
/* 67 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Report", reportName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(int timeout, String[] params) {
/* 72 */     String reportName = getParam(0, params);
/*    */ 
/* 74 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR [" + reportName + "]");
/*    */     try
/*    */     {
/* 77 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getXpath(params))));
/* 78 */       return true;
/*    */     } catch (TimeoutException e) {
/* 80 */       return false;
/*    */     } catch (Exception e) {
/* 82 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Report", reportName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(String[] params) {
/* 87 */     return waitForReturn(this.settings.getTimeoutSeconds(), params);
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.report.TempoReport
 * JD-Core Version:    0.6.2
 */