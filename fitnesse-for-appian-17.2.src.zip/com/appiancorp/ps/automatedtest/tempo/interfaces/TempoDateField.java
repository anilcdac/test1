/*     */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.CrossPlatformUtilities;
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.lang3.time.DateUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.Keys;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoDateField extends AbstractTempoField
/*     */ {
/*  20 */   private static final Logger LOG = Logger.getLogger(TempoDateField.class);
/*     */ 
/*  22 */   private static final String XPATH_RELATIVE_DATE_FIELD_PLACEHOLDER = Settings.getByConstant("xpathRelativeDateFieldPlaceholder");
/*  23 */   private static final String XPATH_RELATIVE_DATE_FIELD_INPUT = Settings.getByConstant("xpathRelativeDateFieldInput");
/*     */ 
/*     */   public static TempoDateField getInstance(Settings settings) {
/*  26 */     return new TempoDateField(settings);
/*     */   }
/*     */ 
/*     */   private TempoDateField(Settings settings) {
/*  30 */     super(settings);
/*     */   }
/*     */ 
/*     */   public void populate(WebElement fieldLayout, String[] params)
/*     */     throws ParseException
/*     */   {
/*  48 */     String fieldValue = getParam(1, params);
/*     */ 
/*  50 */     if (LOG.isDebugEnabled()) LOG.debug("POPULATION [" + fieldValue + "]");
/*     */ 
/*  52 */     Date d = parseDate(fieldValue);
/*     */ 
/*  54 */     populateTempoDateFieldWithDate(fieldLayout, d);
/*     */   }
/*     */ 
/*     */   public String capture(WebElement fieldLayout, String[] params)
/*     */   {
/*  59 */     String value = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_DATE_FIELD_INPUT)).getAttribute("value");
/*     */ 
/*  61 */     if (LOG.isDebugEnabled()) LOG.debug("GET VALUE [" + value + "]");
/*     */ 
/*  63 */     return value;
/*     */   }
/*     */ 
/*     */   public boolean contains(WebElement fieldLayout, String[] params) throws ParseException
/*     */   {
/*  68 */     String fieldValue = getParam(0, params);
/*     */ 
/*  70 */     String dateString = capture(fieldLayout, new String[0]);
/*     */ 
/*  72 */     Date compareDate = parseDate(dateString);
/*  73 */     Date fieldDate = parseDate(fieldValue);
/*  74 */     if (LOG.isDebugEnabled()) {
/*  75 */       LOG.debug("DATE FIELD COMPARISON : Field value [" + compareDate.toString() + "] compared to Entered value [" + fieldDate.toString() + "]");
/*     */     }
/*     */ 
/*  78 */     return DateUtils.isSameDay(compareDate, fieldDate);
/*     */   }
/*     */ 
/*     */   private void populateTempoDateFieldWithDate(WebElement fieldLayout, Date d) {
/*  82 */     String dateValue = new SimpleDateFormat(this.settings.getDateFormat()).format(d);
/*     */ 
/*  84 */     WebElement datePlaceholder = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_DATE_FIELD_PLACEHOLDER));
/*  85 */     WebElement dateField = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_DATE_FIELD_INPUT));
/*     */ 
/*  88 */     if (dateField.isDisplayed()) {
/*  89 */       dateField.click();
/*  90 */       CrossPlatformUtilities.selectAll(dateField);
/*  91 */       dateField.sendKeys(new CharSequence[] { Keys.DELETE });
/*  92 */       dateField.sendKeys(new CharSequence[] { dateValue });
/*     */     } else {
/*  94 */       datePlaceholder.click();
/*  95 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOf(dateField));
/*  96 */       dateField.sendKeys(new CharSequence[] { dateValue });
/*     */     }
/*     */ 
/*  99 */     dateField.sendKeys(new CharSequence[] { Keys.ENTER });
/* 100 */     dateField.sendKeys(new CharSequence[] { Keys.ESCAPE });
/*     */   }
/*     */ 
/*     */   public void clear(WebElement fieldLayout, String[] params)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static boolean isType(WebElement fieldLayout)
/*     */   {
/*     */     try {
/* 110 */       fieldLayout.findElement(By.xpath(XPATH_RELATIVE_DATE_FIELD_INPUT));
/*     */     } catch (Exception e) {
/* 112 */       return false;
/*     */     }
/*     */ 
/* 115 */     return true;
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoDateField
 * JD-Core Version:    0.6.2
 */