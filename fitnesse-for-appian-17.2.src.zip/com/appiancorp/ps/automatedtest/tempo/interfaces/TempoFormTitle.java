/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Captureable;
/*    */ import com.appiancorp.ps.automatedtest.properties.RegexCaptureable;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitFor;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoFormTitle extends AppianObject
/*    */   implements WaitFor, Captureable, RegexCaptureable
/*    */ {
/* 18 */   private static final Logger LOG = Logger.getLogger(TempoFormTitle.class);
/* 19 */   private static final String XPATH_ABSOLUTE_FORM_TITLE = Settings.getByConstant("xpathAbsoluteFormTitle");
/*    */ 
/*    */   public static TempoFormTitle getInstance(Settings settings) {
/* 22 */     return new TempoFormTitle(settings);
/*    */   }
/*    */ 
/*    */   private TempoFormTitle(Settings settings) {
/* 26 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 31 */     return XPATH_ABSOLUTE_FORM_TITLE;
/*    */   }
/*    */ 
/*    */   public String capture(String[] params) {
/* 35 */     if (LOG.isDebugEnabled()) LOG.debug("GET FORM TITLE");
/*    */     try
/*    */     {
/* 38 */       WebElement element = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 39 */       return element.getText();
/*    */     } catch (Exception e) {
/* 41 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Get Form Title" });
/*    */     }
/*    */   }
/*    */ 
/*    */   public String regexCapture(String regex, Integer group, String[] params) {
/* 46 */     if (LOG.isDebugEnabled()) LOG.debug("REGEX FOR FORM TITLE [" + regex + "]");
/*    */     try
/*    */     {
/* 49 */       String text = this.settings.getDriver().findElement(By.xpath(getXpath(params))).getText();
/* 50 */       if (LOG.isDebugEnabled()) LOG.debug("TITLE VALUE [" + text + "]");
/* 51 */       return getRegexResults(regex, group, text);
/*    */     } catch (Exception e) {
/* 53 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Title regex", regex });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params) {
/* 58 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR FORM TITLE");
/*    */     try
/*    */     {
/* 61 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 63 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Title" });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoFormTitle
 * JD-Core Version:    0.6.2
 */