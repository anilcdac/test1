/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.properties.Container;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitFor;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoGrid extends AppianObject
/*    */   implements WaitFor, Container
/*    */ {
/* 18 */   private static final Logger LOG = Logger.getLogger(TempoGrid.class);
/* 19 */   protected static final String XPATH_ABSOLUTE_GRID_BY_INDEX = Settings.getByConstant("xpathAbsoluteGridByIndex");
/* 20 */   protected static final String XPATH_ABSOLUTE_GRID_BY_LABEL = Settings.getByConstant("xpathAbsoluteGridByLabel");
/* 21 */   protected static final String XPATH_ABSOLUTE_GRID_BY_LABEL_INDEX = "(" + XPATH_ABSOLUTE_GRID_BY_LABEL + ")[%2$d]";
/*    */ 
/*    */   public static TempoGrid getInstance(Settings settings) {
/* 24 */     return new TempoGrid(settings);
/*    */   }
/*    */ 
/*    */   protected TempoGrid(Settings settings) {
/* 28 */     super(settings);
/*    */   }
/*    */ 
/*    */   public WebElement getWebElement(String[] params)
/*    */   {
/* 33 */     return this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 38 */     String gridName = getParam(0, params);
/*    */ 
/* 40 */     WebElement grid = null;
/* 41 */     if (isFieldIndex(gridName)) {
/* 42 */       int gNum = getIndexFromFieldIndex(gridName);
/* 43 */       String gName = getFieldFromFieldIndex(gridName);
/* 44 */       if (StringUtils.isBlank(gName))
/* 45 */         grid = this.settings.getDriver().findElement(By.xpath(xpathFormat(XPATH_ABSOLUTE_GRID_BY_INDEX, new Object[] { Integer.valueOf(gNum) })));
/*    */       else
/* 47 */         grid = this.settings.getDriver().findElement(By.xpath(xpathFormat(XPATH_ABSOLUTE_GRID_BY_LABEL_INDEX, new Object[] { gName, Integer.valueOf(gNum) })));
/*    */     }
/*    */     else {
/* 50 */       grid = this.settings.getDriver().findElement(By.xpath(xpathFormat(XPATH_ABSOLUTE_GRID_BY_LABEL, new Object[] { gridName })));
/*    */     }
/*    */ 
/* 53 */     scrollIntoView(grid);
/* 54 */     return getXpathLocator(grid);
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 59 */     new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGrid
 * JD-Core Version:    0.6.2
 */