/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.properties.Captureable;
/*    */ import com.appiancorp.ps.automatedtest.properties.Verifiable;
/*    */ import com.google.common.base.Strings;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ 
/*    */ public class TempoLinkFieldUrl extends TempoLinkField
/*    */   implements Verifiable, Captureable
/*    */ {
/* 14 */   private static final Logger LOG = Logger.getLogger(TempoLinkFieldUrl.class);
/*    */ 
/*    */   public static TempoLinkFieldUrl getInstance(Settings settings) {
/* 17 */     return new TempoLinkFieldUrl(settings);
/*    */   }
/*    */ 
/*    */   private TempoLinkFieldUrl(Settings settings) {
/* 21 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String capture(String[] params)
/*    */   {
/* 26 */     String linkName = getParam(0, params);
/*    */ 
/* 28 */     WebElement link = this.settings.getDriver().findElement(By.xpath(getXpath(new String[] { linkName })));
/* 29 */     String linkURL = link.getAttribute("href");
/* 30 */     return linkURL;
/*    */   }
/*    */ 
/*    */   public boolean contains(String[] params)
/*    */   {
/* 35 */     String linkName = getParam(0, params);
/* 36 */     String linkURLValue = getParam(1, params);
/*    */ 
/* 38 */     String linkURLText = capture(new String[] { linkName });
/*    */ 
/* 40 */     if (LOG.isDebugEnabled()) {
/* 41 */       LOG.debug("READ ONLY FIELD COMPARISON : Link field URL value [" + linkURLText + "] compared to Entered value [" + linkURLValue + "]");
/*    */     }
/* 43 */     return (linkURLText.contains(linkURLValue)) && (!Strings.isNullOrEmpty(linkURLValue));
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoLinkFieldUrl
 * JD-Core Version:    0.6.2
 */