/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import com.appiancorp.ps.automatedtest.properties.Completeable;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitFor;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoSaveChanges extends AppianObject
/*    */   implements WaitFor, Clickable, Completeable
/*    */ {
/* 18 */   private static final Logger LOG = Logger.getLogger(TempoSaveChanges.class);
/* 19 */   private static final String XPATH_ABSOLUTE_SAVE_CHANGES = Settings.getByConstant("xpathAbsoluteSaveChanges");
/* 20 */   private static final String XPATH_ABSOLUTE_FORM_SAVED_CONFIRMATION = Settings.getByConstant("xpathAbsoluteFormSavedConfirmation");
/*    */ 
/*    */   public static TempoSaveChanges getInstance(Settings settings) {
/* 23 */     return new TempoSaveChanges(settings);
/*    */   }
/*    */ 
/*    */   private TempoSaveChanges(Settings settings) {
/* 27 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 32 */     return XPATH_ABSOLUTE_SAVE_CHANGES;
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 37 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR SAVE CHANGES");
/*    */     try
/*    */     {
/* 40 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/* 41 */         .until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     }
/*    */     catch (Exception e) {
/* 43 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Save Changes" });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 49 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK SAVE CHANGES");
/*    */     try
/*    */     {
/* 52 */       WebElement saveChanges = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 53 */       clickElement(saveChanges);
/*    */     }
/*    */     catch (Exception e) {
/* 56 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Click Save Changes" });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean complete(String[] params)
/*    */   {
/*    */     try {
/* 63 */       new WebDriverWait(this.settings.getDriver(), this.settings.getNotPresentTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(
/* 64 */         By.xpath(XPATH_ABSOLUTE_FORM_SAVED_CONFIRMATION)));
/*    */     }
/*    */     catch (Exception e) {
/* 66 */       return false;
/*    */     }
/*    */ 
/* 69 */     return true;
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoSaveChanges
 * JD-Core Version:    0.6.2
 */