/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.properties.FieldLayoutCaptureable;
/*    */ import com.appiancorp.ps.automatedtest.properties.FieldLayoutVerifiable;
/*    */ import com.google.common.base.Strings;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebElement;
/*    */ 
/*    */ public class TempoReadOnlyField extends AbstractTempoField
/*    */   implements FieldLayoutVerifiable, FieldLayoutCaptureable
/*    */ {
/* 14 */   private static final Logger LOG = Logger.getLogger(TempoReadOnlyField.class);
/* 15 */   public static final String XPATH_RELATIVE_READ_ONLY_FIELD = Settings.getByConstant("xpathRelativeReadOnlyField");
/*    */ 
/*    */   public static TempoReadOnlyField getInstance(Settings settings) {
/* 18 */     return new TempoReadOnlyField(settings);
/*    */   }
/*    */ 
/*    */   private TempoReadOnlyField(Settings settings) {
/* 22 */     super(settings);
/*    */   }
/*    */ 
/*    */   public void populate(WebElement fieldLayout, String[] params) throws Exception
/*    */   {
/* 27 */     throw new IllegalArgumentException("Invalid for a READONLY Field");
/*    */   }
/*    */ 
/*    */   public boolean contains(WebElement fieldLayout, String[] params)
/*    */   {
/* 32 */     String fieldValue = getParam(0, params);
/*    */ 
/* 34 */     String compareString = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_READ_ONLY_FIELD)).getText();
/*    */ 
/* 36 */     if (LOG.isDebugEnabled()) {
/* 37 */       LOG.debug("READ ONLY FIELD COMPARISON : Field value [" + fieldValue + "] compared to Entered value [" + compareString + "]");
/*    */     }
/*    */ 
/* 41 */     return ((compareString.contains(fieldValue)) && (!Strings.isNullOrEmpty(fieldValue))) || (
/* 42 */       (fieldValue
/* 42 */       .contains(compareString)) && 
/* 42 */       (!Strings.isNullOrEmpty(compareString)));
/*    */   }
/*    */ 
/*    */   public String capture(WebElement fieldLayout, String[] params)
/*    */   {
/* 47 */     String value = fieldLayout.findElement(By.xpath(xpathFormat(XPATH_RELATIVE_READ_ONLY_FIELD, new Object[0]))).getText();
/*    */ 
/* 49 */     if (LOG.isDebugEnabled()) LOG.debug("READ ONLY FIELD VALUE: " + value);
/*    */ 
/* 51 */     return value;
/*    */   }
/*    */ 
/*    */   public void clear(WebElement fieldLayout, String[] params)
/*    */   {
/* 56 */     throw new IllegalArgumentException("Invalid for a READONLY Field");
/*    */   }
/*    */ 
/*    */   public static boolean isType(WebElement fieldLayout) {
/*    */     try {
/* 61 */       fieldLayout.findElement(By.xpath(XPATH_RELATIVE_READ_ONLY_FIELD));
/*    */     } catch (Exception e) {
/* 63 */       return false;
/*    */     }
/*    */ 
/* 66 */     return true;
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoReadOnlyField
 * JD-Core Version:    0.6.2
 */