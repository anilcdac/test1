/*     */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoMilestoneField extends AbstractTempoField
/*     */ {
/*  15 */   private static final Logger LOG = Logger.getLogger(TempoMilestoneField.class);
/*  16 */   private static final String XPATH_ABSOLUTE_MILESTONE_FIELD_LABEL = Settings.getByConstant("xpathAbsoluteMilestoneFieldLabel");
/*  17 */   private static final String XPATH_ABSOLUTE_MILESTONE_FIELD_INDEX = Settings.getByConstant("xpathAbsoluteMilestoneFieldIndex");
/*  18 */   private static final String XPATH_ABSOLUTE_MILESTONE_FIELD_LABEL_INDEX = "(" + XPATH_ABSOLUTE_MILESTONE_FIELD_LABEL + ")[%2$d]";
/*  19 */   private static final String XPATH_RELATIVE_STEP = Settings.getByConstant("xpathRelativeMilestoneStepGeneral");
/*  20 */   private static final String XPATH_RELATIVE_STEP_SELECTED = Settings.getByConstant("xpathRelativeMilestoneStepSelected");
/*     */ 
/*     */   public static TempoMilestoneField getInstance(Settings settings) {
/*  23 */     return new TempoMilestoneField(settings);
/*     */   }
/*     */ 
/*     */   protected TempoMilestoneField(Settings settings) {
/*  27 */     super(settings);
/*     */   }
/*     */ 
/*     */   public String getXpath(String[] params)
/*     */   {
/*  32 */     String fieldName = getParam(0, params);
/*     */ 
/*  34 */     if (isFieldIndex(fieldName)) {
/*  35 */       int index = getIndexFromFieldIndex(fieldName);
/*  36 */       String name = getFieldFromFieldIndex(fieldName);
/*  37 */       if (StringUtils.isBlank(name)) {
/*  38 */         return xpathFormat(XPATH_ABSOLUTE_MILESTONE_FIELD_INDEX + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { Integer.valueOf(index) });
/*     */       }
/*  40 */       return xpathFormat(XPATH_ABSOLUTE_MILESTONE_FIELD_LABEL_INDEX + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { name, 
/*  41 */         Integer.valueOf(index) });
/*     */     }
/*     */ 
/*  45 */     return xpathFormat(XPATH_ABSOLUTE_MILESTONE_FIELD_LABEL + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { fieldName });
/*     */   }
/*     */ 
/*     */   public void waitFor(String[] params)
/*     */   {
/*  51 */     String fieldName = getParam(0, params);
/*     */ 
/*  53 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR MILESTONE [" + fieldName + "]");
/*     */     try
/*     */     {
/*  56 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*     */     } catch (Exception e) {
/*  58 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Milestone Field", fieldName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void populate(WebElement fieldLayout, String[] params)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public String capture(WebElement fieldLayout, String[] params)
/*     */   {
/*  69 */     WebElement selectedStep = fieldLayout.findElement(By.xpath(xpathFormat(XPATH_RELATIVE_STEP_SELECTED, new Object[0])));
/*  70 */     String currentStep = selectedStep.getText().replace("Current step: ", "");
/*  71 */     if (LOG.isDebugEnabled()) {
/*  72 */       LOG.debug("MILESTONE FIELD VALUE [" + currentStep + "]");
/*     */     }
/*  74 */     return currentStep;
/*     */   }
/*     */ 
/*     */   public boolean contains(WebElement fieldLayout, String[] params) throws Exception
/*     */   {
/*  79 */     String fieldValue = getParam(0, params);
/*     */ 
/*  81 */     WebElement selectedStep = fieldLayout.findElement(By.xpath(xpathFormat(XPATH_RELATIVE_STEP_SELECTED, new Object[0])));
/*  82 */     String compareString = selectedStep.getText().replace("Current step: ", "");
/*  83 */     if (LOG.isDebugEnabled()) {
/*  84 */       LOG.debug("MILESTONE FIELD COMPARISON : Step [" + fieldValue + "] compared to current step [" + compareString + "]");
/*     */     }
/*  86 */     return fieldValue.equals(compareString);
/*     */   }
/*     */ 
/*     */   public void clear(WebElement fieldLayout, String[] params)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static boolean isType(WebElement fieldLayout)
/*     */   {
/*     */     try {
/*  96 */       fieldLayout.findElement(By.xpath(XPATH_RELATIVE_STEP));
/*     */     } catch (Exception e) {
/*  98 */       return false;
/*     */     }
/*     */ 
/* 101 */     return true;
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoMilestoneField
 * JD-Core Version:    0.6.2
 */