/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Container;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitFor;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoSection extends AppianObject
/*    */   implements Container, WaitFor
/*    */ {
/* 27 */   private static final Logger LOG = Logger.getLogger(TempoSection.class);
/*    */ 
/* 29 */   protected static final String XPATH_ABSOLUTE_SECTION_LAYOUT = Settings.getByConstant("xpathAbsoluteSectionLayout");
/*    */ 
/*    */   public static TempoSection getInstance(Settings settings)
/*    */   {
/* 19 */     return new TempoSection(settings);
/*    */   }
/*    */ 
/*    */   protected TempoSection(Settings settings) {
/* 23 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 33 */     String sectionName = getParam(0, params);
/*    */ 
/* 35 */     return xpathFormat(XPATH_ABSOLUTE_SECTION_LAYOUT, new Object[] { sectionName });
/*    */   }
/*    */ 
/*    */   public WebElement getWebElement(String[] params)
/*    */   {
/* 40 */     return this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 45 */     if (params.length == 1) {
/* 46 */       String sectionName = getParam(0, params);
/*    */       try
/*    */       {
/* 49 */         new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */       } catch (Exception e) {
/* 51 */         throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Section", sectionName });
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoSection
 * JD-Core Version:    0.6.2
 */