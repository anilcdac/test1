/*     */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import com.appiancorp.ps.automatedtest.properties.Captureable;
/*     */ import com.appiancorp.ps.automatedtest.properties.Clearable;
/*     */ import com.appiancorp.ps.automatedtest.properties.FieldLayoutCaptureable;
/*     */ import com.appiancorp.ps.automatedtest.properties.FieldLayoutClearable;
/*     */ import com.appiancorp.ps.automatedtest.properties.FieldLayoutPopulateable;
/*     */ import com.appiancorp.ps.automatedtest.properties.FieldLayoutRegexCaptureable;
/*     */ import com.appiancorp.ps.automatedtest.properties.FieldLayoutVerifiable;
/*     */ import com.appiancorp.ps.automatedtest.properties.PopulateableMultiple;
/*     */ import com.appiancorp.ps.automatedtest.properties.RegexCaptureable;
/*     */ import com.appiancorp.ps.automatedtest.properties.VerifiableMultiple;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.WebElement;
/*     */ 
/*     */ public class TempoFieldFactory extends AppianObject
/*     */   implements FieldLayoutVerifiable, VerifiableMultiple, FieldLayoutClearable, Clearable, FieldLayoutPopulateable, PopulateableMultiple, FieldLayoutCaptureable, Captureable, FieldLayoutRegexCaptureable, RegexCaptureable
/*     */ {
/*  27 */   private static final Logger LOG = Logger.getLogger(TempoFieldFactory.class);
/*  28 */   public static final String XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT = Settings.getByConstant("xpathConcatAncestorFieldLayout");
/*     */ 
/*     */   public static TempoFieldFactory getInstance(Settings settings) {
/*  31 */     return new TempoFieldFactory(settings);
/*     */   }
/*     */ 
/*     */   protected TempoFieldFactory(Settings settings) {
/*  35 */     super(settings);
/*     */   }
/*     */ 
/*     */   public void populateMultiple(String[] fieldValues, String[] params)
/*     */   {
/*     */     String fieldValue;
/*     */     WebElement fieldLayout;
/*  39 */     if (params.length == 1) {
/*  40 */       String fieldName = getParam(0, params);
/*     */ 
/*  42 */       for (fieldValue : fieldValues) {
/*  43 */         fieldLayout = TempoField.getInstance(this.settings).getWebElement(params);
/*  44 */         populate(fieldLayout, new String[] { fieldName, fieldValue });
/*     */       }
/*     */     } else {
/*  47 */       String fieldType = getParam(0, params);
/*  48 */       String fieldName = getParam(1, params);
/*     */ 
/*  50 */       AbstractTempoField tempoField = getFieldTypeFromString(fieldType);
/*  51 */       String[] arrayOfString2 = fieldValues; fieldValue = arrayOfString2.length; for (fieldLayout = 0; fieldLayout < fieldValue; fieldLayout++) { String fieldValue = arrayOfString2[fieldLayout];
/*  52 */         WebElement fieldLayout = tempoField.getWebElement(new String[] { fieldName });
/*  53 */         populate(fieldLayout, new String[] { fieldName, fieldValue });
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void populate(WebElement fieldLayout, String[] params)
/*     */   {
/*  60 */     String fieldName = getParam(0, params);
/*  61 */     String fieldValue = getParam(1, params);
/*     */     try
/*     */     {
/*  64 */       AbstractTempoField tempoField = getFieldType(fieldLayout);
/*     */ 
/*  66 */       scrollIntoView(fieldLayout);
/*  67 */       tempoField.populate(fieldLayout, new String[] { fieldName, fieldValue });
/*  68 */       unfocus();
/*     */     } catch (Exception e) {
/*  70 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Populate Field", fieldName, fieldValue });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void waitFor(String[] params) {
/*  75 */     if (params.length == 1) {
/*  76 */       TempoField.getInstance(this.settings).waitFor(params);
/*     */     } else {
/*  78 */       String fieldType = getParam(0, params);
/*  79 */       String fieldName = getParam(1, params);
/*     */       try
/*     */       {
/*  82 */         AbstractTempoField tempoField = getFieldTypeFromString(fieldType);
/*     */ 
/*  84 */         tempoField.waitFor(new String[] { fieldName });
/*     */       } catch (Exception e) {
/*  86 */         throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Field Type", fieldType, fieldName });
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear(String[] params)
/*     */   {
/*  93 */     WebElement fieldLayout = TempoField.getInstance(this.settings).getWebElement(params);
/*  94 */     clear(fieldLayout, params);
/*     */   }
/*     */ 
/*     */   public void clear(WebElement fieldLayout, String[] params)
/*     */   {
/*  99 */     String fieldName = getParam(0, params);
/*     */     try
/*     */     {
/* 102 */       AbstractTempoField tempoField = getFieldType(fieldLayout);
/*     */ 
/* 104 */       scrollIntoView(fieldLayout);
/* 105 */       tempoField.clear(fieldLayout, new String[0]);
/* 106 */       unfocus();
/*     */     } catch (Exception e) {
/* 108 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Clear Field", fieldName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clearOf(String[] fieldValues, String[] params) {
/* 113 */     WebElement fieldLayout = TempoField.getInstance(this.settings).getWebElement(params);
/* 114 */     clearOf(fieldLayout, fieldValues);
/*     */   }
/*     */ 
/*     */   public void clearOf(WebElement fieldLayout, String[] fieldValues) {
/*     */     try {
/* 119 */       AbstractTempoField tempoField = getFieldType(fieldLayout);
/*     */ 
/* 121 */       if ((tempoField instanceof TempoPickerField)) {
/* 122 */         scrollIntoView(fieldLayout);
/* 123 */         ((TempoPickerField)tempoField).clearOf(fieldLayout, fieldValues);
/* 124 */         unfocus();
/*     */       } else {
/* 126 */         throw new IllegalArgumentException("A PICKER field is the only valid option for 'clear of'");
/*     */       }
/*     */     } catch (Exception e) {
/* 129 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Clear Field of" });
/*     */     }
/*     */   }
/*     */ 
/*     */   public String capture(String[] params)
/*     */   {
/* 135 */     WebElement fieldLayout = TempoField.getInstance(this.settings).getWebElement(params);
/*     */ 
/* 137 */     return capture(fieldLayout, params);
/*     */   }
/*     */ 
/*     */   public String capture(WebElement fieldLayout, String[] params)
/*     */   {
/* 142 */     String fieldName = getParam(0, params);
/*     */     try
/*     */     {
/* 145 */       AbstractTempoField tempoField = getFieldType(fieldLayout);
/* 146 */       return tempoField.capture(fieldLayout, new String[0]);
/*     */     }
/*     */     catch (Exception e) {
/* 149 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Get field value", fieldName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public String regexCapture(String regex, Integer group, String[] params)
/*     */   {
/* 155 */     WebElement fieldLayout = TempoField.getInstance(this.settings).getWebElement(params);
/*     */ 
/* 157 */     return regexCapture(fieldLayout, regex, group, params);
/*     */   }
/*     */ 
/*     */   public String regexCapture(WebElement fieldLayout, String regex, Integer group, String[] params)
/*     */   {
/* 162 */     if (LOG.isDebugEnabled()) LOG.debug("REGEX FOR FIELD VALUE [" + regex + "]");
/*     */     try
/*     */     {
/* 165 */       AbstractTempoField tempoField = getFieldType(fieldLayout);
/* 166 */       String text = tempoField.capture(fieldLayout, new String[0]);
/* 167 */       if (LOG.isDebugEnabled()) LOG.debug("FIELD VALUE [" + text + "]");
/* 168 */       return getRegexResults(regex, group, text);
/*     */     } catch (Exception e) {
/* 170 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Field value regex", regex });
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean containsMultiple(String[] fieldValues, String[] params)
/*     */   {
/* 176 */     String fieldName = getParam(0, params);
/*     */ 
/* 178 */     for (String fieldValue : fieldValues) {
/* 179 */       WebElement fieldLayout = TempoField.getInstance(this.settings).getWebElement(params);
/* 180 */       if (!contains(fieldLayout, new String[] { fieldName, fieldValue })) return false;
/*     */     }
/*     */ 
/* 183 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean contains(WebElement fieldLayout, String[] params)
/*     */   {
/* 188 */     String fieldName = getParam(0, params);
/* 189 */     String fieldValue = getParam(1, params);
/*     */     try
/*     */     {
/* 192 */       AbstractTempoField tempoField = getFieldType(fieldLayout);
/* 193 */       return tempoField.contains(fieldLayout, new String[] { fieldValue });
/*     */     } catch (Exception e) {
/* 195 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Field contains", fieldName, fieldValue });
/*     */     }
/*     */   }
/*     */ 
/*     */   public AbstractTempoField getFieldType(WebElement fieldLayout) {
/* 200 */     if (TempoReadOnlyField.isType(fieldLayout))
/* 201 */       return TempoReadOnlyField.getInstance(this.settings);
/* 202 */     if (TempoTextField.isType(fieldLayout))
/* 203 */       return TempoTextField.getInstance(this.settings);
/* 204 */     if (TempoParagraphField.isType(fieldLayout))
/* 205 */       return TempoParagraphField.getInstance(this.settings);
/* 206 */     if (TempoDropdownField.isType(fieldLayout))
/* 207 */       return TempoDropdownField.getInstance(this.settings);
/* 208 */     if (TempoRadioField.isType(fieldLayout))
/* 209 */       return TempoRadioField.getInstance(this.settings);
/* 210 */     if (TempoCheckboxField.isType(fieldLayout))
/* 211 */       return TempoCheckboxField.getInstance(this.settings);
/* 212 */     if (TempoFileUploadField.isType(fieldLayout)) {
/* 213 */       return TempoFileUploadField.getInstance(this.settings);
/*     */     }
/* 215 */     if (TempoDatetimeField.isType(fieldLayout))
/* 216 */       return TempoDatetimeField.getInstance(this.settings);
/* 217 */     if (TempoDateField.isType(fieldLayout))
/* 218 */       return TempoDateField.getInstance(this.settings);
/* 219 */     if (TempoImageField.isType(fieldLayout))
/* 220 */       return TempoImageField.getInstance(this.settings);
/* 221 */     if (TempoPickerField.isType(fieldLayout))
/* 222 */       return TempoPickerField.getInstance(this.settings);
/* 223 */     if (TempoMilestoneField.isType(fieldLayout))
/* 224 */       return TempoMilestoneField.getInstance(this.settings);
/* 225 */     throw new IllegalArgumentException("Unrecognized field type");
/*     */   }
/*     */ 
/*     */   public AbstractTempoField getFieldTypeFromString(String fieldType) {
/* 229 */     fieldType = fieldType.toUpperCase();
/* 230 */     if (fieldType.equals("TEXT"))
/* 231 */       return TempoTextField.getInstance(this.settings);
/* 232 */     if (fieldType.equals("PARAGRAPH"))
/* 233 */       return TempoParagraphField.getInstance(this.settings);
/* 234 */     if (fieldType.equals("FILE_UPLOAD"))
/* 235 */       return TempoFileUploadField.getInstance(this.settings);
/* 236 */     if (fieldType.equals("MILESTONE"))
/* 237 */       return TempoMilestoneField.getInstance(this.settings);
/* 238 */     throw new IllegalArgumentException("Unrecognized field type");
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoFieldFactory
 * JD-Core Version:    0.6.2
 */