/*     */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.WebDriver;
/*     */ import org.openqa.selenium.WebDriver.TargetLocator;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoPickerField extends AbstractTempoField
/*     */ {
/*  16 */   private static final Logger LOG = Logger.getLogger(TempoPickerField.class);
/*  17 */   protected static final String XPATH_ABSOLUTE_PICKER_LABEL = Settings.getByConstant("xpathAbsolutePickerLabel");
/*  18 */   protected static final String XPATH_RELATIVE_PICKER_INPUT = Settings.getByConstant("xpathRelativePickerInput");
/*  19 */   protected static final String XPATH_ABSOLUTE_PICKER_SUGGESTION = Settings.getByConstant("xpathAbsolutePickerSuggestion");
/*  20 */   protected static final String XPATH_RELATIVE_PICKER_SELECTION = Settings.getByConstant("xpathRelativePickerSelection");
/*  21 */   protected static final String XPATH_RELATIVE_PICKER_SPECIFIC_SELECTION = Settings.getByConstant("xpathRelativePickerSpecificSelection");
/*  22 */   protected static final String XPATH_RELATIVE_PICKER_SELECTION_REMOVE_LINK = Settings.getByConstant("xpathRelativePickerSelectionRemoveLink");
/*  23 */   protected static final String XPATH_RELATIVE_PICKER_SPECIFIC_SELECTION_REMOVE_LINK = Settings.getByConstant("xpathRelativePickerSpecificSelectionRemoveLink");
/*  24 */   protected static final String XPATH_RELATIVE_PICKER_SUGGEST_BOX = Settings.getByConstant("xpathRelativePickerSuggestBox");
/*  25 */   protected static final String XPATH_RELATIVE_INPUT_OR_SELECTION = "(" + XPATH_RELATIVE_PICKER_INPUT + " | " + XPATH_RELATIVE_PICKER_SELECTION + ")";
/*     */ 
/*     */   public static TempoPickerField getInstance(Settings settings)
/*     */   {
/*  29 */     return new TempoPickerField(settings);
/*     */   }
/*     */ 
/*     */   protected TempoPickerField(Settings settings) {
/*  33 */     super(settings);
/*     */   }
/*     */ 
/*     */   public void populate(WebElement fieldLayout, String[] params)
/*     */   {
/*  38 */     String fieldName = getParam(0, params);
/*  39 */     String fieldValue = getParam(1, params);
/*     */ 
/*  41 */     if (LOG.isDebugEnabled()) LOG.debug("POPULATION [" + fieldValue + "]");
/*     */ 
/*  45 */     this.settings.getDriver().switchTo().window("");
/*  46 */     waitForSuggestBox(fieldLayout, fieldName);
/*  47 */     WebElement groupPickerField = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_PICKER_INPUT));
/*  48 */     groupPickerField.click();
/*  49 */     groupPickerField.sendKeys(new CharSequence[] { fieldValue });
/*     */ 
/*  52 */     TempoPickerFieldSuggestion.getInstance(this.settings).waitFor(new String[] { fieldValue });
/*  53 */     WebElement suggestion = this.settings.getDriver().findElement(
/*  54 */       By.xpath(xpathFormat(XPATH_ABSOLUTE_PICKER_SUGGESTION, new Object[] { fieldValue, fieldValue })));
/*     */ 
/*  55 */     suggestion.click();
/*  56 */     TempoPickerFieldSelection.getInstance(this.settings).waitFor(fieldLayout, new String[] { fieldValue });
/*     */   }
/*     */ 
/*     */   public String capture(WebElement fieldLayout, String[] params)
/*     */   {
/*  61 */     List values = new ArrayList();
/*     */ 
/*  63 */     for (WebElement a : fieldLayout.findElements(By.xpath(XPATH_RELATIVE_PICKER_SELECTION))) {
/*  64 */       values.add(a.getText());
/*     */     }
/*     */ 
/*  67 */     if (LOG.isDebugEnabled()) LOG.debug("PICKER FIELD VALUE : " + values.toString());
/*     */ 
/*  69 */     return String.join(",", values);
/*     */   }
/*     */ 
/*     */   public boolean contains(WebElement fieldLayout, String[] params)
/*     */   {
/*  74 */     String fieldValue = getParam(0, params);
/*     */ 
/*  76 */     if (TempoPickerFieldSelection.getInstance(this.settings).waitForReturn(fieldLayout, new String[] { fieldValue })) {
/*  77 */       if (LOG.isDebugEnabled()) LOG.debug("USER PICKER FIELD COMPARISON : FIELD VALUE [" + fieldValue + "] FOUND");
/*  78 */       return true;
/*     */     }
/*  80 */     if (LOG.isDebugEnabled()) LOG.debug("USER PICKER FIELD COMPARISON : FIELD VALUE [" + fieldValue + "] NOT FOUND");
/*     */ 
/*  82 */     return false;
/*     */   }
/*     */ 
/*     */   public void clear(WebElement fieldLayout, String[] params)
/*     */   {
/*  88 */     List xs = fieldLayout.findElements(By.xpath(XPATH_RELATIVE_PICKER_SELECTION_REMOVE_LINK));
/*     */ 
/*  90 */     for (WebElement x : xs)
/*  91 */       x.click();
/*     */   }
/*     */ 
/*     */   public void clearOf(WebElement fieldLayout, String[] params)
/*     */   {
/*  96 */     if (LOG.isDebugEnabled()) LOG.debug("PICKER FIELD CLEAR OF : " + String.join(", ", params));
/*     */ 
/*  98 */     for (int i = 0; i < params.length; i++) {
/*  99 */       WebElement x = fieldLayout.findElement(By.xpath(xpathFormat(XPATH_RELATIVE_PICKER_SPECIFIC_SELECTION_REMOVE_LINK, new Object[] { params[i] })));
/* 100 */       x.click();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void waitForSuggestBox(WebElement fieldLayout, String fieldValue) {
/* 105 */     String xpathLocator = getXpathLocator(fieldLayout);
/* 106 */     new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(" + xpathLocator + ")" + 
/* 107 */       xpathFormat(XPATH_RELATIVE_PICKER_SUGGEST_BOX, new Object[] { fieldValue }))));
/*     */   }
/*     */ 
/*     */   public static boolean isType(WebElement fieldLayout)
/*     */   {
/*     */     try {
/* 112 */       fieldLayout.findElement(By.xpath(XPATH_RELATIVE_INPUT_OR_SELECTION));
/*     */     } catch (Exception e) {
/* 114 */       return false;
/*     */     }
/*     */ 
/* 117 */     return true;
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoPickerField
 * JD-Core Version:    0.6.2
 */