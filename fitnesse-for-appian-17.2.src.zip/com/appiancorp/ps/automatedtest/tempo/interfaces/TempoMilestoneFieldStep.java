/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebElement;
/*    */ 
/*    */ public class TempoMilestoneFieldStep extends TempoMilestoneField
/*    */   implements Clickable
/*    */ {
/* 13 */   private static final Logger LOG = Logger.getLogger(TempoMilestoneFieldStep.class);
/* 14 */   private static final String XPATH_RELATIVE_MILESTONE_STEP = Settings.getByConstant("xpathRelativeMilestoneStep");
/* 15 */   private static final String XPATH_RELATIVE_MILESTONE_STEP_INDEX = Settings.getByConstant("xpathRelativeMilestoneStepIndex");
/*    */ 
/*    */   public static TempoMilestoneFieldStep getInstance(Settings settings) {
/* 18 */     return new TempoMilestoneFieldStep(settings);
/*    */   }
/*    */ 
/*    */   private TempoMilestoneFieldStep(Settings settings) {
/* 22 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 27 */     String step = getParam(1, params);
/*    */ 
/* 29 */     if (isFieldIndex(step)) {
/* 30 */       int rNum = getIndexFromFieldIndex(step);
/* 31 */       return xpathFormat(XPATH_RELATIVE_MILESTONE_STEP_INDEX, new Object[] { Integer.valueOf(rNum) });
/*    */     }
/* 33 */     return xpathFormat(XPATH_RELATIVE_MILESTONE_STEP, new Object[] { step });
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 39 */     String milestone = getParam(0, params);
/* 40 */     String step = getParam(1, params);
/*    */ 
/* 42 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK ON MILESTONE [" + milestone + "] STEP [" + step + "]");
/*    */     try
/*    */     {
/* 45 */       TempoMilestoneField tm = TempoMilestoneField.getInstance(this.settings);
/* 46 */       WebElement milestoneField = tm.getWebElement(params);
/* 47 */       WebElement stepElement = milestoneField.findElement(By.xpath(getXpath(params)));
/* 48 */       clickElement(stepElement);
/*    */     } catch (Exception e) {
/* 50 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Click on Milestone Step", milestone, step });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoMilestoneFieldStep
 * JD-Core Version:    0.6.2
 */