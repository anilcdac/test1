/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitFor;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoPickerFieldSuggestion extends TempoPickerField
/*    */   implements WaitFor
/*    */ {
/* 14 */   private static final Logger LOG = Logger.getLogger(TempoPickerFieldSuggestion.class);
/* 15 */   protected static final String XPATH_ABSOLUTE_PICKER_SUGGESTION = Settings.getByConstant("xpathAbsolutePickerSuggestion");
/*    */ 
/*    */   public static TempoPickerFieldSuggestion getInstance(Settings settings) {
/* 18 */     return new TempoPickerFieldSuggestion(settings);
/*    */   }
/*    */ 
/*    */   private TempoPickerFieldSuggestion(Settings settings) {
/* 22 */     super(settings);
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 27 */     String fieldValue = getParam(0, params);
/*    */ 
/* 29 */     new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathFormat(XPATH_ABSOLUTE_PICKER_SUGGESTION, new Object[] { fieldValue }))));
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoPickerFieldSuggestion
 * JD-Core Version:    0.6.2
 */