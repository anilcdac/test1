/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoCheckboxFieldOption extends TempoCheckboxField
/*    */   implements Clickable
/*    */ {
/* 15 */   private static final Logger LOG = Logger.getLogger(TempoCheckboxFieldOption.class);
/* 16 */   private static final String XPATH_ABSOLUTE_CHECKBOX_FIELD_OPTION = Settings.getByConstant("xpathAbsoluteCheckboxFieldOption");
/* 17 */   private static final String XPATH_ABSOLUTE_CHECKBOX_FIELD_OPTION_INDEX = "(" + XPATH_ABSOLUTE_CHECKBOX_FIELD_OPTION + ")[%2$d]";
/*    */ 
/*    */   public static TempoCheckboxFieldOption getInstance(Settings settings) {
/* 20 */     return new TempoCheckboxFieldOption(settings);
/*    */   }
/*    */ 
/*    */   private TempoCheckboxFieldOption(Settings settings) {
/* 24 */     super(settings);
/*    */   }
/*    */ 
/*    */   public WebElement getOptionLayout(String optionName) {
/* 28 */     if (isFieldIndex(optionName)) {
/* 29 */       String oName = getFieldFromFieldIndex(optionName);
/* 30 */       int index = getIndexFromFieldIndex(optionName);
/* 31 */       return this.settings.getDriver().findElement(By.xpath(xpathFormat(XPATH_ABSOLUTE_CHECKBOX_FIELD_OPTION_INDEX, new Object[] { oName, Integer.valueOf(index) })));
/*    */     }
/* 33 */     return this.settings.getDriver().findElement(By.xpath(xpathFormat(XPATH_ABSOLUTE_CHECKBOX_FIELD_OPTION, new Object[] { optionName })));
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 38 */     String optionName = getParam(0, params);
/*    */ 
/* 40 */     if (LOG.isDebugEnabled()) LOG.debug("CHECKBOX OPTION CLICK [" + optionName + "]");
/*    */     try
/*    */     {
/* 43 */       WebElement element = getOptionLayout(optionName);
/* 44 */       clickElement(element);
/*    */     } catch (Exception e) {
/* 46 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Checkbox option", optionName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params) {
/* 51 */     String optionName = getParam(0, params);
/*    */ 
/* 53 */     if (LOG.isDebugEnabled()) LOG.debug("CHECKBOX OPTION WAIT FOR [" + optionName + "]");
/*    */     try
/*    */     {
/* 56 */       if (isFieldIndex(optionName)) {
/* 57 */         String oName = getFieldFromFieldIndex(optionName);
/* 58 */         int index = getIndexFromFieldIndex(optionName);
/* 59 */         new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/* 60 */           .until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathFormat(XPATH_ABSOLUTE_CHECKBOX_FIELD_OPTION_INDEX, new Object[] { oName, 
/* 61 */           Integer.valueOf(index) }))));
/*    */       }
/*    */       else
/*    */       {
/* 63 */         new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/* 64 */           .until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathFormat(XPATH_ABSOLUTE_CHECKBOX_FIELD_OPTION, new Object[] { optionName }))));
/*    */       }
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 68 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Checkbox option", optionName });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoCheckboxFieldOption
 * JD-Core Version:    0.6.2
 */