/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.properties.FieldLayoutWaitForReturn;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.TimeoutException;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoPickerFieldSelection extends TempoPickerField
/*    */   implements FieldLayoutWaitForReturn
/*    */ {
/* 16 */   private static final Logger LOG = Logger.getLogger(TempoPickerFieldSelection.class);
/* 17 */   protected static final String XPATH_RELATIVE_PICKER_SELECTION = Settings.getByConstant("xpathRelativePickerSelection");
/* 18 */   protected static final String XPATH_RELATIVE_PICKER_SPECIFIC_SELECTION = Settings.getByConstant("xpathRelativePickerSpecificSelection");
/* 19 */   protected static final String XPATH_RELATIVE_PICKER_SELECTION_REMOVE_LINK = Settings.getByConstant("xpathRelativePickerSelectionRemoveLink");
/* 20 */   protected static final String XPATH_RELATIVE_PICKER_SPECIFIC_SELECTION_REMOVE_LINK = Settings.getByConstant("xpathRelativePickerSpecificSelectionRemoveLink");
/*    */ 
/*    */   public static TempoPickerFieldSelection getInstance(Settings settings) {
/* 23 */     return new TempoPickerFieldSelection(settings);
/*    */   }
/*    */ 
/*    */   private TempoPickerFieldSelection(Settings settings) {
/* 27 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(WebElement fieldLayout, String[] params) {
/* 31 */     String fieldValue = getParam(0, params);
/*    */ 
/* 33 */     String xpathLocator = getXpathLocator(fieldLayout);
/* 34 */     return "(" + xpathLocator + ")" + xpathFormat(XPATH_RELATIVE_PICKER_SPECIFIC_SELECTION, new Object[] { fieldValue });
/*    */   }
/*    */ 
/*    */   public void waitFor(WebElement fieldLayout, String[] params)
/*    */   {
/* 39 */     new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getXpath(fieldLayout, params))));
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(int timeout, WebElement fieldLayout, String[] params)
/*    */   {
/*    */     try
/*    */     {
/* 46 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(fieldLayout, params))));
/*    */ 
/* 48 */       return true; } catch (TimeoutException e) {
/*    */     }
/* 50 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(WebElement fieldLayout, String[] params)
/*    */   {
/* 56 */     return waitForReturn(this.settings.getNotPresentTimeoutSeconds(), fieldLayout, params);
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoPickerFieldSelection
 * JD-Core Version:    0.6.2
 */