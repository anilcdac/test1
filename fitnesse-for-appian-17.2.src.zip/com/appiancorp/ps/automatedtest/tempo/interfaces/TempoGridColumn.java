/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ 
/*    */ public class TempoGridColumn extends TempoGrid
/*    */   implements Clickable
/*    */ {
/* 13 */   private static final Logger LOG = Logger.getLogger(TempoGridColumn.class);
/* 14 */   private static final String XPATH_RELATIVE_GRID_COLUMN_LINK = Settings.getByConstant("xpathRelativeGridColumnLink");
/*    */ 
/*    */   public static TempoGridColumn getInstance(Settings settings) {
/* 17 */     return new TempoGridColumn(settings);
/*    */   }
/*    */ 
/*    */   private TempoGridColumn(Settings settings) {
/* 21 */     super(settings);
/*    */   }
/*    */ 
/*    */   public void click(String[] params) {
/* 25 */     String gridName = getParam(0, params);
/* 26 */     String columnName = getParam(1, params);
/*    */ 
/* 28 */     if (LOG.isDebugEnabled()) LOG.debug("SORT GRID [" + gridName + "] BY [" + columnName + "]");
/*    */     try
/*    */     {
/* 31 */       WebElement grid = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 32 */       WebElement column = grid.findElement(By.xpath(xpathFormat(XPATH_RELATIVE_GRID_COLUMN_LINK, new Object[] { columnName })));
/* 33 */       clickElement(column);
/*    */     } catch (Exception e) {
/* 35 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Sort Grid", columnName });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridColumn
 * JD-Core Version:    0.6.2
 */