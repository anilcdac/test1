/*     */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.common.Version;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.Keys;
/*     */ import org.openqa.selenium.WebDriver;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.Select;
/*     */ 
/*     */ public class TempoDropdownField extends AbstractTempoField
/*     */ {
/*  19 */   private static final Logger LOG = Logger.getLogger(TempoDropdownField.class);
/*     */ 
/*  21 */   private static final String XPATH_RELATIVE_SELECT_FIELD_INPUT = Settings.getByConstant("xpathRelativeSelectFieldInput");
/*     */   public static final int ITERATION_TIME_LIMIT_SECONDS = 60;
/*     */ 
/*     */   public static TempoDropdownField getInstance(Settings settings)
/*     */   {
/*  25 */     return new TempoDropdownField(settings);
/*     */   }
/*     */ 
/*     */   private TempoDropdownField(Settings settings) {
/*  29 */     super(settings);
/*     */   }
/*     */ 
/*     */   public void populate(WebElement fieldLayout, String[] params)
/*     */   {
/*  47 */     String fieldValue = getParam(1, params);
/*     */ 
/*  49 */     if (LOG.isDebugEnabled()) LOG.debug("POPULATION [" + fieldValue + "]");
/*     */ 
/*  51 */     WebElement selectField = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_SELECT_FIELD_INPUT));
/*     */ 
/*  53 */     if (Settings.getVersion().compareTo(new Version(Integer.valueOf(17), Integer.valueOf(1))) < 0) {
/*  54 */       Select select = new Select(selectField);
/*     */ 
/*  56 */       if (isFieldIndex(fieldValue)) {
/*  57 */         int index = getIndexFromFieldIndex(fieldValue);
/*  58 */         select.selectByIndex(index);
/*     */       } else {
/*  60 */         select.selectByVisibleText(fieldValue);
/*     */       }
/*     */     } else {
/*  63 */       selectField.click();
/*     */ 
/*  65 */       if (isFieldIndex(fieldValue)) {
/*  66 */         int selectedOptionIndex = getIndexFromFieldIndex(fieldValue);
/*     */ 
/*  68 */         if (isMultipleDropdown(selectField)) {
/*  69 */           selectedOptionIndex--;
/*     */         }
/*     */ 
/*  72 */         for (int i = 0; i < selectedOptionIndex; i++) {
/*  73 */           selectField.sendKeys(new CharSequence[] { Keys.ARROW_DOWN });
/*     */         }
/*  75 */         selectField.sendKeys(new CharSequence[] { Keys.ENTER });
/*     */       } else {
/*  77 */         Calendar now = Calendar.getInstance();
/*  78 */         Calendar iterationTimeLimit = Calendar.getInstance();
/*     */ 
/*  80 */         now.setTime(new Date());
/*  81 */         iterationTimeLimit.setTime(new Date());
/*  82 */         iterationTimeLimit.add(13, 60);
/*     */ 
/*  84 */         int selectedOptionIndex = 1;
/*     */ 
/*  86 */         if (isMultipleDropdown(selectField)) {
/*  87 */           selectedOptionIndex = 0;
/*     */         }
/*     */ 
/*  90 */         selectField.sendKeys(new CharSequence[] { Keys.ESCAPE });
/*     */ 
/*  92 */         while ((isFieldValueNotSelected(isMultipleDropdown(selectField), fieldValue, selectField)) && 
/*  93 */           (iterationTimeLimit
/*  93 */           .compareTo(now) >= 0))
/*     */         {
/*  94 */           for (int i = 0; i <= selectedOptionIndex; i++) {
/*  95 */             selectField.sendKeys(new CharSequence[] { Keys.ARROW_DOWN });
/*     */           }
/*  97 */           selectedOptionIndex++;
/*  98 */           selectField.sendKeys(new CharSequence[] { Keys.ENTER });
/*  99 */           now.setTime(new Date());
/* 100 */           if (LOG.isDebugEnabled()) {
/* 101 */             LOG.debug("SELECTED OPTION [" + selectField.getText() + "]");
/*     */           }
/*     */         }
/*     */ 
/* 105 */         if (iterationTimeLimit.compareTo(now) < 0)
/* 106 */           throw new RuntimeException("Timeout trying to select dropdown value. Could not find specified value.");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String capture(WebElement fieldLayout, String[] params)
/*     */   {
/* 114 */     List values = new ArrayList();
/* 115 */     WebElement selectField = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_SELECT_FIELD_INPUT));
/* 116 */     boolean isMultipleDropdown = isMultipleDropdown(selectField);
/*     */     List selects;
/* 118 */     if (Settings.getVersion().compareTo(new Version(Integer.valueOf(17), Integer.valueOf(1))) < 0) {
/* 119 */       Select select = new Select(selectField);
/* 120 */       selects = select.getAllSelectedOptions();
/* 121 */       for (WebElement settings : selects) {
/* 122 */         values.add(settings.getText());
/*     */       }
/*     */ 
/* 125 */       if (LOG.isDebugEnabled()) LOG.debug("SELECT FIELD VALUE : " + values.toString());
/*     */ 
/* 127 */       return String.join(",", values);
/*     */     }
/* 129 */     if (!isMultipleDropdown) {
/* 130 */       return selectField.getText();
/*     */     }
/* 132 */     List selectedItems = getListItemsFromHiddenList(selectField);
/* 133 */     for (WebElement selectedItem : selectedItems) {
/* 134 */       values.add(selectedItem.getText());
/*     */     }
/*     */ 
/* 137 */     selectField.sendKeys(new CharSequence[] { Keys.ESCAPE });
/* 138 */     return String.join(",", values);
/*     */   }
/*     */ 
/*     */   public boolean contains(WebElement fieldLayout, String[] params)
/*     */   {
/* 146 */     String fieldValue = getParam(0, params);
/*     */     try
/*     */     {
/* 150 */       return TempoFieldFactory.getInstance(this.settings).contains(fieldLayout, new String[] { fieldValue });
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 155 */       WebElement selectField = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_SELECT_FIELD_INPUT));
/* 156 */       boolean selected = false;
/*     */       int index;
/* 158 */       if (Settings.getVersion().compareTo(new Version(Integer.valueOf(17), Integer.valueOf(1))) < 0) {
/* 159 */         Select select = new Select(selectField);
/* 160 */         List selectedOptions = select.getAllSelectedOptions();
/*     */ 
/* 162 */         if (isFieldIndex(fieldValue)) {
/* 163 */           index = getIndexFromFieldIndex(fieldValue);
/* 164 */           fieldValue = ((WebElement)select.getAllSelectedOptions().get(index - 1)).getText();
/*     */         }
/*     */ 
/* 167 */         for (WebElement s : selectedOptions)
/* 168 */           if (s.getText().contains(fieldValue)) {
/* 169 */             selected = true;
/* 170 */             break;
/*     */           }
/*     */       }
/*     */       else {
/* 174 */         List values = new ArrayList();
/*     */ 
/* 176 */         if (isFieldIndex(fieldValue)) {
/* 177 */           WebElement selectedItem = getListItemFromHiddenList(fieldValue, selectField);
/* 178 */           selected = Boolean.parseBoolean(selectedItem.getAttribute("aria-selected"));
/*     */         } else {
/* 180 */           List selectedItems = getListItemsFromHiddenList(selectField);
/* 181 */           for (WebElement selectedItem : selectedItems) {
/* 182 */             values.add(selectedItem.getText());
/*     */           }
/* 184 */           selected = values.contains(fieldValue);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 189 */       selectField.sendKeys(new CharSequence[] { Keys.ESCAPE });
/*     */ 
/* 191 */       if (LOG.isDebugEnabled()) LOG.debug("SELECT FIELD COMPARISON : Field value [" + fieldValue + "] was selected [" + selected + "]");
/*     */ 
/* 193 */       return selected;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isType(WebElement fieldLayout) {
/*     */     try { fieldLayout.findElement(By.xpath(XPATH_RELATIVE_SELECT_FIELD_INPUT));
/*     */     } catch (Exception e) {
/* 200 */       return false;
/*     */     }
/*     */ 
/* 203 */     return true;
/*     */   }
/*     */ 
/*     */   public void clear(WebElement fieldLayout, String[] params)
/*     */   {
/*     */   }
/*     */ 
/*     */   private boolean isMultipleDropdown(WebElement selectField)
/*     */   {
/* 213 */     return selectField.getAttribute("class").contains("MultipleDropdownWidget");
/*     */   }
/*     */ 
/*     */   private boolean isFieldValueNotSelected(boolean isMultipleDropdown, String fieldValue, WebElement selectField) {
/* 217 */     if (isMultipleDropdown) {
/* 218 */       return !selectField.getText().contains(fieldValue);
/*     */     }
/*     */ 
/* 221 */     return !selectField.getText().equals(fieldValue);
/*     */   }
/*     */ 
/*     */   private WebElement getHiddenDropdownList()
/*     */   {
/* 226 */     return this.settings.getDriver()
/* 227 */       .findElement(By.xpath("//div[contains(@class,'TetherComponent---sailcontents') and contains(@class,'DropdownWidget---tether_dropdown')]//ul"));
/*     */   }
/*     */ 
/*     */   private List<WebElement> getListItemsFromHiddenList(WebElement selectField)
/*     */   {
/*     */     try
/*     */     {
/* 233 */       return getHiddenDropdownList().findElements(By.xpath("./li[@aria-selected='true']"));
/*     */     } catch (Exception e) {
/* 235 */       selectField.click();
/* 236 */     }return getHiddenDropdownList().findElements(By.xpath("./li[@aria-selected='true']"));
/*     */   }
/*     */ 
/*     */   private WebElement getListItemFromHiddenList(String fieldValue, WebElement selectField)
/*     */   {
/* 243 */     int index = isMultipleDropdown(selectField) ? 
/* 242 */       getIndexFromFieldIndex(fieldValue) : 
/* 243 */       getIndexFromFieldIndex(fieldValue) + 
/* 243 */       1;
/*     */     try {
/* 245 */       return getHiddenDropdownList().findElement(By.xpath("./li[" + index + "]"));
/*     */     } catch (Exception e) {
/* 247 */       selectField.click();
/* 248 */     }return getHiddenDropdownList().findElement(By.xpath("./li[" + index + "]"));
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoDropdownField
 * JD-Core Version:    0.6.2
 */