/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Captureable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebElement;
/*    */ 
/*    */ public class TempoGridRowCount extends TempoGridNavigation
/*    */   implements Captureable
/*    */ {
/* 13 */   private static final Logger LOG = Logger.getLogger(TempoGridRowCount.class);
/*    */   private static final String DASH_PUNCTUATION_REGEX = "\\p{Pd}";
/*    */ 
/*    */   public static TempoGridRowCount getInstance(Settings settings)
/*    */   {
/* 17 */     return new TempoGridRowCount(settings);
/*    */   }
/*    */ 
/*    */   private TempoGridRowCount(Settings settings) {
/* 21 */     super(settings);
/*    */   }
/*    */ 
/*    */   public Integer capture(String[] params)
/*    */   {
/* 26 */     String gridName = getParam(0, params);
/*    */ 
/* 28 */     if (LOG.isDebugEnabled()) LOG.debug("GRID [" + gridName + "] ROW COUNT");
/*    */     try
/*    */     {
/* 31 */       WebElement grid = getWebElement(params);
/* 32 */       WebElement pagingLabel = grid.findElement(By.xpath(XPATH_RELATIVE_GRID_PAGING_LABEL));
/* 33 */       String pagingLabelText = pagingLabel.getText().replaceAll("[\\n\\s]", "");
/* 34 */       String rowCountStr = pagingLabelText.split("of", 2)[0];
/* 35 */       String[] rowCountStrArray = rowCountStr.split("\\p{Pd}", 2);
/* 36 */       int rowCount = Integer.parseInt(rowCountStrArray[1]) - Integer.parseInt(rowCountStrArray[0]) + 1;
/* 37 */       return Integer.valueOf(rowCount);
/*    */     } catch (Exception e) {
/* 39 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Retrieving grid total count", gridName });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridRowCount
 * JD-Core Version:    0.6.2
 */