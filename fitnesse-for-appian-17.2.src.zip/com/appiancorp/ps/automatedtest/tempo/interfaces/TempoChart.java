/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitForReturn;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.TimeoutException;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoChart extends AppianObject
/*    */   implements WaitForReturn
/*    */ {
/* 16 */   private static final Logger LOG = Logger.getLogger(TempoChart.class);
/* 17 */   private static final String XPATH_ABSOLUTE_CHART_LABEL = Settings.getByConstant("xpathAbsoluteChartLabel");
/*    */ 
/*    */   public TempoChart(Settings settings) {
/* 20 */     super(settings);
/*    */   }
/*    */ 
/*    */   public static TempoChart getInstance(Settings settings) {
/* 24 */     return new TempoChart(settings);
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 29 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR TEMPO CHART");
/*    */     try
/*    */     {
/* 32 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/* 33 */         .until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     }
/*    */     catch (Exception e) {
/* 35 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Tempo Chart" });
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 41 */     String chartName = getParam(0, params);
/* 42 */     return xpathFormat(XPATH_ABSOLUTE_CHART_LABEL, new Object[] { chartName });
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(int timeout, String[] params)
/*    */   {
/* 47 */     String chartName = getParam(0, params);
/*    */ 
/* 49 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR CHART [" + chartName + "]");
/*    */     try
/*    */     {
/* 52 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/* 53 */       return true;
/*    */     } catch (TimeoutException e) {
/* 55 */       return false;
/*    */     } catch (Exception e) {
/* 57 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "CHART", chartName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(String[] params)
/*    */   {
/* 63 */     return waitForReturn(this.settings.getTimeoutSeconds(), params);
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoChart
 * JD-Core Version:    0.6.2
 */