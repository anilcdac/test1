/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Captureable;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitForMultiple;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoFieldValidation extends AppianObject
/*    */   implements WaitForMultiple, Captureable
/*    */ {
/* 20 */   private static final Logger LOG = Logger.getLogger(TempoFieldValidation.class);
/* 21 */   public static final String XPATH_RELATIVE_FIELD_VALIDATION_MESSAGE_SPECIFIC_VALUE = Settings.getByConstant("xpathRelativeFieldValidationMessageSpecificValue");
/* 22 */   public static final String XPATH_RELATIVE_FIELD_VALIDATION_MESSAGE = Settings.getByConstant("xpathRelativeFieldValidationMessage");
/*    */ 
/*    */   public static TempoFieldValidation getInstance(Settings settings) {
/* 25 */     return new TempoFieldValidation(settings);
/*    */   }
/*    */ 
/*    */   protected TempoFieldValidation(Settings settings) {
/* 29 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 34 */     String fieldName = getParam(0, params);
/* 35 */     String validationMessage = getParam(1, params);
/*    */ 
/* 37 */     return "(" + TempoField.getInstance(this.settings).getXpath(new String[] { fieldName }) + ")" + 
/* 38 */       xpathFormat(XPATH_RELATIVE_FIELD_VALIDATION_MESSAGE_SPECIFIC_VALUE, new Object[] { validationMessage });
/*    */   }
/*    */ 
/*    */   public String capture(String[] params)
/*    */   {
/* 42 */     WebElement fieldLayout = this.settings.getDriver().findElement(By.xpath(TempoField.getInstance(this.settings).getXpath(params)));
/* 43 */     List values = new ArrayList();
/*    */ 
/* 45 */     for (WebElement a : fieldLayout.findElements(By.xpath(XPATH_RELATIVE_FIELD_VALIDATION_MESSAGE))) {
/* 46 */       values.add(a.getText());
/*    */     }
/*    */ 
/* 49 */     return String.join(",", values);
/*    */   }
/*    */ 
/*    */   public void waitForMultiple(String[] validationMessages, String[] params) {
/* 53 */     String fieldName = getParam(0, params);
/*    */     try
/*    */     {
/* 56 */       for (String validationMessage : validationMessages)
/* 57 */         waitFor(new String[] { fieldName, validationMessage });
/*    */     }
/*    */     catch (Exception e) {
/* 60 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Get field value", fieldName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 67 */     String fieldName = getParam(0, params);
/* 68 */     String validationMessage = getParam(1, params);
/*    */ 
/* 70 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR VALIDATION [" + validationMessage + "]");
/*    */ 
/* 72 */     new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(
/* 73 */       getXpath(params))));
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoFieldValidation
 * JD-Core Version:    0.6.2
 */