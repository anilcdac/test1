/*     */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoImageField extends AbstractTempoField
/*     */ {
/*  15 */   private static final Logger LOG = Logger.getLogger(TempoTextField.class);
/*  16 */   private static final String XPATH_ABSOLUTE_IMAGE_FIELD_LABEL = Settings.getByConstant("xpathAbsoluteImageFieldLabel");
/*  17 */   private static final String XPATH_ABSOLUTE_IMAGE_FIELD_INDEX = Settings.getByConstant("xpathAbsoluteImageFieldIndex");
/*  18 */   private static final String XPATH_ABSOLUTE_IMAGE_FIELD_LABEL_INDEX = "(" + XPATH_ABSOLUTE_IMAGE_FIELD_LABEL + ")[%2$d]";
/*  19 */   private static final String XPATH_RELATIVE_IMAGE_FIELD_INPUT = Settings.getByConstant("xpathRelativeImageFieldInput");
/*     */ 
/*     */   public static TempoImageField getInstance(Settings settings) {
/*  22 */     return new TempoImageField(settings);
/*     */   }
/*     */ 
/*     */   private TempoImageField(Settings settings) {
/*  26 */     super(settings);
/*     */   }
/*     */ 
/*     */   public String getXpath(String[] params)
/*     */   {
/*  31 */     String fieldName = getParam(0, params);
/*     */ 
/*  33 */     if (isFieldIndex(fieldName)) {
/*  34 */       int index = getIndexFromFieldIndex(fieldName);
/*  35 */       String name = getFieldFromFieldIndex(fieldName);
/*  36 */       if (StringUtils.isBlank(name)) {
/*  37 */         return xpathFormat(XPATH_ABSOLUTE_IMAGE_FIELD_INDEX + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { Integer.valueOf(index) });
/*     */       }
/*  39 */       return xpathFormat(XPATH_ABSOLUTE_IMAGE_FIELD_LABEL_INDEX + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { name, 
/*  40 */         Integer.valueOf(index) });
/*     */     }
/*     */ 
/*  44 */     return xpathFormat(XPATH_ABSOLUTE_IMAGE_FIELD_LABEL + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { fieldName });
/*     */   }
/*     */ 
/*     */   public void waitFor(String[] params)
/*     */   {
/*  50 */     String fieldName = getParam(0, params);
/*     */ 
/*  52 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR [" + fieldName + "]");
/*     */     try
/*     */     {
/*  55 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/*  56 */         .until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*     */     }
/*     */     catch (Exception e) {
/*  58 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Field", fieldName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void populate(WebElement fieldLayout, String[] params)
/*     */   {
/*     */   }
/*     */ 
/*     */   public String capture(WebElement fieldLayout, String[] params)
/*     */   {
/*  68 */     WebElement element = fieldLayout.findElement(By.xpath(xpathFormat(XPATH_RELATIVE_IMAGE_FIELD_INPUT, new Object[0])));
/*     */ 
/*  70 */     String value = element.getAttribute("alt");
/*  71 */     if (LOG.isDebugEnabled()) LOG.debug("IMAGE FIELD ALT : " + value);
/*     */ 
/*  73 */     return value;
/*     */   }
/*     */ 
/*     */   public boolean contains(WebElement fieldLayout, String[] params)
/*     */   {
/*  78 */     String fieldValue = getParam(0, params);
/*     */     try
/*     */     {
/*  81 */       return TempoFieldFactory.getInstance(this.settings).contains(fieldLayout, new String[] { fieldValue });
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*  86 */       String compareString = capture(fieldLayout, new String[0]);
/*  87 */       if (LOG.isDebugEnabled()) {
/*  88 */         LOG.debug("IMAGE FIELD COMPARISON : Field value [" + fieldValue + "] compared to Entered value [" + compareString + "]");
/*     */       }
/*  90 */       return compareString.contains(fieldValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear(WebElement fieldLayout, String[] params)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static boolean isType(WebElement fieldLayout) {
/*     */     try {
/* 100 */       fieldLayout.findElement(By.xpath(XPATH_RELATIVE_IMAGE_FIELD_INPUT));
/*     */     } catch (Exception e) {
/* 102 */       return false;
/*     */     }
/*     */ 
/* 105 */     return true;
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoImageField
 * JD-Core Version:    0.6.2
 */