/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Captureable;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitFor;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoFormInstructions extends AppianObject
/*    */   implements WaitFor, Captureable
/*    */ {
/* 17 */   private static final Logger LOG = Logger.getLogger(TempoFormInstructions.class);
/* 18 */   private static final String XPATH_ABSOLUTE_FORM_INSTRUCTIONS = Settings.getByConstant("xpathAbsoluteFormInstructions");
/*    */ 
/*    */   public static TempoFormInstructions getInstance(Settings settings) {
/* 21 */     return new TempoFormInstructions(settings);
/*    */   }
/*    */ 
/*    */   private TempoFormInstructions(Settings settings) {
/* 25 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 30 */     return XPATH_ABSOLUTE_FORM_INSTRUCTIONS;
/*    */   }
/*    */ 
/*    */   public String capture(String[] params)
/*    */   {
/* 35 */     if (LOG.isDebugEnabled()) LOG.debug("GET FORM INSTRUCTIONS");
/*    */     try
/*    */     {
/* 38 */       WebElement element = this.settings.getDriver().findElement(By.xpath(xpathFormat(getXpath(params), new Object[0])));
/* 39 */       return element.getText();
/*    */     } catch (Exception e) {
/* 41 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Get Form Instructions" });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 47 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR FORM INSTRUCTIONS");
/*    */     try
/*    */     {
/* 50 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 52 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Form Instructions" });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoFormInstructions
 * JD-Core Version:    0.6.2
 */