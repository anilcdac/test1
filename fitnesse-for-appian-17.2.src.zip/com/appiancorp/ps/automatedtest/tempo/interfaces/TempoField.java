/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import org.openqa.selenium.WebElement;
/*    */ 
/*    */ public class TempoField extends AbstractTempoField
/*    */ {
/*    */   public static TempoField getInstance(Settings settings)
/*    */   {
/* 10 */     return new TempoField(settings);
/*    */   }
/*    */ 
/*    */   private TempoField(Settings settings) {
/* 14 */     super(settings);
/*    */   }
/*    */ 
/*    */   public void populate(WebElement fieldLayout, String[] params)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   public boolean contains(WebElement fieldLayout, String[] params)
/*    */     throws Exception
/*    */   {
/* 26 */     return false;
/*    */   }
/*    */ 
/*    */   public String capture(WebElement fieldLayout, String[] params)
/*    */   {
/* 32 */     return null;
/*    */   }
/*    */ 
/*    */   public void clear(WebElement fieldLayout, String[] params)
/*    */   {
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoField
 * JD-Core Version:    0.6.2
 */