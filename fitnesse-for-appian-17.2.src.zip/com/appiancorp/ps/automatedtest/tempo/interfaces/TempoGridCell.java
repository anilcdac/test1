/*     */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import com.appiancorp.ps.automatedtest.properties.Captureable;
/*     */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*     */ import com.appiancorp.ps.automatedtest.properties.Populateable;
/*     */ import com.appiancorp.ps.automatedtest.properties.PopulateableMultiple;
/*     */ import com.appiancorp.ps.automatedtest.properties.RegexCaptureable;
/*     */ import com.appiancorp.ps.automatedtest.properties.Verifiable;
/*     */ import com.appiancorp.ps.automatedtest.properties.VerifiableMultiple;
/*     */ import com.appiancorp.ps.automatedtest.properties.WaitFor;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.WebDriver;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoGridCell extends TempoGrid
/*     */   implements PopulateableMultiple, Populateable, VerifiableMultiple, Verifiable, Captureable, RegexCaptureable, WaitFor, Clickable
/*     */ {
/*  26 */   private static final String XPATH_RELATIVE_GRID_CELL_LINK = Settings.getByConstant("xpathRelativeGridCellLink");
/*     */ 
/*  28 */   private static final Logger LOG = Logger.getLogger(TempoGridCell.class);
/*     */ 
/*  30 */   private static final String XPATH_ABSOLUTE_GRID_BY_LABEL_CELL_BY_COLUMN_LABEL = XPATH_ABSOLUTE_GRID_BY_LABEL + 
/*  30 */     Settings.getByConstant("xpathConcatCellByGridLabelColumnLabel")
/*  30 */     ;
/*     */ 
/*  32 */   private static final String XPATH_ABSOLUTE_GRID_BY_LABEL_CELL_BY_COLUMN_INDEX = XPATH_ABSOLUTE_GRID_BY_LABEL + 
/*  32 */     Settings.getByConstant("xpathConcatCellByColumnIndex")
/*  32 */     ;
/*     */ 
/*  34 */   private static final String XPATH_ABSOLUTE_GRID_BY_INDEX_CELL_BY_COLUMN_LABEL = XPATH_ABSOLUTE_GRID_BY_INDEX + 
/*  34 */     Settings.getByConstant("xpathConcatCellByGridIndexColumnLabel")
/*  34 */     ;
/*     */ 
/*  36 */   private static final String XPATH_ABSOLUTE_GRID_BY_INDEX_CELL_BY_COLUMN_INDEX = XPATH_ABSOLUTE_GRID_BY_INDEX + 
/*  36 */     Settings.getByConstant("xpathConcatCellByColumnIndex")
/*  36 */     ;
/*     */ 
/*  38 */   private static final String XPATH_ABSOLUTE_GRID_BY_LABEL_INDEX_CELL_BY_COLUMN_LABEL = XPATH_ABSOLUTE_GRID_BY_LABEL_INDEX + 
/*  38 */     Settings.getByConstant("xpathConcatCellByGridLabelIndexColumnLabel")
/*  38 */     ;
/*     */ 
/*  40 */   private static final String XPATH_ABSOLUTE_GRID_BY_LABEL_INDEX_CELL_BY_COLUMN_INDEX = XPATH_ABSOLUTE_GRID_BY_LABEL_INDEX + 
/*  40 */     Settings.getByConstant("xpathConcatCellByGridLabelIndexColumnIndex")
/*  40 */     ;
/*     */ 
/*     */   public static TempoGridCell getInstance(Settings settings) {
/*  43 */     return new TempoGridCell(settings);
/*     */   }
/*     */ 
/*     */   protected TempoGridCell(Settings settings) {
/*  47 */     super(settings);
/*     */   }
/*     */ 
/*     */   public WebElement getWebElement(String[] params)
/*     */   {
/*  52 */     WebElement cell = null;
/*     */ 
/*  54 */     if (params.length == 1) {
/*  55 */       cell = this.settings.getDriver().findElement(By.xpath(super.getXpath(params)));
/*  56 */     } else if (params.length == 2) {
/*  57 */       String gridName = getParam(0, params);
/*  58 */       String rowNum = getParam(1, params);
/*     */ 
/*  60 */       waitFor(new String[] { gridName, "[1]", rowNum });
/*     */     } else {
/*  62 */       String gridName = getParam(0, params);
/*  63 */       String columnName = getParam(1, params);
/*  64 */       String rowNum = getParam(2, params);
/*     */ 
/*  66 */       if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR GRID [" + gridName + "] COLUMN [" + columnName + "] ROW [" + rowNum + "]");
/*     */       try
/*     */       {
/*  69 */         int rNum = getIndexFromFieldIndex(rowNum);
/*     */ 
/*  71 */         if (isFieldIndex(gridName)) {
/*  72 */           int gNum = getIndexFromFieldIndex(gridName);
/*  73 */           String gName = getFieldFromFieldIndex(gridName);
/*     */ 
/*  75 */           if (StringUtils.isBlank(gName)) {
/*  76 */             if (isFieldIndex(columnName))
/*     */             {
/*  78 */               int cNum = getIndexFromFieldIndex(columnName);
/*  79 */               cell = this.settings.getDriver().findElement(By.xpath(xpathFormat(XPATH_ABSOLUTE_GRID_BY_INDEX_CELL_BY_COLUMN_INDEX, new Object[] { 
/*  80 */                 Integer.valueOf(gNum), 
/*  80 */                 Integer.valueOf(rNum), Integer.valueOf(cNum) })));
/*     */             }
/*     */             else {
/*  83 */               cell = this.settings.getDriver().findElement(By.xpath(xpathFormat(XPATH_ABSOLUTE_GRID_BY_INDEX_CELL_BY_COLUMN_LABEL, new Object[] { 
/*  84 */                 Integer.valueOf(gNum), 
/*  84 */                 columnName, Integer.valueOf(rNum) })));
/*     */             }
/*     */           }
/*  87 */           else if (isFieldIndex(columnName))
/*     */           {
/*  89 */             int cNum = getIndexFromFieldIndex(columnName);
/*  90 */             cell = this.settings.getDriver().findElement(By.xpath(xpathFormat(XPATH_ABSOLUTE_GRID_BY_LABEL_INDEX_CELL_BY_COLUMN_INDEX, new Object[] { gName, 
/*  91 */               Integer.valueOf(gNum), 
/*  91 */               Integer.valueOf(rNum), Integer.valueOf(cNum) })));
/*     */           }
/*     */           else
/*     */           {
/*  95 */             cell = this.settings.getDriver().findElement(By.xpath(xpathFormat(XPATH_ABSOLUTE_GRID_BY_LABEL_INDEX_CELL_BY_COLUMN_LABEL, new Object[] { gName, 
/*  96 */               Integer.valueOf(gNum), 
/*  96 */               columnName, Integer.valueOf(rNum) })));
/*     */           }
/*     */ 
/*     */         }
/* 100 */         else if (isFieldIndex(columnName))
/*     */         {
/* 102 */           int cNum = getIndexFromFieldIndex(columnName);
/* 103 */           cell = this.settings.getDriver().findElement(By.xpath(xpathFormat(XPATH_ABSOLUTE_GRID_BY_LABEL_CELL_BY_COLUMN_INDEX, new Object[] { gridName, 
/* 104 */             Integer.valueOf(rNum), 
/* 104 */             Integer.valueOf(cNum) })));
/*     */         }
/*     */         else
/*     */         {
/* 108 */           cell = this.settings.getDriver().findElement(By.xpath(xpathFormat(XPATH_ABSOLUTE_GRID_BY_LABEL_CELL_BY_COLUMN_LABEL, new Object[] { gridName, columnName, 
/* 109 */             Integer.valueOf(rNum) })));
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 113 */         throw ExceptionBuilder.build(e, this.settings, new String[] { "Grid Wait For", gridName, columnName, rowNum });
/*     */       }
/*     */     }
/* 116 */     scrollIntoView(cell);
/* 117 */     return cell;
/*     */   }
/*     */ 
/*     */   public String getXpath(String[] params)
/*     */   {
/* 122 */     WebElement cell = getWebElement(params);
/* 123 */     return getXpathLocator(cell);
/*     */   }
/*     */ 
/*     */   public void populateMultiple(String[] fieldValues, String[] params)
/*     */   {
/* 128 */     String gridName = getParam(0, params);
/* 129 */     String columnName = getParam(1, params);
/* 130 */     String rowNum = getParam(2, params);
/*     */ 
/* 132 */     for (String fieldValue : fieldValues) {
/* 133 */       params = new String[] { gridName, columnName, rowNum, fieldValue };
/* 134 */       populate(params);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void populate(String[] params)
/*     */   {
/* 141 */     String gridName = getParam(0, params);
/* 142 */     String columnName = getParam(1, params);
/* 143 */     String rowNum = getParam(2, params);
/* 144 */     String fieldValue = getParam(3, params);
/*     */ 
/* 146 */     WebElement cell = getWebElement(params);
/* 147 */     TempoFieldFactory.getInstance(this.settings).populate(cell, new String[] { "", fieldValue });
/*     */   }
/*     */ 
/*     */   public void click(String[] params)
/*     */   {
/* 153 */     String gridName = getParam(0, params);
/* 154 */     String columnName = getParam(1, params);
/* 155 */     String rowNum = getParam(2, params);
/*     */ 
/* 157 */     WebElement cell = getWebElement(params);
/* 158 */     WebElement link = cell.findElement(By.xpath(XPATH_RELATIVE_GRID_CELL_LINK));
/* 159 */     clickElement(link);
/*     */   }
/*     */ 
/*     */   public String capture(String[] params)
/*     */   {
/* 164 */     WebElement cell = getWebElement(params);
/*     */ 
/* 166 */     return TempoFieldFactory.getInstance(this.settings).capture(cell, new String[] { "" });
/*     */   }
/*     */ 
/*     */   public String regexCapture(String regex, Integer group, String[] params)
/*     */   {
/* 171 */     WebElement cell = getWebElement(params);
/*     */ 
/* 173 */     return TempoFieldFactory.getInstance(this.settings).regexCapture(cell, regex, group, new String[] { "" });
/*     */   }
/*     */ 
/*     */   public boolean containsMultiple(String[] fieldValues, String[] params)
/*     */   {
/* 178 */     String gridName = getParam(0, params);
/* 179 */     String columnName = getParam(1, params);
/* 180 */     String rowNum = getParam(2, params);
/*     */ 
/* 182 */     for (String fieldValue : fieldValues) {
/* 183 */       params = new String[] { gridName, columnName, rowNum, fieldValue };
/* 184 */       if (!contains(params)) return false;
/*     */     }
/*     */ 
/* 187 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean contains(String[] params)
/*     */   {
/* 192 */     String gridName = getParam(0, params);
/* 193 */     String columnName = getParam(1, params);
/* 194 */     String rowNum = getParam(2, params);
/* 195 */     String fieldValue = getParam(3, params);
/*     */ 
/* 197 */     WebElement cell = getWebElement(new String[] { gridName, columnName, rowNum });
/* 198 */     if (!TempoFieldFactory.getInstance(this.settings).contains(cell, new String[] { "", fieldValue })) return false;
/* 199 */     return true;
/*     */   }
/*     */ 
/*     */   public void clear(String[] params) {
/* 203 */     WebElement cell = getWebElement(params);
/* 204 */     TempoFieldFactory.getInstance(this.settings).clear(cell, new String[] { "" });
/*     */   }
/*     */ 
/*     */   public void waitFor(String[] params)
/*     */   {
/* 209 */     new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/* 210 */       .until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridCell
 * JD-Core Version:    0.6.2
 */