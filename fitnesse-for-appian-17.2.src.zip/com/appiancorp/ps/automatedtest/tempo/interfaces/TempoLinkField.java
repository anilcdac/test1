/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Captureable;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoLinkField extends AppianObject
/*    */   implements Clickable, Captureable
/*    */ {
/* 17 */   private static final Logger LOG = Logger.getLogger(TempoLinkField.class);
/* 18 */   private static final String XPATH_ABSOLUTE_LINK_FIELD = Settings.getByConstant("xpathAbsoluteLinkField");
/* 19 */   private static final String XPATH_ABSOLUTE_LINK_FIELD_INDEX = "(" + XPATH_ABSOLUTE_LINK_FIELD + ")[%2$d]";
/*    */ 
/*    */   public static TempoLinkField getInstance(Settings settings) {
/* 22 */     return new TempoLinkField(settings);
/*    */   }
/*    */ 
/*    */   protected TempoLinkField(Settings settings) {
/* 26 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 31 */     String linkName = getParam(0, params);
/*    */ 
/* 33 */     if (isFieldIndex(linkName)) {
/* 34 */       int lNum = getIndexFromFieldIndex(linkName);
/* 35 */       String lName = getFieldFromFieldIndex(linkName);
/* 36 */       return xpathFormat(XPATH_ABSOLUTE_LINK_FIELD_INDEX, new Object[] { lName, Integer.valueOf(lNum) });
/*    */     }
/* 38 */     return xpathFormat(XPATH_ABSOLUTE_LINK_FIELD, new Object[] { linkName });
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 44 */     String linkName = getParam(0, params);
/*    */ 
/* 46 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR LINK [" + linkName + "]");
/*    */     try
/*    */     {
/* 49 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 51 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Link", linkName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public String capture(String[] params)
/*    */   {
/* 57 */     WebElement link = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 58 */     String linkURL = link.getAttribute("href");
/* 59 */     return linkURL;
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 64 */     String linkName = getParam(0, params);
/*    */ 
/* 66 */     if (LOG.isDebugEnabled()) LOG.debug("CLINK LINK [" + linkName + "]");
/*    */     try
/*    */     {
/* 69 */       WebElement link = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 70 */       clickElement(link);
/*    */     } catch (Exception e) {
/* 72 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Click Link", linkName });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoLinkField
 * JD-Core Version:    0.6.2
 */