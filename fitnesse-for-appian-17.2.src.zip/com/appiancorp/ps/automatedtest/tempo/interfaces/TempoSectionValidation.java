/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.common.Version;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Captureable;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitForMultiple;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoSectionValidation extends TempoSection
/*    */   implements WaitForMultiple, Captureable
/*    */ {
/* 20 */   private static final Logger LOG = Logger.getLogger(TempoSectionValidation.class);
/*    */ 
/* 22 */   protected static final String XPATH_ABSOLUTE_SECTION_FIELD_LAYOUT = Settings.getByConstant("xpathAbsoluteSectionFieldLayout");
/* 23 */   protected static final String XPATH_ABSOLUTE_SECTION_FIELD_LAYOUT_INDEX = Settings.getByConstant("xpathAbsoluteSectionFieldLayoutIndex");
/* 24 */   protected static final String XPATH_RELATIVE_SECTION_VALIDATION_MESSAGE_SPECIFIC_VALUE = Settings.getByConstant("xpathRelativeSectionValidationMessageSpecificValue");
/* 25 */   protected static final String XPATH_RELATIVE_SECTION_VALIDATION_MESSAGE = Settings.getByConstant("xpathRelativeSectionValidationMessage");
/*    */ 
/* 27 */   protected static final String XPATH_ABSOLUTE_SECTION_LAYOUT = Settings.getByConstant("xpathAbsoluteSectionLayout");
/*    */ 
/*    */   public static TempoSectionValidation getInstance(Settings settings) {
/* 30 */     return new TempoSectionValidation(settings);
/*    */   }
/*    */ 
/*    */   protected TempoSectionValidation(Settings settings) {
/* 34 */     super(settings);
/*    */   }
/*    */ 
/*    */   public void waitForMultiple(String[] validationMessages, String[] params)
/*    */   {
/* 39 */     String sectionName = getParam(0, params);
/*    */ 
/* 41 */     if (LOG.isDebugEnabled()) {
/* 42 */       LOG.debug("WAIT FOR SECTION [" + sectionName + "] VALIDATIONS [" + String.join(",", validationMessages) + "]");
/*    */     }
/* 44 */     WebElement section = getWebElement(new String[] { sectionName });
/* 45 */     String xpathLocator = getXpathLocator(section);
/*    */     try
/*    */     {
/* 48 */       for (String validationMessage : validationMessages)
/* 49 */         new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath("(" + xpathLocator + ")" + 
/* 50 */           xpathFormat(XPATH_RELATIVE_SECTION_VALIDATION_MESSAGE_SPECIFIC_VALUE, new Object[] { validationMessage }))));
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 53 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Section Field", sectionName, String.join(",", validationMessages) });
/*    */     }
/*    */   }
/*    */ 
/*    */   public String capture(String[] params)
/*    */   {
/* 59 */     String sectionName = getParam(0, params);
/*    */ 
/* 61 */     if (LOG.isDebugEnabled()) LOG.debug("GET SECTION VALIDATIONS [" + sectionName + "]");
/*    */ 
/* 63 */     WebElement section = getWebElement(new String[] { sectionName });
/* 64 */     List values = new ArrayList();
/*    */ 
/* 66 */     for (WebElement a : section.findElements(By.xpath(XPATH_RELATIVE_SECTION_VALIDATION_MESSAGE))) {
/* 67 */       values.add(a.getText());
/*    */     }
/*    */ 
/* 70 */     if (Settings.getVersion().compareTo(new Version(Integer.valueOf(17), Integer.valueOf(1))) < 0)
/*    */     {
/* 72 */       if (values.size() > 1) {
/* 73 */         for (int i = 0; i < values.size(); i++) {
/* 74 */           String val = (String)values.get(i);
/* 75 */           values.set(i, val.substring(2, val.length()));
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 80 */     return String.join(",", values);
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoSectionValidation
 * JD-Core Version:    0.6.2
 */