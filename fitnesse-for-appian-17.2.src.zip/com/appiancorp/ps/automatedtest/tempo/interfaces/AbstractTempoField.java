/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Container;
/*    */ import com.appiancorp.ps.automatedtest.properties.FieldLayoutCaptureable;
/*    */ import com.appiancorp.ps.automatedtest.properties.FieldLayoutClearable;
/*    */ import com.appiancorp.ps.automatedtest.properties.FieldLayoutPopulateable;
/*    */ import com.appiancorp.ps.automatedtest.properties.FieldLayoutVerifiable;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitForReturn;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.TimeoutException;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public abstract class AbstractTempoField extends AppianObject
/*    */   implements Container, FieldLayoutPopulateable, FieldLayoutVerifiable, FieldLayoutCaptureable, FieldLayoutClearable, WaitForReturn
/*    */ {
/* 23 */   public static final String XPATH_ABSOLUTE_FIELD_LAYOUT_LABEL = Settings.getByConstant("xpathAbsoluteFieldLayoutLabel");
/* 24 */   public static final String XPATH_ABSOLUTE_FIELD_LAYOUT_INDEX = Settings.getByConstant("xpathAbsoluteFieldLayoutIndex");
/* 25 */   public static final String XPATH_ABSOLUTE_FIELD_LAYOUT_LABEL_INDEX = "(" + XPATH_ABSOLUTE_FIELD_LAYOUT_LABEL + ")[%2$d]";
/*    */ 
/*    */   protected AbstractTempoField(Settings settings) {
/* 28 */     super(settings);
/*    */   }
/*    */ 
/*    */   public WebElement getWebElement(String[] params)
/*    */   {
/* 33 */     return this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 38 */     String fieldName = getParam(0, params);
/*    */ 
/* 40 */     if (isFieldIndex(fieldName)) {
/* 41 */       int index = getIndexFromFieldIndex(fieldName);
/* 42 */       String name = getFieldFromFieldIndex(fieldName);
/* 43 */       if (StringUtils.isBlank(name)) {
/* 44 */         return xpathFormat(XPATH_ABSOLUTE_FIELD_LAYOUT_INDEX, new Object[] { Integer.valueOf(index) });
/*    */       }
/* 46 */       return xpathFormat(XPATH_ABSOLUTE_FIELD_LAYOUT_LABEL_INDEX, new Object[] { name, Integer.valueOf(index) });
/*    */     }
/*    */ 
/* 50 */     return xpathFormat(XPATH_ABSOLUTE_FIELD_LAYOUT_LABEL, new Object[] { fieldName });
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 56 */     String fieldName = getParam(0, params);
/*    */     try
/*    */     {
/* 59 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 61 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Field", fieldName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(int timeout, String[] params)
/*    */   {
/* 67 */     String fieldName = getParam(0, params);
/*    */     try
/*    */     {
/* 70 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getXpath(params))));
/* 71 */       return true;
/*    */     } catch (TimeoutException e) {
/* 73 */       return false;
/*    */     } catch (Exception e) {
/* 75 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Field", fieldName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(String[] params)
/*    */   {
/* 81 */     return waitForReturn(this.settings.getTimeoutSeconds(), params);
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.AbstractTempoField
 * JD-Core Version:    0.6.2
 */