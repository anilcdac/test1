/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Captureable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebElement;
/*    */ 
/*    */ public class TempoGridTotalCount extends TempoGridNavigation
/*    */   implements Captureable
/*    */ {
/* 13 */   private static final Logger LOG = Logger.getLogger(TempoGridTotalCount.class);
/*    */ 
/*    */   public static TempoGridTotalCount getInstance(Settings settings) {
/* 16 */     return new TempoGridTotalCount(settings);
/*    */   }
/*    */ 
/*    */   private TempoGridTotalCount(Settings settings) {
/* 20 */     super(settings);
/*    */   }
/*    */ 
/*    */   public Integer capture(String[] params)
/*    */   {
/* 25 */     String gridName = getParam(0, params);
/*    */ 
/* 27 */     if (LOG.isDebugEnabled()) LOG.debug("GRID [" + gridName + "] TOTAL COUNT");
/*    */     try
/*    */     {
/* 30 */       WebElement grid = getWebElement(new String[] { gridName });
/* 31 */       WebElement pagingLabel = grid.findElement(By.xpath(XPATH_RELATIVE_GRID_PAGING_LABEL));
/* 32 */       String pagingLabelText = pagingLabel.getText();
/* 33 */       String totalCountStr = pagingLabelText.split("of", 2)[1];
/* 34 */       int totalCount = Integer.parseInt(totalCountStr.trim());
/* 35 */       return Integer.valueOf(totalCount);
/*    */     } catch (Exception e) {
/* 37 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Retrieving grid total count", gridName });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridTotalCount
 * JD-Core Version:    0.6.2
 */