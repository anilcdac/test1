/*     */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.properties.Captureable;
/*     */ import com.appiancorp.ps.automatedtest.properties.Clearable;
/*     */ import com.appiancorp.ps.automatedtest.properties.Populateable;
/*     */ import com.appiancorp.ps.automatedtest.properties.PopulateableMultiple;
/*     */ import com.appiancorp.ps.automatedtest.properties.RegexCaptureable;
/*     */ import com.appiancorp.ps.automatedtest.properties.Verifiable;
/*     */ import com.appiancorp.ps.automatedtest.properties.VerifiableMultiple;
/*     */ import com.appiancorp.ps.automatedtest.properties.WaitFor;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.WebDriver;
/*     */ import org.openqa.selenium.WebElement;
/*     */ 
/*     */ public class TempoSectionField extends TempoSection
/*     */   implements VerifiableMultiple, Verifiable, PopulateableMultiple, Populateable, Captureable, RegexCaptureable, Clearable, WaitFor
/*     */ {
/*  23 */   private static final Logger LOG = Logger.getLogger(TempoSectionField.class);
/*     */ 
/*  25 */   protected static final String XPATH_ABSOLUTE_SECTION_FIELD_LAYOUT = Settings.getByConstant("xpathAbsoluteSectionFieldLayout");
/*  26 */   protected static final String XPATH_ABSOLUTE_SECTION_FIELD_LAYOUT_INDEX = Settings.getByConstant("xpathAbsoluteSectionFieldLayoutIndex");
/*  27 */   protected static final String XPATH_RELATIVE_SECTION_VALIDATION_MESSAGE_SPECIFIC_VALUE = Settings.getByConstant("xpathRelativeSectionValidationMessageSpecificValue");
/*  28 */   protected static final String XPATH_RELATIVE_SECTION_VALIDATION_MESSAGE = Settings.getByConstant("xpathRelativeSectionValidationMessage");
/*     */ 
/*  30 */   protected static final String XPATH_ABSOLUTE_SECTION_LAYOUT = Settings.getByConstant("xpathAbsoluteSectionLayout");
/*     */ 
/*     */   public static TempoSectionField getInstance(Settings settings) {
/*  33 */     return new TempoSectionField(settings);
/*     */   }
/*     */ 
/*     */   protected TempoSectionField(Settings settings) {
/*  37 */     super(settings);
/*     */   }
/*     */ 
/*     */   public WebElement getWebElement(String[] params) {
/*  41 */     return this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/*     */   }
/*     */ 
/*     */   public String getXpath(String[] params)
/*     */   {
/*  46 */     String fieldName = getParam(0, params);
/*  47 */     String sectionName = getParam(1, params);
/*     */ 
/*  50 */     if (isFieldIndex(fieldName)) {
/*  51 */       int index = getIndexFromFieldIndex(fieldName);
/*  52 */       return xpathFormat(XPATH_ABSOLUTE_SECTION_FIELD_LAYOUT_INDEX, new Object[] { sectionName, Integer.valueOf(index) });
/*     */     }
/*  54 */     return xpathFormat(XPATH_ABSOLUTE_SECTION_FIELD_LAYOUT, new Object[] { sectionName, fieldName });
/*     */   }
/*     */ 
/*     */   public void populateMultiple(String[] fieldValues, String[] params)
/*     */   {
/*  60 */     String fieldName = getParam(0, params);
/*  61 */     String fieldSection = getParam(1, params);
/*     */ 
/*  63 */     for (String fieldValue : fieldValues) {
/*  64 */       params = new String[] { fieldName, fieldSection, fieldValue };
/*  65 */       populate(params);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void populate(String[] params)
/*     */   {
/*  71 */     String fieldName = getParam(0, params);
/*  72 */     String fieldSection = getParam(1, params);
/*  73 */     String fieldValue = getParam(2, params);
/*     */ 
/*  75 */     WebElement fieldLayout = getWebElement(new String[] { fieldName, fieldSection });
/*  76 */     TempoFieldFactory.getInstance(this.settings).populate(fieldLayout, new String[] { fieldName, fieldValue });
/*     */   }
/*     */ 
/*     */   public void clear(String[] params)
/*     */   {
/*  81 */     String fieldName = getParam(0, params);
/*  82 */     String sectionName = getParam(1, params);
/*     */ 
/*  84 */     WebElement fieldLayout = getWebElement(new String[] { fieldName, sectionName });
/*  85 */     TempoFieldFactory.getInstance(this.settings).clear(fieldLayout, new String[] { fieldName });
/*     */   }
/*     */ 
/*     */   public String capture(String[] params)
/*     */   {
/*  90 */     WebElement fieldLayout = getWebElement(params);
/*  91 */     return TempoFieldFactory.getInstance(this.settings).capture(fieldLayout, params);
/*     */   }
/*     */ 
/*     */   public String regexCapture(String regex, Integer group, String[] params)
/*     */   {
/*  96 */     WebElement fieldLayout = getWebElement(params);
/*  97 */     return TempoFieldFactory.getInstance(this.settings).regexCapture(fieldLayout, regex, group, params);
/*     */   }
/*     */ 
/*     */   public boolean containsMultiple(String[] fieldValues, String[] params)
/*     */   {
/* 102 */     String fieldName = getParam(0, params);
/* 103 */     String sectionName = getParam(1, params);
/*     */ 
/* 105 */     for (String fieldValue : fieldValues) {
/* 106 */       params = new String[] { fieldName, sectionName, fieldValue };
/* 107 */       if (!contains(params)) return false;
/*     */     }
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean contains(String[] params)
/*     */   {
/* 114 */     String fieldName = getParam(0, params);
/* 115 */     String sectionName = getParam(1, params);
/* 116 */     String fieldValue = getParam(2, params);
/*     */ 
/* 118 */     WebElement fieldLayout = getWebElement(new String[] { fieldName, sectionName });
/* 119 */     if (!TempoFieldFactory.getInstance(this.settings).contains(fieldLayout, new String[] { fieldName, fieldValue })) return false;
/* 120 */     return true;
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoSectionField
 * JD-Core Version:    0.6.2
 */