/*     */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.CrossPlatformUtilities;
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.lang3.time.DateUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.Keys;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoDatetimeField extends AbstractTempoField
/*     */ {
/*  20 */   private static final Logger LOG = Logger.getLogger(TempoDatetimeField.class);
/*     */ 
/*  22 */   private static final String XPATH_RELATIVE_DATETIME_FIELD_DATE_PLACEHOLDER = Settings.getByConstant("xpathRelativeDatetimeFieldDatePlaceholder");
/*  23 */   private static final String XPATH_RELATIVE_DATETIME_FIELD_DATE_INPUT = Settings.getByConstant("xpathRelativeDatetimeFieldDateInput");
/*     */ 
/*  25 */   private static final String XPATH_RELATIVE_DATETIME_FIELD_TIME_PLACEHOLDER = Settings.getByConstant("xpathRelativeDatetimeFieldTimePlaceholder");
/*  26 */   private static final String XPATH_RELATIVE_DATETIME_FIELD_TIME_INPUT = Settings.getByConstant("xpathRelativeDatetimeFieldTimeInput");
/*     */ 
/*     */   public static TempoDatetimeField getInstance(Settings settings) {
/*  29 */     return new TempoDatetimeField(settings);
/*     */   }
/*     */ 
/*     */   private TempoDatetimeField(Settings settings) {
/*  33 */     super(settings);
/*     */   }
/*     */ 
/*     */   public void populate(WebElement fieldLayout, String[] params)
/*     */     throws ParseException
/*     */   {
/*  54 */     String fieldValue = getParam(1, params);
/*     */ 
/*  56 */     if (LOG.isDebugEnabled()) LOG.debug("POPULATION [" + fieldValue + "]");
/*     */ 
/*  58 */     Date d = parseDate(fieldValue);
/*     */ 
/*  60 */     populateTempoDatetimeFieldWithDate(fieldLayout, d);
/*  61 */     populateTempoDatetimeFieldWithTime(fieldLayout, d);
/*  62 */     unfocus();
/*     */   }
/*     */ 
/*     */   public String capture(WebElement fieldLayout, String[] params)
/*     */   {
/*  67 */     String dateString = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_DATETIME_FIELD_DATE_INPUT)).getAttribute("value");
/*  68 */     String timeString = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_DATETIME_FIELD_TIME_INPUT)).getAttribute("value");
/*     */ 
/*  70 */     String value = dateString + " " + timeString;
/*  71 */     if (LOG.isDebugEnabled()) LOG.debug("DATE FIELD VALUE [" + value + "]");
/*     */ 
/*  73 */     return value;
/*     */   }
/*     */ 
/*     */   public boolean contains(WebElement fieldLayout, String[] params) throws ParseException
/*     */   {
/*  78 */     String fieldValue = getParam(0, params);
/*     */ 
/*  80 */     String datetimeString = capture(fieldLayout, new String[0]);
/*     */ 
/*  82 */     Date compareDate = parseDate(datetimeString);
/*  83 */     Date fieldDate = parseDate(fieldValue);
/*  84 */     LOG.debug("DATETIME FIELD COMPARISON : Field value [" + fieldDate.toString() + "] compared to Entered value [" + fieldDate.toString() + "]");
/*     */ 
/*  87 */     return DateUtils.isSameInstant(compareDate, fieldDate);
/*     */   }
/*     */ 
/*     */   private void populateTempoDatetimeFieldWithDate(WebElement fieldLayout, Date d) {
/*  91 */     String dateValue = new SimpleDateFormat(this.settings.getDateFormat()).format(d);
/*     */ 
/*  93 */     WebElement datePlaceholder = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_DATETIME_FIELD_DATE_PLACEHOLDER));
/*  94 */     WebElement dateField = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_DATETIME_FIELD_DATE_INPUT));
/*     */ 
/*  97 */     if (dateField.isDisplayed()) {
/*  98 */       dateField.click();
/*  99 */       CrossPlatformUtilities.selectAll(dateField);
/* 100 */       dateField.sendKeys(new CharSequence[] { Keys.DELETE });
/* 101 */       dateField.sendKeys(new CharSequence[] { dateValue });
/*     */     } else {
/* 103 */       datePlaceholder.click();
/* 104 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOf(dateField));
/* 105 */       dateField.sendKeys(new CharSequence[] { dateValue });
/*     */     }
/*     */   }
/*     */ 
/*     */   private void populateTempoDatetimeFieldWithTime(WebElement fieldLayout, Date d) {
/* 110 */     String timeValue = new SimpleDateFormat(this.settings.getTimeFormat()).format(d);
/*     */ 
/* 112 */     WebElement timePlaceholder = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_DATETIME_FIELD_TIME_PLACEHOLDER));
/* 113 */     WebElement timeField = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_DATETIME_FIELD_TIME_INPUT));
/*     */ 
/* 116 */     if (timeField.isDisplayed()) {
/* 117 */       timeField.click();
/* 118 */       CrossPlatformUtilities.selectAll(timeField);
/* 119 */       timeField.sendKeys(new CharSequence[] { Keys.DELETE });
/* 120 */       timeField.sendKeys(new CharSequence[] { timeValue });
/*     */     } else {
/* 122 */       timePlaceholder.click();
/* 123 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOf(timeField));
/* 124 */       timeField.sendKeys(new CharSequence[] { timeValue });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear(WebElement fieldLayout, String[] params)
/*     */   {
/*     */   }
/*     */ 
/*     */   public static boolean isType(WebElement fieldLayout)
/*     */   {
/*     */     try {
/* 135 */       fieldLayout.findElement(By.xpath(XPATH_RELATIVE_DATETIME_FIELD_DATE_INPUT));
/* 136 */       fieldLayout.findElement(By.xpath(XPATH_RELATIVE_DATETIME_FIELD_TIME_INPUT));
/*     */     } catch (Exception e) {
/* 138 */       return false;
/*     */     }
/*     */ 
/* 141 */     return true;
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoDatetimeField
 * JD-Core Version:    0.6.2
 */