/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoRadioFieldOption extends TempoRadioField
/*    */   implements Clickable
/*    */ {
/* 15 */   private static final Logger LOG = Logger.getLogger(TempoRadioFieldOption.class);
/* 16 */   private static final String XPATH_ABSOLUTE_RADIO_FIELD_OPTION = Settings.getByConstant("xpathAbsoluteRadioFieldOption");
/* 17 */   private static final String XPATH_ABSOLUTE_RADIO_FIELD_OPTION_INDEX = "(" + XPATH_ABSOLUTE_RADIO_FIELD_OPTION + ")[%2$d]";
/*    */ 
/*    */   public static TempoRadioFieldOption getInstance(Settings settings) {
/* 20 */     return new TempoRadioFieldOption(settings);
/*    */   }
/*    */ 
/*    */   private TempoRadioFieldOption(Settings settings) {
/* 24 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 29 */     String optionName = getParam(0, params);
/*    */ 
/* 31 */     if (isFieldIndex(optionName)) {
/* 32 */       String oName = getFieldFromFieldIndex(optionName);
/* 33 */       int index = getIndexFromFieldIndex(optionName);
/* 34 */       return xpathFormat(XPATH_ABSOLUTE_RADIO_FIELD_OPTION_INDEX, new Object[] { oName, Integer.valueOf(index) });
/*    */     }
/* 36 */     return xpathFormat(XPATH_ABSOLUTE_RADIO_FIELD_OPTION, new Object[] { optionName });
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 42 */     String optionName = getParam(0, params);
/*    */ 
/* 44 */     if (LOG.isDebugEnabled()) LOG.debug("RADIO BUTTON OPTION CLICK : " + optionName);
/*    */     try
/*    */     {
/* 47 */       WebElement option = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 48 */       clickElement(option);
/*    */     } catch (Exception e) {
/* 50 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Radio option", optionName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 56 */     String optionName = getParam(0, params);
/*    */ 
/* 58 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR RADIO BUTTON OPTION CLICK : " + optionName);
/*    */     try
/*    */     {
/* 61 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/* 62 */         .until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     }
/*    */     catch (Exception e) {
/* 64 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Radio option", optionName });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoRadioFieldOption
 * JD-Core Version:    0.6.2
 */