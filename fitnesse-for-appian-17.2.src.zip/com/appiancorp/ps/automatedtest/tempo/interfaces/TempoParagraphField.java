/*     */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import com.appiancorp.ps.automatedtest.properties.Container;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoParagraphField extends AbstractTempoField
/*     */   implements Container
/*     */ {
/*  16 */   private static final Logger LOG = Logger.getLogger(TempoParagraphField.class);
/*  17 */   private static final String XPATH_ABSOLUTE_PARAGRAPH_FIELD_LABEL = Settings.getByConstant("xpathAbsoluteParagraphFieldLabel");
/*  18 */   private static final String XPATH_ABSOLUTE_PARAGRAPH_FIELD_INDEX = Settings.getByConstant("xpathAbsoluteParagraphFieldIndex");
/*  19 */   private static final String XPATH_ABSOLUTE_PARAGRAPH_FIELD_LABEL_INDEX = "(" + XPATH_ABSOLUTE_PARAGRAPH_FIELD_LABEL + ")[%2$d]";
/*  20 */   private static final String XPATH_RELATIVE_PARAGRAPH_FIELD_INPUT = Settings.getByConstant("xpathRelativeParagraphFieldInput");
/*     */ 
/*     */   public static TempoParagraphField getInstance(Settings settings) {
/*  23 */     return new TempoParagraphField(settings);
/*     */   }
/*     */ 
/*     */   private TempoParagraphField(Settings settings) {
/*  27 */     super(settings);
/*     */   }
/*     */ 
/*     */   public String getXpath(String[] params)
/*     */   {
/*  32 */     String fieldName = getParam(0, params);
/*     */ 
/*  34 */     if (isFieldIndex(fieldName)) {
/*  35 */       int index = getIndexFromFieldIndex(fieldName);
/*  36 */       String name = getFieldFromFieldIndex(fieldName);
/*  37 */       if (StringUtils.isBlank(name)) {
/*  38 */         return xpathFormat(XPATH_ABSOLUTE_PARAGRAPH_FIELD_INDEX + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { Integer.valueOf(index) });
/*     */       }
/*  40 */       return xpathFormat(XPATH_ABSOLUTE_PARAGRAPH_FIELD_LABEL_INDEX + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { name, 
/*  41 */         Integer.valueOf(index) });
/*     */     }
/*     */ 
/*  44 */     return xpathFormat(XPATH_ABSOLUTE_PARAGRAPH_FIELD_LABEL + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { fieldName });
/*     */   }
/*     */ 
/*     */   public void waitFor(String[] params)
/*     */   {
/*  50 */     String fieldName = getParam(0, params);
/*     */ 
/*  52 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR [" + fieldName + "]");
/*     */     try
/*     */     {
/*  55 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/*  56 */         .until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*     */     }
/*     */     catch (Exception e) {
/*  58 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Field", fieldName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void populate(WebElement fieldLayout, String[] params) throws InterruptedException
/*     */   {
/*  64 */     String fieldValue = getParam(1, params);
/*     */ 
/*  66 */     if (LOG.isDebugEnabled()) LOG.debug("POPULATION [" + fieldValue + "]");
/*     */ 
/*  68 */     WebElement textAreaField = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_PARAGRAPH_FIELD_INPUT));
/*  69 */     textAreaField.clear();
/*  70 */     textAreaField.sendKeys(new CharSequence[] { fieldValue });
/*     */ 
/*  73 */     Thread.sleep(700L);
/*     */   }
/*     */ 
/*     */   public String capture(WebElement fieldLayout, String[] params)
/*     */   {
/*  78 */     String value = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_PARAGRAPH_FIELD_INPUT)).getAttribute("value");
/*  79 */     if (LOG.isDebugEnabled()) LOG.debug("PARAGRAPH FIELD VALUE : " + value);
/*     */ 
/*  81 */     return value;
/*     */   }
/*     */ 
/*     */   public boolean contains(WebElement fieldLayout, String[] params)
/*     */   {
/*  86 */     String fieldValue = getParam(0, params);
/*     */     try
/*     */     {
/*  90 */       return TempoFieldFactory.getInstance(this.settings).contains(fieldLayout, new String[] { fieldValue });
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*  95 */       String compareString = capture(fieldLayout, new String[0]);
/*  96 */       if (LOG.isDebugEnabled()) {
/*  97 */         LOG.debug("PARAGRAPH FIELD COMPARISON : Field value [" + fieldValue + "] compared to Entered value [" + compareString + "]");
/*     */       }
/*  99 */       return compareString.contains(fieldValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear(WebElement fieldLayout, String[] params) {
/* 104 */     WebElement textAreaField = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_PARAGRAPH_FIELD_INPUT));
/* 105 */     textAreaField.clear();
/*     */   }
/*     */ 
/*     */   public static boolean isType(WebElement fieldLayout) {
/*     */     try {
/* 110 */       fieldLayout.findElement(By.xpath(XPATH_RELATIVE_PARAGRAPH_FIELD_INPUT));
/*     */     } catch (Exception e) {
/* 112 */       return false;
/*     */     }
/*     */ 
/* 115 */     return true;
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoParagraphField
 * JD-Core Version:    0.6.2
 */