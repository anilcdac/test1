/*     */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.common.Version;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoCheckboxField extends AbstractTempoField
/*     */ {
/*  19 */   private static final Logger LOG = Logger.getLogger(TempoCheckboxField.class);
/*  20 */   private static final String XPATH_ABSOLUTE_CHECKBOX_FIELD_LABEL = Settings.getByConstant("xpathAbsoluteCheckboxFieldLabel");
/*  21 */   private static final String XPATH_ABSOLUTE_CHECKBOX_FIELD_INDEX = Settings.getByConstant("xpathAbsoluteCheckboxFieldIndex");
/*  22 */   private static final String XPATH_ABSOLUTE_CHECKBOX_FIELD_LABEL_INDEX = "(" + XPATH_ABSOLUTE_CHECKBOX_FIELD_LABEL + ")[%d]";
/*  23 */   private static final String XPATH_RELATIVE_CHECKBOX_FIELD_CHOICE_LABEL = Settings.getByConstant("xpathRelativeCheckboxFieldChoiceLabel");
/*  24 */   private static final String XPATH_RELATIVE_CHECKBOX_FIELD_CHOICE_INDEX = Settings.getByConstant("xpathRelativeCheckboxFieldChoiceIndex");
/*  25 */   private static final String XPATH_RELATIVE_CHECKBOX_FIELD_INPUT = Settings.getByConstant("xpathRelativeCheckboxFieldInput");
/*  26 */   private static final String XPATH_RELATIVE_CHECKBOX_FIELD_INPUT_SPAN = Settings.getByConstant("xpathRelativeCheckboxFieldInputSpan");
/*     */ 
/*     */   public static TempoCheckboxField getInstance(Settings settings) {
/*  29 */     return new TempoCheckboxField(settings);
/*     */   }
/*     */ 
/*     */   protected TempoCheckboxField(Settings settings) {
/*  33 */     super(settings);
/*     */   }
/*     */ 
/*     */   public String getXpath(String[] params)
/*     */   {
/*  38 */     String fieldName = getParam(0, params);
/*     */ 
/*  40 */     if (isFieldIndex(fieldName)) {
/*  41 */       int index = getIndexFromFieldIndex(fieldName);
/*  42 */       String name = getFieldFromFieldIndex(fieldName);
/*  43 */       if (StringUtils.isBlank(name)) {
/*  44 */         return xpathFormat(XPATH_ABSOLUTE_CHECKBOX_FIELD_INDEX + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { Integer.valueOf(index) });
/*     */       }
/*  46 */       return xpathFormat(XPATH_ABSOLUTE_CHECKBOX_FIELD_LABEL_INDEX + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { name, 
/*  47 */         Integer.valueOf(index) });
/*     */     }
/*     */ 
/*  51 */     return xpathFormat(XPATH_ABSOLUTE_CHECKBOX_FIELD_LABEL + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { fieldName });
/*     */   }
/*     */ 
/*     */   public String getXpathForCheckbox(boolean isContains, String[] params)
/*     */   {
/*  56 */     String fieldValue = getParam(0, params);
/*  57 */     String fixFor17_1 = "";
/*     */ 
/*  59 */     if ((isContains) && (Settings.getVersion().compareTo(new Version(Integer.valueOf(17), Integer.valueOf(1))) >= 0)) {
/*  60 */       fixFor17_1 = "//input";
/*     */     }
/*     */ 
/*  63 */     if (isFieldIndex(fieldValue)) {
/*  64 */       int index = getIndexFromFieldIndex(fieldValue);
/*  65 */       return xpathFormat(XPATH_RELATIVE_CHECKBOX_FIELD_CHOICE_INDEX + fixFor17_1, new Object[] { Integer.valueOf(index) });
/*     */     }
/*  67 */     return xpathFormat(XPATH_RELATIVE_CHECKBOX_FIELD_CHOICE_LABEL + fixFor17_1, new Object[] { fieldValue });
/*     */   }
/*     */ 
/*     */   public void waitFor(String[] params)
/*     */   {
/*  73 */     String fieldName = getParam(0, params);
/*     */ 
/*  75 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR [" + fieldName + "]");
/*     */     try
/*     */     {
/*  78 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*     */     } catch (Exception e) {
/*  80 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Field", fieldName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void populate(WebElement fieldLayout, String[] params)
/*     */   {
/*  86 */     String fieldValue = getParam(1, params);
/*     */ 
/*  88 */     if (LOG.isDebugEnabled()) LOG.debug("POPULATION [" + fieldValue + "]");
/*     */ 
/*  90 */     WebElement checkboxField = fieldLayout.findElement(By.xpath(getXpathForCheckbox(false, new String[] { fieldValue })));
/*  91 */     checkboxField.click();
/*     */   }
/*     */ 
/*     */   public String capture(WebElement fieldLayout, String[] params)
/*     */   {
/*  96 */     List values = new ArrayList();
/*     */ 
/*  98 */     for (WebElement span : fieldLayout.findElements(By.xpath(XPATH_RELATIVE_CHECKBOX_FIELD_INPUT_SPAN))) {
/*  99 */       if (span.findElement(By.tagName("input")).isSelected()) {
/* 100 */         values.add(span.findElement(By.tagName("label")).getText());
/*     */       }
/*     */     }
/*     */ 
/* 104 */     if (LOG.isDebugEnabled()) LOG.debug("CHECKBOX FIELD VALUE : " + values.toString());
/*     */ 
/* 106 */     return String.join(",", values);
/*     */   }
/*     */ 
/*     */   public boolean contains(WebElement fieldLayout, String[] params)
/*     */   {
/* 111 */     String fieldValue = getParam(0, params);
/*     */     try
/*     */     {
/* 115 */       return TempoFieldFactory.getInstance(this.settings).contains(fieldLayout, new String[] { fieldValue });
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 121 */       WebElement checkbox = fieldLayout.findElement(By.xpath(getXpathForCheckbox(true, params)));
/* 122 */       boolean checked = checkbox.getAttribute("checked") != null;
/*     */ 
/* 124 */       if (LOG.isDebugEnabled()) LOG.debug("CONTAINS: Field value [" + fieldValue + "] is checked [" + checked + "]");
/*     */ 
/* 126 */       return checked;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isType(WebElement fieldLayout) {
/*     */     try { fieldLayout.findElement(By.xpath(XPATH_RELATIVE_CHECKBOX_FIELD_INPUT));
/*     */     } catch (Exception e) {
/* 133 */       return false;
/*     */     }
/*     */ 
/* 136 */     return true;
/*     */   }
/*     */ 
/*     */   public void clear(WebElement fieldLayout, String[] params)
/*     */   {
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoCheckboxField
 * JD-Core Version:    0.6.2
 */