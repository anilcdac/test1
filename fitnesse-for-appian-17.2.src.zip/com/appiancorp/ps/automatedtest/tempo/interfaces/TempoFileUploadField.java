/*     */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.common.Version;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.io.FilenameUtils;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.JavascriptExecutor;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoFileUploadField extends AbstractTempoField
/*     */ {
/*  22 */   private static final Logger LOG = Logger.getLogger(TempoFileUploadField.class);
/*  23 */   private static final String XPATH_ABSOLUTE_FILE_UPLOAD_FIELD_LABEL = Settings.getByConstant("xpathAbsoluteFileUploadFieldLabel");
/*  24 */   private static final String XPATH_ABSOLUTE_FILE_UPLOAD_FIELD_LABEL_INDEX = "(" + XPATH_ABSOLUTE_FILE_UPLOAD_FIELD_LABEL + ")[%2$d]";
/*  25 */   private static final String XPATH_ABSOLUTE_FILE_UPLOAD_FIELD_INDEX = Settings.getByConstant("xpathAbsoluteFileUploadFieldIndex");
/*  26 */   private static final String XPATH_RELATIVE_FILE_UPLOAD_FIELD_INPUT = Settings.getByConstant("xpathRelativeFileUploadFieldInput");
/*  27 */   private static final String XPATH_RELATIVE_FILE_UPLOAD_FIELD_FILE = Settings.getByConstant("xpathRelativeFileUploadFieldFile");
/*     */ 
/*  29 */   private static final String XPATH_RELATIVE_FILE_UPLOAD_FIELD_REMOVE_LINK = Settings.getByConstant("xpathRelativeFileUploadFieldRemoveLink")
/*  29 */     ;
/*     */ 
/*  31 */   private static final String XPATH_ABSOLUTE_FILE_UPLOAD_FIELD_WAITING = XPATH_ABSOLUTE_FILE_UPLOAD_FIELD_LABEL + 
/*  31 */     Settings.getByConstant("xpathRelativeFileUploadFieldWaiting")
/*  31 */     ;
/*  32 */   private static final Pattern FILENAME_PATTERN = Pattern.compile("(.*) \\(.*\\)");
/*     */ 
/*     */   public static TempoFileUploadField getInstance(Settings settings) {
/*  35 */     return new TempoFileUploadField(settings);
/*     */   }
/*     */ 
/*     */   private TempoFileUploadField(Settings settings) {
/*  39 */     super(settings);
/*     */   }
/*     */ 
/*     */   public String getXpath(String[] params)
/*     */   {
/*  44 */     String fieldName = getParam(0, params);
/*     */ 
/*  46 */     if (isFieldIndex(fieldName)) {
/*  47 */       int index = getIndexFromFieldIndex(fieldName);
/*  48 */       String name = getFieldFromFieldIndex(fieldName);
/*  49 */       if (StringUtils.isBlank(name)) {
/*  50 */         return xpathFormat(XPATH_ABSOLUTE_FILE_UPLOAD_FIELD_INDEX + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { Integer.valueOf(index) });
/*     */       }
/*  52 */       return xpathFormat(XPATH_ABSOLUTE_FILE_UPLOAD_FIELD_LABEL_INDEX + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { name, 
/*  53 */         Integer.valueOf(index) });
/*     */     }
/*     */ 
/*  57 */     return xpathFormat(XPATH_ABSOLUTE_FILE_UPLOAD_FIELD_LABEL + TempoFieldFactory.XPATH_CONCAT_ANCESTOR_FIELD_LAYOUT, new Object[] { fieldName });
/*     */   }
/*     */ 
/*     */   public void waitFor(String[] params)
/*     */   {
/*  63 */     String fieldName = getParam(0, params);
/*     */     try
/*     */     {
/*  66 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/*  67 */         .until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*     */     }
/*     */     catch (Exception e) {
/*  69 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Field", fieldName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void populate(WebElement fieldLayout, String[] params)
/*     */   {
/*  75 */     String fieldValue = FilenameUtils.separatorsToSystem(getParam(1, params));
/*     */ 
/*  77 */     if (LOG.isDebugEnabled()) LOG.debug("POPULATION [" + fieldValue + "]");
/*     */ 
/*  79 */     WebElement fileUpload = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_FILE_UPLOAD_FIELD_INPUT));
/*  80 */     toggleVisibilityForAppian17_1(fileUpload);
/*  81 */     fileUpload.sendKeys(new CharSequence[] { fieldValue });
/*  82 */     unfocus(Integer.valueOf(300));
/*  83 */     waitForFileUpload(fieldLayout);
/*     */   }
/*     */ 
/*     */   private void toggleVisibilityForAppian17_1(WebElement fileUpload) {
/*  87 */     if (fileUpload.getAttribute("class").equals("FileUploadWidget---ui-inaccessible")) {
/*  88 */       String fileUploadId = fileUpload.getAttribute("id");
/*  89 */       JavascriptExecutor jsExecutor = (JavascriptExecutor)this.settings.getDriver();
/*  90 */       jsExecutor.executeScript("document.getElementById('" + fileUploadId + "').setAttribute('class', '')", new Object[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void waitForFileUpload(WebElement fieldLayout) {
/*  95 */     String xpathLocator = getXpathLocator(fieldLayout);
/*  96 */     new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/*  97 */       .until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("(" + xpathLocator + ")" + XPATH_ABSOLUTE_FILE_UPLOAD_FIELD_WAITING)));
/*     */   }
/*     */ 
/*     */   public String capture(WebElement fieldLayout, String[] params)
/*     */   {
/* 104 */     String value = fieldLayout.findElement(By.xpath(xpathFormat(XPATH_RELATIVE_FILE_UPLOAD_FIELD_FILE, new Object[0]))).getText();
/* 105 */     Matcher m = FILENAME_PATTERN.matcher(value);
/*     */ 
/* 107 */     if (m.find()) {
/* 108 */       value = m.group(1);
/*     */     }
/*     */ 
/* 111 */     if (LOG.isDebugEnabled()) LOG.debug("FILE UPLOAD FIELD VALUE : " + value);
/*     */ 
/* 113 */     if (Settings.getVersion().compareTo(new Version(Integer.valueOf(17), Integer.valueOf(1))) >= 0) {
/* 114 */       String filename = value.split("\\n")[0];
/* 115 */       String extension = value.split("\\n")[1].split("\\s")[0];
/* 116 */       value = filename + "." + extension.toLowerCase();
/*     */     }
/*     */ 
/* 119 */     return value;
/*     */   }
/*     */ 
/*     */   public boolean contains(WebElement fieldLayout, String[] params)
/*     */   {
/* 124 */     String fieldValue = FilenameUtils.separatorsToSystem(getParam(0, params));
/*     */     try
/*     */     {
/* 128 */       return TempoFieldFactory.getInstance(this.settings).contains(fieldLayout, new String[] { fieldValue });
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 132 */       fieldValue = Paths.get(fieldValue, new String[0]).getFileName().toString();
/* 133 */       String compareString = FilenameUtils.separatorsToSystem(capture(fieldLayout, new String[0]));
/*     */ 
/* 135 */       if (LOG.isDebugEnabled()) {
/* 136 */         LOG.debug("FILE UPLOAD FIELD COMPARISON : Field value [" + fieldValue + "] compared to Entered value [" + compareString + "]");
/*     */       }
/* 138 */       return compareString.equals(fieldValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear(WebElement fieldLayout, String[] params) {
/* 143 */     WebElement removeLink = fieldLayout.findElement(By.xpath(XPATH_RELATIVE_FILE_UPLOAD_FIELD_REMOVE_LINK));
/* 144 */     removeLink.click();
/*     */   }
/*     */ 
/*     */   public static boolean isType(WebElement fieldLayout) {
/*     */     try {
/* 149 */       fieldLayout.findElement(By.xpath(XPATH_RELATIVE_FILE_UPLOAD_FIELD_INPUT));
/* 150 */       return true;
/*     */     } catch (Exception e) {
/*     */       try {
/* 153 */         fieldLayout.findElement(By.xpath(XPATH_RELATIVE_FILE_UPLOAD_FIELD_FILE));
/* 154 */         return true; } catch (Exception e2) {  }
/*     */     }
/* 156 */     return false;
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoFileUploadField
 * JD-Core Version:    0.6.2
 */