/*     */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.common.Version;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.WebElement;
/*     */ 
/*     */ public class TempoRadioField extends AbstractTempoField
/*     */ {
/*  15 */   private static final Logger LOG = Logger.getLogger(TempoRadioField.class);
/*     */ 
/*  17 */   private static final String XPATH_RELATIVE_RADIO_FIELD_CHOICE_LABEL = Settings.getByConstant("xpathRelativeRadioFieldChoiceLabel");
/*  18 */   private static final String XPATH_RELATIVE_RADIO_FIELD_CHOICE_INDEX = Settings.getByConstant("xpathRelativeRadioFieldChoiceIndex");
/*  19 */   private static final String XPATH_RELATIVE_RADIO_BUTTON_GROUP = Settings.getByConstant("xpathRelativeRadioButtonGroup");
/*  20 */   private static final String XPATH_RELATIVE_RADIO_FIELD_INPUT_SPAN = Settings.getByConstant("xpathRelativeRadioFieldInputSpan");
/*     */ 
/*     */   public static TempoRadioField getInstance(Settings settings) {
/*  23 */     return new TempoRadioField(settings);
/*     */   }
/*     */ 
/*     */   protected TempoRadioField(Settings settings) {
/*  27 */     super(settings);
/*     */   }
/*     */ 
/*     */   public void populate(WebElement fieldLayout, String[] params)
/*     */   {
/*  45 */     String fieldValue = getParam(1, params);
/*  46 */     String fixFor17_1 = "";
/*     */ 
/*  48 */     if (Settings.getVersion().compareTo(new Version(Integer.valueOf(17), Integer.valueOf(1))) >= 0) {
/*  49 */       fixFor17_1 = "/parent::div/label";
/*     */     }
/*     */ 
/*  52 */     if (LOG.isDebugEnabled()) LOG.debug("POPULATION [" + fieldValue + "]");
/*     */     WebElement radioField;
/*     */     WebElement radioField;
/*  55 */     if (isFieldIndex(fieldValue)) {
/*  56 */       int index = getIndexFromFieldIndex(fieldValue);
/*  57 */       radioField = fieldLayout.findElement(By.xpath(xpathFormat(XPATH_RELATIVE_RADIO_FIELD_CHOICE_INDEX + fixFor17_1, new Object[] { Integer.valueOf(index) })));
/*     */     } else {
/*  59 */       radioField = fieldLayout.findElement(By.xpath(xpathFormat(XPATH_RELATIVE_RADIO_FIELD_CHOICE_LABEL + fixFor17_1, new Object[] { fieldValue })));
/*     */     }
/*  61 */     radioField.click();
/*     */   }
/*     */ 
/*     */   public String capture(WebElement fieldLayout, String[] params)
/*     */   {
/*  66 */     List values = new ArrayList();
/*     */ 
/*  68 */     for (WebElement span : fieldLayout.findElements(By.xpath(XPATH_RELATIVE_RADIO_FIELD_INPUT_SPAN))) {
/*  69 */       if (span.findElement(By.tagName("input")).isSelected()) {
/*  70 */         values.add(span.findElement(By.tagName("label")).getText());
/*     */       }
/*     */     }
/*     */ 
/*  74 */     if (LOG.isDebugEnabled()) LOG.debug("RADIO FIELD VALUE : " + values.toString());
/*     */ 
/*  76 */     return String.join(",", values);
/*     */   }
/*     */ 
/*     */   public boolean contains(WebElement fieldLayout, String[] params)
/*     */   {
/*  81 */     String fieldValue = getParam(0, params);
/*     */     try
/*     */     {
/*  85 */       return TempoFieldFactory.getInstance(this.settings).contains(fieldLayout, new String[] { fieldValue });
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*     */       String compareString;
/*     */       String compareString;
/*  91 */       if (isFieldIndex(fieldValue)) {
/*  92 */         int index = getIndexFromFieldIndex(fieldValue);
/*  93 */         compareString = fieldLayout.findElement(By.xpath(xpathFormat(XPATH_RELATIVE_RADIO_FIELD_CHOICE_INDEX, new Object[] { Integer.valueOf(index) }))).getAttribute("checked");
/*     */       }
/*     */       else {
/*  96 */         compareString = fieldLayout.findElement(By.xpath(xpathFormat(XPATH_RELATIVE_RADIO_FIELD_CHOICE_LABEL, new Object[] { fieldValue }))).getAttribute("checked");
/*     */       }
/*     */ 
/*  99 */       if (LOG.isDebugEnabled()) LOG.debug("RADIO FIELD COMPARISON : Field value [" + fieldValue + "] is checked [" + compareString + "]");
/*     */ 
/* 101 */       return compareString.equals("true");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isType(WebElement fieldLayout) {
/*     */     try { fieldLayout.findElement(By.xpath(XPATH_RELATIVE_RADIO_BUTTON_GROUP));
/*     */     } catch (Exception e) {
/* 108 */       return false;
/*     */     }
/*     */ 
/* 111 */     return true;
/*     */   }
/*     */ 
/*     */   public void clear(WebElement fieldLayout, String[] params)
/*     */   {
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoRadioField
 * JD-Core Version:    0.6.2
 */