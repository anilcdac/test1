/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ 
/*    */ public class TempoGridAddRow extends TempoGrid
/*    */   implements Clickable
/*    */ {
/* 13 */   private static final Logger LOG = Logger.getLogger(TempoGridAddRow.class);
/*    */ 
/* 15 */   private static final String XPATH_RELATIVE_GRID_ADD_ROW_LINK = Settings.getByConstant("xpathRelativeGridAddRowLink");
/*    */ 
/*    */   public static TempoGridAddRow getInstance(Settings settings) {
/* 18 */     return new TempoGridAddRow(settings);
/*    */   }
/*    */ 
/*    */   private TempoGridAddRow(Settings settings) {
/* 22 */     super(settings);
/*    */   }
/*    */ 
/*    */   public void click(String[] params) {
/* 26 */     String gridName = getParam(0, params);
/*    */     try
/*    */     {
/* 29 */       WebElement grid = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 30 */       WebElement link = grid.findElement(By.xpath(XPATH_RELATIVE_GRID_ADD_ROW_LINK));
/* 31 */       clickElement(link);
/*    */     } catch (Exception e) {
/* 33 */       LOG.error("Click Add Row", e);
/* 34 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Click Add Row", gridName });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridAddRow
 * JD-Core Version:    0.6.2
 */