/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebElement;
/*    */ 
/*    */ public class TempoGridSelectAll extends TempoGrid
/*    */   implements Clickable
/*    */ {
/* 13 */   private static final Logger LOG = Logger.getLogger(TempoGridSelectAll.class);
/* 14 */   private static final String XPATH_RELATIVE_GRID_SELECT_ALL_CHECKBOX = Settings.getByConstant("xpathRelativeGridSelectAllColumn");
/*    */ 
/*    */   public static TempoGridSelectAll getInstance(Settings settings) {
/* 17 */     return new TempoGridSelectAll(settings);
/*    */   }
/*    */ 
/*    */   private TempoGridSelectAll(Settings settings) {
/* 21 */     super(settings);
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 26 */     String gridName = getParam(0, params);
/*    */ 
/* 28 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK SELECT ALL [" + gridName + "]");
/*    */     try
/*    */     {
/* 31 */       WebElement grid = getWebElement(params);
/* 32 */       WebElement checkboxColumn = grid.findElement(By.xpath(XPATH_RELATIVE_GRID_SELECT_ALL_CHECKBOX));
/* 33 */       clickElement(checkboxColumn);
/*    */     } catch (Exception e) {
/* 35 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Select All ", gridName });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridSelectAll
 * JD-Core Version:    0.6.2
 */