/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitFor;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitForReturn;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.TimeoutException;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoButton extends AppianObject
/*    */   implements WaitFor, WaitForReturn, Clickable
/*    */ {
/* 19 */   private static final Logger LOG = Logger.getLogger(TempoButton.class);
/* 20 */   private static final String XPATH_ABSOLUTE_BUTTON = Settings.getByConstant("xpathAbsoluteButton");
/* 21 */   private static final String XPATH_ABSOLUTE_BUTTON_INDEX = "(" + XPATH_ABSOLUTE_BUTTON + ")[%2$d]";
/*    */ 
/*    */   public static TempoButton getInstance(Settings settings) {
/* 24 */     return new TempoButton(settings);
/*    */   }
/*    */ 
/*    */   private TempoButton(Settings settings) {
/* 28 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 33 */     String button = getParam(0, params);
/*    */ 
/* 35 */     if (isFieldIndex(button)) {
/* 36 */       int rNum = getIndexFromFieldIndex(button);
/* 37 */       String rName = getFieldFromFieldIndex(button);
/* 38 */       return xpathFormat(XPATH_ABSOLUTE_BUTTON_INDEX, new Object[] { rName, Integer.valueOf(rNum) });
/*    */     }
/* 40 */     return xpathFormat(XPATH_ABSOLUTE_BUTTON, new Object[] { button });
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 46 */     String buttonName = getParam(0, params);
/*    */ 
/* 48 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR BUTTON [" + buttonName + "]");
/*    */     try
/*    */     {
/* 51 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/* 52 */         .until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     }
/*    */     catch (Exception e) {
/* 54 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Button", buttonName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(int timeout, String[] params)
/*    */   {
/* 60 */     String buttonName = getParam(0, params);
/*    */ 
/* 62 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR BUTTON [" + buttonName + "]");
/*    */     try
/*    */     {
/* 65 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/* 66 */       return true;
/*    */     } catch (TimeoutException e) {
/* 68 */       return false;
/*    */     } catch (Exception e) {
/* 70 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Button", buttonName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(String[] params)
/*    */   {
/* 76 */     return waitForReturn(this.settings.getTimeoutSeconds(), params);
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 81 */     String buttonName = getParam(0, params);
/*    */ 
/* 83 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK BUTTON [" + buttonName + "]");
/*    */     try
/*    */     {
/* 86 */       WebElement button = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 87 */       clickElement(button);
/*    */     } catch (Exception e) {
/* 89 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Click Button", buttonName });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoButton
 * JD-Core Version:    0.6.2
 */