/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebElement;
/*    */ 
/*    */ public class TempoSectionToggle extends TempoSection
/*    */   implements Clickable
/*    */ {
/* 13 */   private static final Logger LOG = Logger.getLogger(TempoSectionToggle.class);
/*    */ 
/* 15 */   protected static final String XPATH_RELATIVE_SECTION_TOGGLE = Settings.getByConstant("xpathRelativeSectionToggle");
/*    */ 
/*    */   public static TempoSectionToggle getInstance(Settings settings) {
/* 18 */     return new TempoSectionToggle(settings);
/*    */   }
/*    */ 
/*    */   protected TempoSectionToggle(Settings settings) {
/* 22 */     super(settings);
/*    */   }
/*    */ 
/*    */   public void click(String[] params) {
/* 26 */     String sectionName = getParam(0, params);
/*    */ 
/* 28 */     if (LOG.isDebugEnabled()) LOG.debug("EXPAND SECTION [" + sectionName + "]");
/*    */     try
/*    */     {
/* 31 */       WebElement section = getWebElement(new String[] { sectionName });
/* 32 */       WebElement expand = section.findElement(By.xpath(XPATH_RELATIVE_SECTION_TOGGLE));
/* 33 */       clickElement(expand);
/*    */     } catch (Exception e) {
/* 35 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Expand Section", sectionName });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoSectionToggle
 * JD-Core Version:    0.6.2
 */