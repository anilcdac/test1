/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebElement;
/*    */ 
/*    */ public class TempoGridNavigation extends TempoGrid
/*    */   implements Clickable
/*    */ {
/* 13 */   private static final Logger LOG = Logger.getLogger(TempoGridNavigation.class);
/* 14 */   private static final String XPATH_RELATIVE_GRID_FIRST_PAGE_LINK = Settings.getByConstant("xpathRelativeGridFirstPageLink");
/* 15 */   private static final String XPATH_RELATIVE_GRID_PREVIOUS_PAGE_LINK = Settings.getByConstant("xpathRelativeGridPreviousPageLink");
/* 16 */   private static final String XPATH_RELATIVE_GRID_NEXT_PAGE_LINK = Settings.getByConstant("xpathRelativeGridNextPageLink");
/* 17 */   private static final String XPATH_RELATIVE_GRID_LAST_PAGE_LINK = Settings.getByConstant("xpathRelativeGridLastPageLink");
/* 18 */   protected static final String XPATH_RELATIVE_GRID_PAGING_LABEL = Settings.getByConstant("xpathRelativeGridPagingLabel");
/*    */ 
/*    */   public static TempoGridNavigation getInstance(Settings settings) {
/* 21 */     return new TempoGridNavigation(settings);
/*    */   }
/*    */ 
/*    */   protected TempoGridNavigation(Settings settings) {
/* 25 */     super(settings);
/*    */   }
/*    */ 
/*    */   public void click(String[] params) {
/* 29 */     String gridName = getParam(0, params);
/* 30 */     String navOption = getParam(1, params);
/*    */ 
/* 32 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK GRID [" + gridName + "] NAVIGATION [" + navOption + "]");
/*    */     try
/*    */     {
/* 35 */       navOption = navOption.toLowerCase();
/*    */ 
/* 37 */       WebElement grid = getWebElement(params);
/* 38 */       WebElement link = null;
/*    */ 
/* 40 */       switch (navOption) {
/*    */       case "first":
/* 42 */         link = grid.findElement(By.xpath(XPATH_RELATIVE_GRID_FIRST_PAGE_LINK));
/* 43 */         break;
/*    */       case "next":
/* 45 */         link = grid.findElement(By.xpath(XPATH_RELATIVE_GRID_NEXT_PAGE_LINK));
/* 46 */         break;
/*    */       case "previous":
/* 48 */         link = grid.findElement(By.xpath(XPATH_RELATIVE_GRID_PREVIOUS_PAGE_LINK));
/* 49 */         break;
/*    */       case "last":
/* 51 */         link = grid.findElement(By.xpath(XPATH_RELATIVE_GRID_LAST_PAGE_LINK));
/* 52 */         break;
/*    */       default:
/* 54 */         throw new IllegalArgumentException("Invalid navigation option");
/*    */       }
/* 56 */       clickElement(link);
/*    */     } catch (Exception e) {
/* 58 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Click Navigation option", navOption });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridNavigation
 * JD-Core Version:    0.6.2
 */