/*    */ package com.appiancorp.ps.automatedtest.tempo.interfaces;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.common.Version;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import com.appiancorp.ps.automatedtest.properties.Countable;
/*    */ import com.appiancorp.ps.automatedtest.properties.Verifiable;
/*    */ import java.util.List;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ 
/*    */ public class TempoGridRow extends TempoGridCell
/*    */   implements Clickable, Verifiable, Countable
/*    */ {
/* 17 */   private static final Logger LOG = Logger.getLogger(TempoGridRow.class);
/* 18 */   private static final String XPATH_RELATIVE_GRID_CHECKBOX = Settings.getByConstant("xpathRelativeGridCheckbox");
/* 19 */   private static final String XPATH_RELATIVE_GRID_ROW = Settings.getByConstant("xpathRelativeGridRow");
/*    */ 
/*    */   public static TempoGridRow getInstance(Settings settings) {
/* 22 */     return new TempoGridRow(settings);
/*    */   }
/*    */ 
/*    */   protected TempoGridRow(Settings settings) {
/* 26 */     super(settings);
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 31 */     String gridName = getParam(0, params);
/* 32 */     String rowNum = getParam(1, params);
/*    */     try
/*    */     {
/* 35 */       WebElement cell = this.settings.getDriver().findElement(By.xpath(getXpath(new String[] { gridName, "[1]", rowNum })));
/* 36 */       WebElement checkbox = cell.findElement(By.xpath(XPATH_RELATIVE_GRID_CHECKBOX));
/* 37 */       clickElement(checkbox);
/*    */     } catch (Exception e) {
/* 39 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Grid Row Selection", gridName, rowNum });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean contains(String[] params)
/*    */   {
/* 45 */     String gridName = getParam(0, params);
/* 46 */     String rowNum = getParam(1, params);
/*    */     try
/*    */     {
/* 49 */       WebElement cell = this.settings.getDriver().findElement(By.xpath(getXpath(new String[] { gridName, "[1]", rowNum })));
/* 50 */       WebElement checkbox = cell.findElement(By.xpath(XPATH_RELATIVE_GRID_CHECKBOX));
/*    */ 
/* 52 */       if (Settings.getVersion().compareTo(new Version(Integer.valueOf(17), Integer.valueOf(1))) >= 0) {
/* 53 */         checkbox = cell.findElement(By.xpath(XPATH_RELATIVE_GRID_CHECKBOX + "//input"));
/*    */       }
/*    */ 
/* 56 */       return checkbox.isSelected();
/*    */     } catch (Exception e) {
/* 58 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Grid Row Selected", gridName, rowNum });
/*    */     }
/*    */   }
/*    */ 
/*    */   public Integer count(String[] params)
/*    */   {
/* 64 */     String gridName = getParam(0, params);
/*    */     try
/*    */     {
/* 67 */       WebElement grid = this.settings.getDriver().findElement(By.xpath(getXpath(new String[] { gridName })));
/* 68 */       return Integer.valueOf(grid.findElements(By.xpath(XPATH_RELATIVE_GRID_ROW)).size());
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 72 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Grid Row Count", gridName });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridRow
 * JD-Core Version:    0.6.2
 */