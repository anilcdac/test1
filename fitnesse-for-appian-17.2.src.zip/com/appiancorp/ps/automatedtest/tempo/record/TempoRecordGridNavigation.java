/*    */ package com.appiancorp.ps.automatedtest.tempo.record;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoRecordGridNavigation extends AppianObject
/*    */   implements Clickable
/*    */ {
/* 17 */   private static final Logger LOG = Logger.getLogger(TempoRecord.class);
/* 18 */   private static final String XPATH_ABSOLUTE_RECORD_GRID_NAVIGATION_FIRST = Settings.getByConstant("xpathAbsoluteRecordGridNavigationFirst");
/* 19 */   private static final String XPATH_ABSOLUTE_RECORD_GRID_NAVIGATION_PREVIOUS = Settings.getByConstant("xpathAbsoluteRecordGridNavigationPrevious");
/* 20 */   private static final String XPATH_ABSOLUTE_RECORD_GRID_NAVIGATION_NEXT = Settings.getByConstant("xpathAbsoluteRecordGridNavigationNext");
/* 21 */   private static final String XPATH_ABSOLUTE_RECORD_GRID_NAVIGATION_LAST = Settings.getByConstant("xpathAbsoluteRecordGridNavigationLast");
/*    */ 
/*    */   public static TempoRecordGridNavigation getInstance(Settings settings) {
/* 24 */     return new TempoRecordGridNavigation(settings);
/*    */   }
/*    */ 
/*    */   private TempoRecordGridNavigation(Settings settings) {
/* 28 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 33 */     String navOption = getParam(0, params);
/*    */ 
/* 35 */     navOption = navOption.toLowerCase();
/* 36 */     switch (navOption) {
/*    */     case "first":
/* 38 */       return XPATH_ABSOLUTE_RECORD_GRID_NAVIGATION_FIRST;
/*    */     case "previous":
/* 40 */       return XPATH_ABSOLUTE_RECORD_GRID_NAVIGATION_PREVIOUS;
/*    */     case "next":
/* 42 */       return XPATH_ABSOLUTE_RECORD_GRID_NAVIGATION_NEXT;
/*    */     case "last":
/* 44 */       return XPATH_ABSOLUTE_RECORD_GRID_NAVIGATION_LAST;
/*    */     }
/* 46 */     throw new IllegalArgumentException("Invalid navigation option");
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 52 */     String navOption = getParam(0, params);
/*    */ 
/* 54 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR NAVIGATION [" + navOption + "]");
/*    */     try
/*    */     {
/* 57 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 59 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Record Navigation", navOption });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 66 */     String navOption = getParam(0, params);
/*    */ 
/* 68 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK ON NAVIGATION [" + navOption + "]");
/*    */     try
/*    */     {
/* 71 */       navOption = navOption.toLowerCase();
/* 72 */       WebElement link = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 73 */       clickElement(link);
/*    */     } catch (Exception e) {
/* 75 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Click Record Navigation", navOption });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.record.TempoRecordGridNavigation
 * JD-Core Version:    0.6.2
 */