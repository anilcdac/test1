/*    */ package com.appiancorp.ps.automatedtest.tempo.record;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import com.appiancorp.ps.automatedtest.properties.Refreshable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.TimeoutException;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoRecordRelatedAction extends AppianObject
/*    */   implements Clickable, Refreshable
/*    */ {
/* 18 */   private static final Logger LOG = Logger.getLogger(TempoRecordRelatedAction.class);
/* 19 */   private static final String XPATH_ABSOLUTE_RECORD_RELATED_ACTION_LINK = Settings.getByConstant("xpathAbsoluteRecordRelatedActionLink");
/*    */ 
/*    */   public static TempoRecordRelatedAction getInstance(Settings settings) {
/* 22 */     return new TempoRecordRelatedAction(settings);
/*    */   }
/*    */ 
/*    */   private TempoRecordRelatedAction(Settings settings) {
/* 26 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 31 */     String relatedAction = getParam(0, params);
/*    */ 
/* 33 */     return xpathFormat(XPATH_ABSOLUTE_RECORD_RELATED_ACTION_LINK, new Object[] { relatedAction });
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 38 */     String relatedAction = getParam(0, params);
/*    */ 
/* 40 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK ON RELATED ACTION [" + relatedAction + "]");
/*    */     try
/*    */     {
/* 43 */       WebElement element = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 44 */       clickElement(element);
/*    */     } catch (Exception e) {
/* 46 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Record Related Action", relatedAction });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 52 */     String relatedAction = getParam(0, params);
/*    */ 
/* 54 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR RELATED ACTION [" + relatedAction + "]");
/*    */     try
/*    */     {
/* 57 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 59 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Record Related Action", relatedAction });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(int timeout, String[] params)
/*    */   {
/* 65 */     String relatedAction = getParam(0, params);
/*    */     try
/*    */     {
/* 68 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/* 69 */       return true;
/*    */     } catch (TimeoutException e) {
/* 71 */       return false;
/*    */     } catch (Exception e) {
/* 73 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Record Related Action", relatedAction });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(String[] params)
/*    */   {
/* 79 */     return waitForReturn(this.settings.getTimeoutSeconds(), params);
/*    */   }
/*    */ 
/*    */   public void refreshAndWaitFor(String[] params)
/*    */   {
/* 84 */     int i = 0;
/* 85 */     while (i < this.settings.getRefreshTimes().intValue())
/*    */     {
/* 87 */       if (i < this.settings.getRefreshTimes().intValue() - 1) {
/* 88 */         if (waitForReturn(params))
/* 89 */           break;
/*    */       }
/*    */       else
/* 92 */         waitFor(params);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.record.TempoRecordRelatedAction
 * JD-Core Version:    0.6.2
 */