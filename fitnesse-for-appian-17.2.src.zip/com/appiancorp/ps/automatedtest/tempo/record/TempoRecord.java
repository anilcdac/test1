/*     */ package com.appiancorp.ps.automatedtest.tempo.record;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*     */ import com.appiancorp.ps.automatedtest.properties.Refreshable;
/*     */ import com.appiancorp.ps.automatedtest.properties.RegexCaptureable;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.TimeoutException;
/*     */ import org.openqa.selenium.WebDriver;
/*     */ import org.openqa.selenium.WebDriver.Navigation;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoRecord extends AppianObject
/*     */   implements Clickable, Refreshable, RegexCaptureable
/*     */ {
/*  20 */   private static final Logger LOG = Logger.getLogger(TempoRecord.class);
/*  21 */   private static final String XPATH_ABSOLUTE_RECORD_LINK = Settings.getByConstant("xpathAbsoluteRecordLink");
/*  22 */   private static final String XPATH_ABSOLUTE_RECORD_LINK_INDEX = "(" + XPATH_ABSOLUTE_RECORD_LINK + ")[%2$d]";
/*  23 */   private static final String XPATH_ABSOLUTE_RECORD_INDEX = Settings.getByConstant("xpathAbsoluteRecordIndexLink");
/*     */ 
/*     */   public static TempoRecord getInstance(Settings settings) {
/*  26 */     return new TempoRecord(settings);
/*     */   }
/*     */ 
/*     */   private TempoRecord(Settings settings) {
/*  30 */     super(settings);
/*     */   }
/*     */ 
/*     */   public String getXpath(String[] params)
/*     */   {
/*  35 */     String record = getParam(0, params);
/*     */ 
/*  37 */     if (isFieldIndex(record)) {
/*  38 */       int rNum = getIndexFromFieldIndex(record);
/*  39 */       String rName = getFieldFromFieldIndex(record);
/*  40 */       if (StringUtils.isBlank(rName)) {
/*  41 */         return xpathFormat(XPATH_ABSOLUTE_RECORD_INDEX, new Object[] { Integer.valueOf(rNum) });
/*     */       }
/*  43 */       return xpathFormat(XPATH_ABSOLUTE_RECORD_LINK_INDEX, new Object[] { rName, Integer.valueOf(rNum) });
/*     */     }
/*     */ 
/*  46 */     return xpathFormat(XPATH_ABSOLUTE_RECORD_LINK, new Object[] { record });
/*     */   }
/*     */ 
/*     */   public void click(String[] params)
/*     */   {
/*  52 */     String itemName = getParam(0, params);
/*     */ 
/*  54 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK RECORD [" + itemName + "]");
/*     */     try
/*     */     {
/*  57 */       WebElement element = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/*  58 */       clickElement(element);
/*     */     } catch (Exception e) {
/*  60 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Record", itemName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void waitFor(String[] params)
/*     */   {
/*  66 */     String itemName = getParam(0, params);
/*     */ 
/*  68 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR RECORD [" + itemName + "]");
/*     */     try
/*     */     {
/*  71 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/*  72 */         .until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*     */     }
/*     */     catch (Exception e) {
/*  74 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Record", itemName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean waitForReturn(int timeout, String[] params)
/*     */   {
/*  80 */     String itemName = getParam(0, params);
/*     */ 
/*  82 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR RECORD [" + itemName + "]");
/*     */     try
/*     */     {
/*  85 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*  86 */       return true;
/*     */     } catch (TimeoutException e) {
/*  88 */       return false;
/*     */     } catch (Exception e) {
/*  90 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Record", itemName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean waitForReturn(String[] params)
/*     */   {
/*  96 */     return waitForReturn(this.settings.getTimeoutSeconds(), params);
/*     */   }
/*     */ 
/*     */   public void refreshAndWaitFor(String[] params)
/*     */   {
/* 101 */     int i = 0;
/* 102 */     while (i < this.settings.getRefreshTimes().intValue())
/*     */     {
/* 104 */       if (i < this.settings.getRefreshTimes().intValue() - 1) {
/* 105 */         if (waitForReturn(params)) {
/*     */           break;
/*     */         }
/* 108 */         this.settings.getDriver().navigate().refresh();
/*     */       } else {
/* 110 */         waitFor(params);
/*     */       }
/* 112 */       i++;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String regexCapture(String regex, Integer group, String[] params)
/*     */   {
/* 118 */     if (LOG.isDebugEnabled()) LOG.debug("REGEX FOR RECORD NAME [" + regex + "]");
/*     */     try
/*     */     {
/* 121 */       String text = this.settings.getDriver().findElement(By.xpath(getXpath(params))).getText();
/* 122 */       if (LOG.isDebugEnabled()) LOG.debug("RECORD NAME [" + text + "]");
/* 123 */       return getRegexResults(regex, group, text);
/*     */     } catch (Exception e) {
/* 125 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Record name regex", regex });
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.record.TempoRecord
 * JD-Core Version:    0.6.2
 */