/*    */ package com.appiancorp.ps.automatedtest.tempo.record;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoRecordGridColumn extends AppianObject
/*    */   implements Clickable
/*    */ {
/* 17 */   private static final Logger LOG = Logger.getLogger(TempoRecord.class);
/* 18 */   private static final String XPATH_ABSOLUTE_RECORD_GRID_COLUMN_SORT_LINK = Settings.getByConstant("xpathAbsoluteRecordGridColumnSortLink");
/*    */ 
/*    */   public static TempoRecordGridColumn getInstance(Settings settings) {
/* 21 */     return new TempoRecordGridColumn(settings);
/*    */   }
/*    */ 
/*    */   private TempoRecordGridColumn(Settings settings) {
/* 25 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 30 */     String columnName = getParam(0, params);
/*    */ 
/* 32 */     return xpathFormat(XPATH_ABSOLUTE_RECORD_GRID_COLUMN_SORT_LINK, new Object[] { columnName });
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 37 */     String columnName = getParam(0, params);
/*    */ 
/* 39 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR COLUMN [" + columnName + "]");
/*    */     try
/*    */     {
/* 42 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 44 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Record Column", columnName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 50 */     String columnName = getParam(0, params);
/*    */ 
/* 52 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK ON COLUMN [" + columnName + "]");
/*    */ 
/*    */     try
/*    */     {
/* 56 */       WebElement column = this.settings.getDriver()
/* 56 */         .findElement(By.xpath(getXpath(params)));
/*    */ 
/* 57 */       clickElement(column);
/*    */     } catch (Exception e) {
/* 59 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Click Record", columnName });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.record.TempoRecordGridColumn
 * JD-Core Version:    0.6.2
 */