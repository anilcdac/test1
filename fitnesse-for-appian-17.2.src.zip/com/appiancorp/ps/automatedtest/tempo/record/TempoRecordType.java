/*    */ package com.appiancorp.ps.automatedtest.tempo.record;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoRecordType extends AppianObject
/*    */   implements Clickable
/*    */ {
/* 16 */   private static final Logger LOG = Logger.getLogger(TempoRecordType.class);
/* 17 */   private static final String XPATH_ABSOLUTE_RECORD_TYPE_LINK = Settings.getByConstant("xpathAbsoluteRecordTypeLink");
/* 18 */   private static final String XPATH_ABSOLUTE_RECORD_TYPE_LINK_INDEX = "(" + XPATH_ABSOLUTE_RECORD_TYPE_LINK + ")[%2$d]";
/*    */ 
/*    */   public static TempoRecordType getInstance(Settings settings) {
/* 21 */     return new TempoRecordType(settings);
/*    */   }
/*    */ 
/*    */   private TempoRecordType(Settings settings) {
/* 25 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 30 */     String type = getParam(0, params);
/*    */ 
/* 32 */     if (isFieldIndex(type)) {
/* 33 */       int rNum = getIndexFromFieldIndex(type);
/* 34 */       String rName = getFieldFromFieldIndex(type);
/* 35 */       return xpathFormat(XPATH_ABSOLUTE_RECORD_TYPE_LINK_INDEX, new Object[] { rName, Integer.valueOf(rNum) });
/*    */     }
/* 37 */     return xpathFormat(XPATH_ABSOLUTE_RECORD_TYPE_LINK, new Object[] { type });
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 43 */     String type = getParam(0, params);
/*    */ 
/* 45 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK RECORD TYPE [" + type + "]");
/*    */     try
/*    */     {
/* 48 */       WebElement recordType = this.settings.getDriver().findElement(By.xpath(getXpath(new String[] { type })));
/* 49 */       clickElement(recordType);
/*    */     } catch (Exception e) {
/* 51 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Record Type", type });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 57 */     String type = getParam(0, params);
/*    */ 
/* 59 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR RECORD TYPE [" + type + "]");
/*    */     try
/*    */     {
/* 62 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/* 63 */         .until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     }
/*    */     catch (Exception e) {
/* 65 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Record Type", type });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.record.TempoRecordType
 * JD-Core Version:    0.6.2
 */