/*     */ package com.appiancorp.ps.automatedtest.tempo.record;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.common.Version;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.WebDriver;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoRecordTypeUserFilter extends AppianObject
/*     */   implements Clickable
/*     */ {
/*  20 */   private static final Logger LOG = Logger.getLogger(TempoRecordTypeUserFilter.class);
/*  21 */   private static final String XPATH_ABSOLUTE_RECORD_TYPE_USER_FILTER_LINK = Settings.getByConstant("xpathAbsoluteRecordTypeUserFilterLink");
/*     */   public static final String XPATH_GENERIC_DROPDOWN = ".//div[contains(@class, 'DropdownWidget---dropdown_value')]";
/*     */   public static final String XPATH_GENERIC_DROPDOWN_LIST_ITEM = "//div[contains(@class,'DropdownWidget---tether_dropdown')]//li/descendant-or-self::*[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),%1$s)]";
/*     */ 
/*     */   public static TempoRecordTypeUserFilter getInstance(Settings settings)
/*     */   {
/*  26 */     return new TempoRecordTypeUserFilter(settings);
/*     */   }
/*     */ 
/*     */   private TempoRecordTypeUserFilter(Settings settings) {
/*  30 */     super(settings);
/*     */   }
/*     */ 
/*     */   public String getXpath(String[] params)
/*     */   {
/*  35 */     String userFilter = getParam(0, params);
/*     */ 
/*  37 */     return xpathFormat(XPATH_ABSOLUTE_RECORD_TYPE_USER_FILTER_LINK, new Object[] { userFilter });
/*     */   }
/*     */ 
/*     */   public void click(String[] params)
/*     */   {
/*  42 */     String userFilter = getParam(0, params);
/*     */ 
/*  44 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK ON USER FILTER [" + userFilter + "]");
/*     */     try
/*     */     {
/*  47 */       if (Settings.getVersion().compareTo(new Version(Integer.valueOf(17), Integer.valueOf(1))) >= 0) {
/*  48 */         clickElementInDropdown(params);
/*     */       } else {
/*  50 */         WebElement filter = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/*  51 */         clickElement(filter);
/*     */       }
/*     */     } catch (Exception e) {
/*  54 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "User Filter", userFilter });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void waitFor(String[] params)
/*     */   {
/*  60 */     String userFilter = getParam(0, params);
/*     */ 
/*  62 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR USER FILTER [" + userFilter + "]");
/*     */     try
/*     */     {
/*  65 */       if (Settings.getVersion().compareTo(new Version(Integer.valueOf(17), Integer.valueOf(1))) >= 0)
/*  66 */         checkDropdownValues(params);
/*     */       else
/*  68 */         new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getXpath(params))));
/*     */     }
/*     */     catch (Exception e) {
/*  71 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "User Filter", userFilter });
/*     */     }
/*     */   }
/*     */ 
/*     */   private void clickElementInDropdown(String[] params) {
/*  76 */     String userFilter = getParam(0, params);
/*  77 */     List dropdowns = this.settings.getDriver().findElements(By.xpath(".//div[contains(@class, 'DropdownWidget---dropdown_value')]"));
/*     */ 
/*  79 */     if (dropdowns.isEmpty()) {
/*  80 */       throw ExceptionBuilder.build(new Exception("No filter dropdowns were found."), this.settings, new String[] { "User Filter", userFilter });
/*     */     }
/*     */ 
/*  83 */     for (Iterator webElementIterator = dropdowns.iterator(); webElementIterator.hasNext(); ) {
/*  84 */       WebElement next = (WebElement)webElementIterator.next();
/*  85 */       next.click();
/*     */       try {
/*  87 */         String formattedXpath = xpathFormat("//div[contains(@class,'DropdownWidget---tether_dropdown')]//li/descendant-or-self::*[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),%1$s)]", new Object[] { userFilter });
/*  88 */         new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(formattedXpath)));
/*  89 */         clickElement(this.settings.getDriver().findElement(By.xpath(formattedXpath)));
/*  90 */         return;
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*     */     }
/*  96 */     throw ExceptionBuilder.build(new Exception("Searched for value not found in any filter dropdowns."), this.settings, new String[] { "User Filter", userFilter });
/*     */   }
/*     */ 
/*     */   private void checkDropdownValues(String[] params) throws Exception {
/* 100 */     String userFilter = getParam(0, params);
/* 101 */     List dropdowns = this.settings.getDriver().findElements(By.xpath(".//div[contains(@class, 'DropdownWidget---dropdown_value')]"));
/*     */ 
/* 103 */     if (dropdowns.isEmpty()) {
/* 104 */       throw ExceptionBuilder.build(new Exception("No filter dropdowns were found."), this.settings, new String[] { "User Filter", userFilter });
/*     */     }
/*     */ 
/* 107 */     for (Iterator webElementIterator = dropdowns.iterator(); webElementIterator.hasNext(); ) {
/* 108 */       WebElement next = (WebElement)webElementIterator.next();
/* 109 */       next.click();
/*     */       try {
/* 111 */         String formattedXpath = xpathFormat("//div[contains(@class,'DropdownWidget---tether_dropdown')]//li/descendant-or-self::*[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),%1$s)]", new Object[] { userFilter });
/* 112 */         new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(formattedXpath)));
/* 113 */         return;
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 117 */         next.click(); } finally { next.click(); }
/*     */ 
/*     */     }
/*     */ 
/* 121 */     throw ExceptionBuilder.build(new Exception("Searched for value not found in any filter dropdowns."), this.settings, new String[] { "User Filter", userFilter });
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.record.TempoRecordTypeUserFilter
 * JD-Core Version:    0.6.2
 */