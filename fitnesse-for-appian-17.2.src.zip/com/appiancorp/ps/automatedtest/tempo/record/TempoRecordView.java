/*    */ package com.appiancorp.ps.automatedtest.tempo.record;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoRecordView extends AppianObject
/*    */   implements Clickable
/*    */ {
/* 16 */   private static final Logger LOG = Logger.getLogger(TempoRecordView.class);
/* 17 */   private static final String XPATH_ABSOLUTE_RECORD_VIEW_LINK = Settings.getByConstant("xpathAbsoluteRecordViewLink");
/*    */ 
/*    */   public static TempoRecordView getInstance(Settings settings) {
/* 20 */     return new TempoRecordView(settings);
/*    */   }
/*    */ 
/*    */   private TempoRecordView(Settings settings) {
/* 24 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 29 */     String view = getParam(0, params);
/*    */ 
/* 31 */     return xpathFormat(XPATH_ABSOLUTE_RECORD_VIEW_LINK, new Object[] { view });
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 36 */     String view = getParam(0, params);
/*    */ 
/* 38 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK ON RECORD VIEW [" + view + "]");
/*    */     try
/*    */     {
/* 41 */       WebElement element = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 42 */       clickElement(element);
/*    */     } catch (Exception e) {
/* 44 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Record View", view });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 50 */     String view = getParam(0, params);
/*    */ 
/* 52 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR RECORD VIEW [" + view + "]");
/*    */     try
/*    */     {
/* 55 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 57 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Record View", view });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.record.TempoRecordView
 * JD-Core Version:    0.6.2
 */