/*     */ package com.appiancorp.ps.automatedtest.tempo.news;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import com.appiancorp.ps.automatedtest.properties.Clearable;
/*     */ import com.appiancorp.ps.automatedtest.properties.Refreshable;
/*     */ import com.appiancorp.ps.automatedtest.properties.RegexCaptureable;
/*     */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoButton;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.NoSuchElementException;
/*     */ import org.openqa.selenium.TimeoutException;
/*     */ import org.openqa.selenium.WebDriver;
/*     */ import org.openqa.selenium.WebDriver.Navigation;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoNewsItem extends AppianObject
/*     */   implements Refreshable, Clearable, RegexCaptureable
/*     */ {
/*  21 */   private static final Logger LOG = Logger.getLogger(TempoNewsItem.class);
/*  22 */   protected static final String XPATH_ABSOLUTE_NEWS_ITEM = Settings.getByConstant("xpathAbsoluteNewsItem");
/*  23 */   protected static final String XPATH_ABSOLUTE_DELETE_LINK = Settings.getByConstant("xpathAbsoluteDeleteLink");
/*     */ 
/*  25 */   private static final String XPATH_ABSOLUTE_NEWS_ITEM_DELETE_LINK = XPATH_ABSOLUTE_NEWS_ITEM + 
/*  25 */     Settings.getByConstant("xpathConcatNewsItemDeleteLink")
/*  25 */     ;
/*     */ 
/*     */   public static TempoNewsItem getInstance(Settings settings) {
/*  28 */     return new TempoNewsItem(settings);
/*     */   }
/*     */ 
/*     */   protected TempoNewsItem(Settings settings) {
/*  32 */     super(settings);
/*     */   }
/*     */ 
/*     */   public String getXpath(String[] params)
/*     */   {
/*  37 */     String newsText = getParam(0, params);
/*     */ 
/*  39 */     return xpathFormat(XPATH_ABSOLUTE_NEWS_ITEM, new Object[] { newsText });
/*     */   }
/*     */ 
/*     */   public void waitFor(String[] params)
/*     */   {
/*  44 */     String newsText = getParam(0, params);
/*     */ 
/*  46 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR [" + newsText + "]");
/*     */     try
/*     */     {
/*  49 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*     */     } catch (Exception e) {
/*  51 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "News Item", newsText });
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean waitForReturn(int timeout, String[] params)
/*     */   {
/*  57 */     String newsText = getParam(0, params);
/*     */ 
/*  59 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR REFRESH [" + newsText + "]");
/*     */     try
/*     */     {
/*  62 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*  63 */       return true;
/*     */     } catch (TimeoutException e) {
/*  65 */       return false;
/*     */     } catch (Exception e) {
/*  67 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "News Item", newsText });
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean waitForReturn(String[] params)
/*     */   {
/*  73 */     return waitForReturn(this.settings.getTimeoutSeconds(), params);
/*     */   }
/*     */ 
/*     */   public void refreshAndWaitFor(String[] params)
/*     */   {
/*  78 */     int i = 0;
/*  79 */     while (i < this.settings.getRefreshTimes().intValue())
/*     */     {
/*  81 */       if (i < this.settings.getRefreshTimes().intValue() - 1) {
/*  82 */         if (waitForReturn(params)) {
/*     */           break;
/*     */         }
/*  85 */         this.settings.getDriver().navigate().refresh();
/*     */       } else {
/*  87 */         waitFor(params);
/*     */       }
/*  89 */       i++;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear(String[] params)
/*     */   {
/*  95 */     String newsText = getParam(0, params);
/*     */ 
/*  97 */     if (LOG.isDebugEnabled()) LOG.debug("DELETE NEWS ITEM [" + newsText + "]");
/*     */     try
/*     */     {
/* 100 */       WebElement element = this.settings.getDriver().findElement(By.xpath(xpathFormat(XPATH_ABSOLUTE_NEWS_ITEM_DELETE_LINK, new Object[] { newsText })));
/* 101 */       element.click();
/* 102 */       TempoButton.getInstance(this.settings).click(new String[] { "Yes" });
/* 103 */       waitForWorking();
/*     */     } catch (Exception e) {
/* 105 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "News Item delete", newsText });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clearAll(String[] params) {
/*     */     try {
/* 111 */       WebElement element = this.settings.getDriver().findElement(By.xpath(XPATH_ABSOLUTE_DELETE_LINK));
/*     */ 
/* 113 */       while (element != null) {
/* 114 */         clickElement(element);
/* 115 */         TempoButton.getInstance(this.settings).click(new String[] { "Yes" });
/*     */ 
/* 117 */         element = this.settings.getDriver().findElement(By.xpath("//a[contains(text(), 'Delete')]"));
/*     */       }
/*     */     } catch (NoSuchElementException e) {
/* 120 */       LOG.debug("No tempo messages remain for this user");
/*     */     } catch (Exception e) {
/* 122 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Delete all news items" });
/*     */     }
/*     */   }
/*     */ 
/*     */   public String regexCapture(String regex, Integer group, String[] params)
/*     */   {
/* 128 */     String newsText = getParam(0, params);
/*     */ 
/* 130 */     if (LOG.isDebugEnabled()) LOG.debug("NEWS ITEM [" + newsText + "] REGEX [" + regex + "]");
/*     */     try
/*     */     {
/* 133 */       String text = this.settings.getDriver().findElement(By.xpath(getXpath(params))).getText();
/* 134 */       return getRegexResults(regex, group, text);
/*     */     } catch (Exception e) {
/* 136 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "News Item regex", newsText, regex });
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.news.TempoNewsItem
 * JD-Core Version:    0.6.2
 */