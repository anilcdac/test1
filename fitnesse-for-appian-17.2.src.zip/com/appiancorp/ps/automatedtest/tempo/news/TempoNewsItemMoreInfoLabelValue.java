/*    */ package com.appiancorp.ps.automatedtest.tempo.news;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitFor;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoNewsItemMoreInfoLabelValue extends TempoNewsItemMoreInfo
/*    */   implements WaitFor
/*    */ {
/* 14 */   private static final Logger LOG = Logger.getLogger(TempoNewsItemMoreInfoLabelValue.class);
/*    */ 
/* 16 */   private static final String XPATH_ABSOLUTE_NEWS_ITEM_MORE_INFO_LABEL = XPATH_ABSOLUTE_NEWS_ITEM + 
/* 16 */     Settings.getByConstant("xpathConcatNewsItemMoreInfoLabel")
/* 16 */     ;
/*    */ 
/* 18 */   private static final String XPATH_ABSOLUTE_NEWS_ITEM_MORE_INFO_VALUE = XPATH_ABSOLUTE_NEWS_ITEM + 
/* 18 */     Settings.getByConstant("xpathConcatNewsItemMoreInfoValue")
/* 18 */     ;
/*    */ 
/*    */   public static TempoNewsItemMoreInfoLabelValue getInstance(Settings settings) {
/* 21 */     return new TempoNewsItemMoreInfoLabelValue(settings);
/*    */   }
/*    */ 
/*    */   private TempoNewsItemMoreInfoLabelValue(Settings settings) {
/* 25 */     super(settings);
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 30 */     String newsText = getParam(0, params);
/* 31 */     String label = getParam(1, params);
/* 32 */     String value = getParam(2, params);
/*    */ 
/* 34 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR LABEL [" + label + "] and VALUE [" + value + "]");
/*    */ 
/* 36 */     value = parseVariable(value);
/*    */     try
/*    */     {
/* 39 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpathFormat(XPATH_ABSOLUTE_NEWS_ITEM_MORE_INFO_LABEL, new Object[] { newsText, label }))));
/*    */ 
/* 41 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpathFormat(XPATH_ABSOLUTE_NEWS_ITEM_MORE_INFO_VALUE, new Object[] { newsText, value }))));
/*    */     }
/*    */     catch (Exception e) {
/* 44 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "News Item Label and Value", newsText, label, value });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.news.TempoNewsItemMoreInfoLabelValue
 * JD-Core Version:    0.6.2
 */