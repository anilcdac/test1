/*    */ package com.appiancorp.ps.automatedtest.tempo.news;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ 
/*    */ public class TempoNewsItemMoreInfo extends TempoNewsItem
/*    */   implements Clickable
/*    */ {
/* 12 */   private static final Logger LOG = Logger.getLogger(TempoNewsItemMoreInfo.class);
/*    */ 
/* 14 */   private static final String XPATH_ABSOLUTE_NEWS_ITEM_MORE_INFO_LINK = XPATH_ABSOLUTE_NEWS_ITEM + 
/* 14 */     Settings.getByConstant("xpathConcatNewsItemMoreInfoLink")
/* 14 */     ;
/*    */ 
/*    */   public static TempoNewsItemMoreInfo getInstance(Settings settings) {
/* 17 */     return new TempoNewsItemMoreInfo(settings);
/*    */   }
/*    */ 
/*    */   protected TempoNewsItemMoreInfo(Settings settings) {
/* 21 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 26 */     String newsText = getParam(0, params);
/*    */ 
/* 28 */     return xpathFormat(XPATH_ABSOLUTE_NEWS_ITEM_MORE_INFO_LINK, new Object[] { newsText });
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 33 */     String newsText = getParam(0, params);
/*    */ 
/* 35 */     if (LOG.isDebugEnabled()) LOG.debug("TOGGLE MORE INFO [" + newsText + "]");
/*    */ 
/* 37 */     WebElement moreInfoLink = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 38 */     clickElement(moreInfoLink);
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.news.TempoNewsItemMoreInfo
 * JD-Core Version:    0.6.2
 */