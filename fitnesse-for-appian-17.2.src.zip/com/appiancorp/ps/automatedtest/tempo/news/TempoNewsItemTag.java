/*    */ package com.appiancorp.ps.automatedtest.tempo.news;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import com.appiancorp.ps.automatedtest.properties.Refreshable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.TimeoutException;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoNewsItemTag extends TempoNewsItem
/*    */   implements Clickable, Refreshable
/*    */ {
/* 17 */   private static final Logger LOG = Logger.getLogger(TempoNewsItemTag.class);
/* 18 */   protected static final String XPATH_ABSOLUTE_NEWS_ITEM = Settings.getByConstant("xpathAbsoluteNewsItem");
/*    */ 
/* 20 */   private static final String XPATH_ABSOLUTE_NEWS_ITEM_RECORD_TAG = XPATH_ABSOLUTE_NEWS_ITEM + 
/* 20 */     Settings.getByConstant("xpathConcatNewsItemRecordTag")
/* 20 */     ;
/*    */ 
/*    */   public static TempoNewsItemTag getInstance(Settings settings) {
/* 23 */     return new TempoNewsItemTag(settings);
/*    */   }
/*    */ 
/*    */   protected TempoNewsItemTag(Settings settings) {
/* 27 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 32 */     String newsText = getParam(0, params);
/* 33 */     String recordTag = getParam(1, params);
/*    */ 
/* 35 */     return xpathFormat(XPATH_ABSOLUTE_NEWS_ITEM_RECORD_TAG, new Object[] { newsText, recordTag });
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 40 */     String newsText = getParam(0, params);
/* 41 */     String recordTag = getParam(1, params);
/*    */ 
/* 43 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR NEWS ITEM [" + newsText + "] and TAG [" + recordTag + "]");
/*    */     try
/*    */     {
/* 46 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 48 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "News Item Tag", newsText, recordTag });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(int timeout, String[] params)
/*    */   {
/* 54 */     String newsText = getParam(0, params);
/* 55 */     String recordTag = getParam(1, params);
/*    */ 
/* 57 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR NEWS ITEM [" + newsText + "] and TAG [" + recordTag + "]");
/*    */     try
/*    */     {
/* 60 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/* 61 */       return true;
/*    */     } catch (TimeoutException e) {
/* 63 */       return false;
/*    */     } catch (Exception e) {
/* 65 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "News Item Tag", newsText, recordTag });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 71 */     String newsText = getParam(0, params);
/* 72 */     String recordTag = getParam(1, params);
/*    */ 
/* 74 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK ON NEWS ITEM [" + newsText + "] and RECORD TAG [" + recordTag + "]");
/*    */     try
/*    */     {
/* 77 */       WebElement tag = this.settings.getDriver().findElement(By.xpath(xpathFormat(XPATH_ABSOLUTE_NEWS_ITEM_RECORD_TAG, new Object[] { newsText, recordTag })));
/* 78 */       clickElement(tag);
/*    */     } catch (Exception e) {
/* 80 */       LOG.error("News Item Record tag", e);
/* 81 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "News Item Record tag", newsText, recordTag });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.news.TempoNewsItemTag
 * JD-Core Version:    0.6.2
 */