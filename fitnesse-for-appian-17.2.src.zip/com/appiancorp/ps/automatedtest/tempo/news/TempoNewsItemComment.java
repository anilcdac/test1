/*    */ package com.appiancorp.ps.automatedtest.tempo.news;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Refreshable;
/*    */ import com.appiancorp.ps.automatedtest.properties.RegexCaptureable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.TimeoutException;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoNewsItemComment extends TempoNewsItem
/*    */   implements Refreshable, RegexCaptureable
/*    */ {
/* 16 */   private static final Logger LOG = Logger.getLogger(TempoNewsItemComment.class);
/*    */ 
/* 18 */   private static final String XPATH_ABSOLUTE_NEWS_ITEM_COMMENT = XPATH_ABSOLUTE_NEWS_ITEM + 
/* 18 */     Settings.getByConstant("xpathConcatNewsItemComment")
/* 18 */     ;
/*    */ 
/*    */   public static TempoNewsItemComment getInstance(Settings settings) {
/* 21 */     return new TempoNewsItemComment(settings);
/*    */   }
/*    */ 
/*    */   protected TempoNewsItemComment(Settings settings) {
/* 25 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 30 */     String newsText = getParam(0, params);
/* 31 */     String newsComment = getParam(1, params);
/*    */ 
/* 33 */     return xpathFormat(XPATH_ABSOLUTE_NEWS_ITEM_COMMENT, new Object[] { newsText, newsComment });
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 38 */     String newsText = getParam(1, params);
/* 39 */     String newsComment = params[2];
/*    */ 
/* 41 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR NEWS ITEM [" + newsText + "] and COMMENT [" + newsComment + "]");
/*    */     try
/*    */     {
/* 44 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 46 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "News Item Comment", newsText, newsComment });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(int timeout, String[] params)
/*    */   {
/* 52 */     String newsText = getParam(0, params);
/* 53 */     String newsComment = getParam(1, params);
/*    */ 
/* 55 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR NEWS ITEM [" + newsText + "] and COMMENT [" + newsComment + "]");
/*    */     try
/*    */     {
/* 58 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (TimeoutException e) {
/* 60 */       return false;
/*    */     } catch (Exception e) {
/* 62 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "News Item Comment", newsText, newsComment });
/*    */     }
/*    */ 
/* 65 */     return true;
/*    */   }
/*    */ 
/*    */   public String regexCapture(String regex, Integer group, String[] params)
/*    */   {
/* 70 */     String newsText = getParam(0, params);
/* 71 */     String newsComment = getParam(1, params);
/*    */ 
/* 73 */     if (LOG.isDebugEnabled()) LOG.debug("NEWS ITEM [" + newsText + "] COMMENT [" + newsComment + "] REGEX [" + regex + "]");
/*    */     try
/*    */     {
/* 76 */       String text = this.settings.getDriver().findElement(By.xpath(getXpath(params))).getText();
/* 77 */       return getRegexResults(regex, group, text);
/*    */     } catch (Exception e) {
/* 79 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "News Item regex", newsText, regex });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.news.TempoNewsItemComment
 * JD-Core Version:    0.6.2
 */