/*    */ package com.appiancorp.ps.automatedtest.tempo.news;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitFor;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoNewsItemPosted extends TempoNewsItem
/*    */   implements WaitFor
/*    */ {
/* 14 */   private static final Logger LOG = Logger.getLogger(TempoNewsItem.class);
/*    */ 
/* 16 */   private static final String XPATH_ABSOLUTE_NEWS_ITEM_POSTED_AT = XPATH_ABSOLUTE_NEWS_ITEM + 
/* 16 */     Settings.getByConstant("xpathConcatNewsItemPostedAt")
/* 16 */     ;
/*    */ 
/*    */   public static TempoNewsItemPosted getInstance(Settings settings) {
/* 19 */     return new TempoNewsItemPosted(settings);
/*    */   }
/*    */ 
/*    */   protected TempoNewsItemPosted(Settings settings) {
/* 23 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 28 */     String newsText = getParam(0, params);
/* 29 */     String newsPostedAt = getParam(1, params);
/*    */ 
/* 31 */     return xpathFormat(XPATH_ABSOLUTE_NEWS_ITEM_POSTED_AT, new Object[] { newsText, newsPostedAt });
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 36 */     String newsText = getParam(0, params);
/* 37 */     String newsPostedAt = getParam(1, params);
/*    */ 
/* 39 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR NEWS ITEM [" + newsText + "] and POSTED AT [" + newsPostedAt + "]");
/*    */     try
/*    */     {
/* 42 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 44 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "News Item Posted at", newsText, newsPostedAt });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.news.TempoNewsItemPosted
 * JD-Core Version:    0.6.2
 */