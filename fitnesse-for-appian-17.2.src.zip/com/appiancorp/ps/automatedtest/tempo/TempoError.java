/*    */ package com.appiancorp.ps.automatedtest.tempo;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitForReturn;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.TimeoutException;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoError extends AppianObject
/*    */   implements WaitForReturn
/*    */ {
/* 16 */   private static final Logger LOG = Logger.getLogger(TempoError.class);
/* 17 */   private static final String XPATH_ERROR = Settings.getByConstant("xpathAbsoluteError");
/*    */ 
/*    */   public static TempoError getInstance(Settings settings) {
/* 20 */     return new TempoError(settings);
/*    */   }
/*    */ 
/*    */   private TempoError(Settings settings) {
/* 24 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 29 */     return XPATH_ERROR;
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 34 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR TEMPO ERROR");
/*    */     try
/*    */     {
/* 37 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 39 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Tempo Error" });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(String[] params)
/*    */   {
/* 45 */     return waitForReturn(this.settings.getTimeoutSeconds(), params);
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(int timeout, String[] params)
/*    */   {
/* 51 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR TEMPO ERROR");
/*    */     try
/*    */     {
/* 54 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/* 55 */       return true;
/*    */     } catch (TimeoutException e) {
/* 57 */       return false;
/*    */     } catch (Exception e) {
/* 59 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Tempo Error" });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.TempoError
 * JD-Core Version:    0.6.2
 */