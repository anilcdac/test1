/*     */ package com.appiancorp.ps.automatedtest.tempo.action;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*     */ import com.appiancorp.ps.automatedtest.properties.Completeable;
/*     */ import com.appiancorp.ps.automatedtest.properties.WaitForReturn;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.TimeoutException;
/*     */ import org.openqa.selenium.WebDriver;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoAction extends AppianObject
/*     */   implements WaitForReturn, Clickable, Completeable
/*     */ {
/*  19 */   private static final Logger LOG = Logger.getLogger(TempoAction.class);
/*  20 */   private static final String XPATH_ABSOLUTE_ACTION_LINK = Settings.getByConstant("xpathAbsoluteActionLink");
/*  21 */   private static final String XPATH_ABSOLUTE_ACTION_LINK_INDEX = "(" + XPATH_ABSOLUTE_ACTION_LINK + ")[%2$d]";
/*     */ 
/*     */   public static TempoAction getInstance(Settings settings) {
/*  24 */     return new TempoAction(settings);
/*     */   }
/*     */ 
/*     */   private TempoAction(Settings settings) {
/*  28 */     super(settings);
/*     */   }
/*     */ 
/*     */   public String getXpath(String[] params)
/*     */   {
/*  33 */     String action = getParam(0, params);
/*     */ 
/*  35 */     if (isFieldIndex(action)) {
/*  36 */       int rNum = getIndexFromFieldIndex(action);
/*  37 */       String rName = getFieldFromFieldIndex(action);
/*  38 */       return xpathFormat(XPATH_ABSOLUTE_ACTION_LINK_INDEX, new Object[] { rName, Integer.valueOf(rNum) });
/*     */     }
/*  40 */     return xpathFormat(XPATH_ABSOLUTE_ACTION_LINK, new Object[] { action });
/*     */   }
/*     */ 
/*     */   public void click(String[] params)
/*     */   {
/*  46 */     String actionName = getParam(0, params);
/*     */ 
/*  48 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK ACTION [" + actionName + "]");
/*     */     try
/*     */     {
/*  51 */       WebElement action = this.settings.getDriver().findElement(By.xpath(getXpath(new String[] { actionName })));
/*  52 */       clickElement(action);
/*     */     } catch (Exception e) {
/*  54 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Action click", actionName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void waitFor(String[] params)
/*     */   {
/*  61 */     String actionName = getParam(0, params);
/*     */ 
/*  63 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR ACTION [" + actionName + "]");
/*     */     try
/*     */     {
/*  66 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/*  67 */         .until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*     */     }
/*     */     catch (Exception e) {
/*  69 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Action wait for", actionName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean waitForReturn(int timeout, String[] params)
/*     */   {
/*  75 */     String actionName = getParam(0, params);
/*     */ 
/*  77 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR ACTION [" + actionName + "]");
/*     */     try
/*     */     {
/*  80 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*  81 */       return true;
/*     */     } catch (TimeoutException e) {
/*  83 */       return false;
/*     */     } catch (Exception e) {
/*  85 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Action wait for", actionName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean waitForReturn(String[] params)
/*     */   {
/*  91 */     return waitForReturn(this.settings.getTimeoutSeconds(), params);
/*     */   }
/*     */ 
/*     */   public boolean complete(String[] params)
/*     */   {
/*     */     try {
/*  97 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.textToBePresentInElementLocated(
/*  98 */         By.id("inlineConfirmMessage"), 
/*  98 */         "Action completed successfully"));
/*     */     } catch (Exception e) {
/* 100 */       return false;
/*     */     }
/*     */ 
/* 103 */     return true;
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.action.TempoAction
 * JD-Core Version:    0.6.2
 */