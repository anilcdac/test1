/*    */ package com.appiancorp.ps.automatedtest.tempo.action;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitForReturn;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.TimeoutException;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoActionApplicationFilter extends AppianObject
/*    */   implements WaitForReturn, Clickable
/*    */ {
/* 18 */   private static final Logger LOG = Logger.getLogger(TempoActionApplicationFilter.class);
/* 19 */   private static final String XPATH_ABSOLUTE_ACTIONS_APP_FILTER_LINK = Settings.getByConstant("xpathAbsoluteActionsAppFilterLink");
/*    */ 
/*    */   public static TempoActionApplicationFilter getInstance(Settings settings) {
/* 22 */     return new TempoActionApplicationFilter(settings);
/*    */   }
/*    */ 
/*    */   private TempoActionApplicationFilter(Settings settings) {
/* 26 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 31 */     String filterName = getParam(0, params);
/*    */ 
/* 33 */     return xpathFormat(XPATH_ABSOLUTE_ACTIONS_APP_FILTER_LINK, new Object[] { filterName });
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 38 */     String filterName = getParam(0, params);
/*    */ 
/* 40 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR ACTION APP FILTER [" + filterName + "]");
/*    */     try
/*    */     {
/* 43 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/* 44 */         .until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     }
/*    */     catch (Exception e) {
/* 46 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Application Filter", filterName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 52 */     String filterName = getParam(0, params);
/*    */ 
/* 54 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK ACTION APP FILTER [" + filterName + "]"); try
/*    */     {
/* 56 */       WebElement filter = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 57 */       clickElement(filter);
/*    */     } catch (Exception e) {
/* 59 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Application Filter", filterName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(int timeout, String[] params)
/*    */   {
/* 65 */     String applicationName = getParam(0, params);
/*    */ 
/* 67 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR ACTION [" + applicationName + "]");
/*    */     try
/*    */     {
/* 70 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/* 71 */       return true;
/*    */     } catch (TimeoutException e) {
/* 73 */       return false;
/*    */     } catch (Exception e) {
/* 75 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Action Application wait for ", applicationName });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(String[] params)
/*    */   {
/* 81 */     return waitForReturn(this.settings.getTimeoutSeconds(), params);
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.action.TempoActionApplicationFilter
 * JD-Core Version:    0.6.2
 */