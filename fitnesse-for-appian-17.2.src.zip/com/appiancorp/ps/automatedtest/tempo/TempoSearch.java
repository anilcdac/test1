/*    */ package com.appiancorp.ps.automatedtest.tempo;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Populateable;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitForReturn;
/*    */ import com.appiancorp.ps.automatedtest.tempo.record.TempoRecordType;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.Keys;
/*    */ import org.openqa.selenium.TimeoutException;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoSearch extends AppianObject
/*    */   implements WaitForReturn, Populateable
/*    */ {
/* 20 */   private static final Logger LOG = Logger.getLogger(TempoRecordType.class);
/* 21 */   private static final String XPATH_ABSOLUTE_SEARCH_FIELD = Settings.getByConstant("xpathAbsoluteSearchField");
/* 22 */   private static final String XPATH_ABSOLUTE_FEED_ENTRY = Settings.getByConstant("xpathAbsoluteFeedEntry");
/*    */ 
/*    */   public static TempoSearch getInstance(Settings settings) {
/* 25 */     return new TempoSearch(settings);
/*    */   }
/*    */ 
/*    */   private TempoSearch(Settings settings) {
/* 29 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 34 */     return XPATH_ABSOLUTE_SEARCH_FIELD;
/*    */   }
/*    */ 
/*    */   public void populate(String[] params)
/*    */   {
/* 39 */     String searchValue = getParam(0, params);
/*    */ 
/* 41 */     if (LOG.isDebugEnabled()) LOG.debug("SEARCH FOR [" + searchValue + "]");
/*    */     try
/*    */     {
/* 44 */       WebElement fieldLayout = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/*    */ 
/* 46 */       scrollIntoView(fieldLayout);
/* 47 */       fieldLayout.clear();
/* 48 */       fieldLayout.sendKeys(new CharSequence[] { searchValue });
/* 49 */       fieldLayout.sendKeys(new CharSequence[] { Keys.ENTER });
/* 50 */       waitForWorking();
/*    */     } catch (Exception e) {
/* 52 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Tempo Search", searchValue });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 58 */     String type = getParam(0, params);
/*    */ 
/* 60 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR SEARCH [" + type + "]");
/*    */ 
/*    */     try
/*    */     {
/* 64 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(XPATH_ABSOLUTE_FEED_ENTRY)));
/* 65 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 67 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Tempo Search" });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(int timeout, String[] params)
/*    */   {
/* 73 */     String type = getParam(0, params);
/*    */ 
/* 75 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR SEARCH [" + type + "]");
/*    */     try
/*    */     {
/* 78 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(getXpath(params))));
/* 79 */       return true;
/*    */     } catch (TimeoutException e) {
/* 81 */       return false;
/*    */     } catch (Exception e) {
/* 83 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Tempo Search" });
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean waitForReturn(String[] params)
/*    */   {
/* 89 */     return waitForReturn(this.settings.getTimeoutSeconds(), params);
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.TempoSearch
 * JD-Core Version:    0.6.2
 */