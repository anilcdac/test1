/*    */ package com.appiancorp.ps.automatedtest.tempo.task;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class TempoTaskReport extends AppianObject
/*    */   implements Clickable
/*    */ {
/* 16 */   private static final Logger LOG = Logger.getLogger(TempoTaskReport.class);
/* 17 */   private static final String XPATH_ABSOLUTE_TASK_REPORT_LINK = Settings.getByConstant("xpathAbsoluteTaskReportLink");
/*    */ 
/*    */   public static TempoTaskReport getInstance(Settings settings) {
/* 20 */     return new TempoTaskReport(settings);
/*    */   }
/*    */ 
/*    */   private TempoTaskReport(Settings settings) {
/* 24 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 29 */     String taskReport = getParam(0, params);
/*    */ 
/* 31 */     return xpathFormat(XPATH_ABSOLUTE_TASK_REPORT_LINK, new Object[] { taskReport });
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 36 */     String taskReport = getParam(0, params);
/*    */ 
/* 38 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR TASK REPORT [" + taskReport + "]");
/*    */     try
/*    */     {
/* 41 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 43 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Task Report", taskReport });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 49 */     String taskReport = getParam(0, params);
/*    */ 
/* 51 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK TASK REPORT [" + taskReport + "]");
/*    */     try
/*    */     {
/* 54 */       WebElement report = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 55 */       clickElement(report);
/*    */     } catch (Exception e) {
/* 57 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Task Report", taskReport });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.task.TempoTaskReport
 * JD-Core Version:    0.6.2
 */