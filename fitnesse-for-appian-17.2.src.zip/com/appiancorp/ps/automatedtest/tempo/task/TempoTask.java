/*     */ package com.appiancorp.ps.automatedtest.tempo.task;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*     */ import com.appiancorp.ps.automatedtest.properties.Refreshable;
/*     */ import com.appiancorp.ps.automatedtest.properties.RegexCaptureable;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.TimeoutException;
/*     */ import org.openqa.selenium.WebDriver;
/*     */ import org.openqa.selenium.WebDriver.Navigation;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoTask extends AppianObject
/*     */   implements Refreshable, Clickable, RegexCaptureable
/*     */ {
/*  19 */   private static final Logger LOG = Logger.getLogger(TempoTask.class);
/*  20 */   private static final String XPATH_ABSOLUTE_TASK_LINK = Settings.getByConstant("xpathAbsoluteTaskLink");
/*  21 */   private static final String XPATH_ABSOLUTE_TASK_LINK_INDEX = "(" + XPATH_ABSOLUTE_TASK_LINK + ")[%2$d]";
/*     */ 
/*     */   public static TempoTask getInstance(Settings settings) {
/*  24 */     return new TempoTask(settings);
/*     */   }
/*     */ 
/*     */   private TempoTask(Settings settings) {
/*  28 */     super(settings);
/*     */   }
/*     */ 
/*     */   public String getXpath(String[] params)
/*     */   {
/*  33 */     String taskName = getParam(0, params);
/*     */ 
/*  35 */     if (isFieldIndex(taskName)) {
/*  36 */       int rNum = getIndexFromFieldIndex(taskName);
/*  37 */       String rName = getFieldFromFieldIndex(taskName);
/*  38 */       return xpathFormat(XPATH_ABSOLUTE_TASK_LINK_INDEX, new Object[] { rName, Integer.valueOf(rNum) });
/*     */     }
/*  40 */     return xpathFormat(XPATH_ABSOLUTE_TASK_LINK, new Object[] { taskName });
/*     */   }
/*     */ 
/*     */   public void click(String[] params)
/*     */   {
/*  46 */     String taskName = getParam(0, params);
/*     */ 
/*  48 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK TASK [" + taskName + "]");
/*     */     try
/*     */     {
/*  51 */       WebElement task = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/*  52 */       clickElement(task);
/*     */     } catch (Exception e) {
/*  54 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Task", taskName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void waitFor(String[] params)
/*     */   {
/*  60 */     String taskName = getParam(0, params);
/*     */ 
/*  62 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR TASK [" + taskName + "]");
/*     */     try
/*     */     {
/*  65 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/*  66 */         .until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*     */     }
/*     */     catch (Exception e) {
/*  68 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Task", taskName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean waitForReturn(int timeout, String[] params)
/*     */   {
/*  74 */     String taskName = getParam(0, params);
/*     */ 
/*  76 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR TASK [" + taskName + "]");
/*     */     try
/*     */     {
/*  79 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*  80 */       return true;
/*     */     } catch (TimeoutException e) {
/*  82 */       return false;
/*     */     } catch (Exception e) {
/*  84 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Task", taskName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean waitForReturn(String[] params)
/*     */   {
/*  90 */     return waitForReturn(this.settings.getTimeoutSeconds(), params);
/*     */   }
/*     */ 
/*     */   public void refreshAndWaitFor(String[] params)
/*     */   {
/*  95 */     int i = 0;
/*  96 */     while (i < this.settings.getRefreshTimes().intValue())
/*     */     {
/*  98 */       if (i < this.settings.getRefreshTimes().intValue() - 1) {
/*  99 */         if (waitForReturn(params)) {
/*     */           break;
/*     */         }
/* 102 */         this.settings.getDriver().navigate().refresh();
/*     */       } else {
/* 104 */         waitFor(params);
/*     */       }
/* 106 */       i++;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String regexCapture(String regex, Integer group, String[] params)
/*     */   {
/* 112 */     String taskName = getParam(0, params);
/*     */ 
/* 114 */     if (LOG.isDebugEnabled()) LOG.debug("REGEX FOR TASK [" + regex + "]");
/*     */     try
/*     */     {
/* 117 */       String text = this.settings.getDriver().findElement(By.xpath(getXpath(params))).getText();
/* 118 */       return getRegexResults(regex, group, text);
/*     */     } catch (Exception e) {
/* 120 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Task name regex", taskName, regex });
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.task.TempoTask
 * JD-Core Version:    0.6.2
 */