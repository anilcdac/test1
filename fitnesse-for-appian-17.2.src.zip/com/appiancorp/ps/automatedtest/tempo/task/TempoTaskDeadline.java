/*    */ package com.appiancorp.ps.automatedtest.tempo.task;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitFor;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ 
/*    */ public class TempoTaskDeadline extends AppianObject
/*    */   implements WaitFor
/*    */ {
/* 13 */   private static final Logger LOG = Logger.getLogger(TempoTaskDeadline.class);
/* 14 */   private static final String XPATH_ABSOLUTE_TASK_DEADLINE = Settings.getByConstant("xpathAbsoluteTaskDeadline");
/*    */ 
/*    */   public static TempoTaskDeadline getInstance(Settings settings) {
/* 17 */     return new TempoTaskDeadline(settings);
/*    */   }
/*    */ 
/*    */   private TempoTaskDeadline(Settings settings) {
/* 21 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 26 */     String taskName = getParam(0, params);
/* 27 */     String deadline = getParam(1, params);
/*    */ 
/* 29 */     return xpathFormat(XPATH_ABSOLUTE_TASK_DEADLINE, new Object[] { taskName, deadline });
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 34 */     String taskName = getParam(0, params);
/* 35 */     String deadline = getParam(1, params);
/*    */ 
/* 37 */     if (LOG.isDebugEnabled()) LOG.debug("TASK [" + taskName + "] HAS DEADLINE [" + deadline + "]");
/*    */     try
/*    */     {
/* 40 */       this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/*    */     } catch (Exception e) {
/* 42 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Task deadline", taskName, deadline });
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.task.TempoTaskDeadline
 * JD-Core Version:    0.6.2
 */