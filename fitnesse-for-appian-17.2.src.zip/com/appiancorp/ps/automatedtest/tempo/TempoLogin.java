/*     */ package com.appiancorp.ps.automatedtest.tempo;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.JavascriptExecutor;
/*     */ import org.openqa.selenium.WebDriver;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class TempoLogin extends AppianObject
/*     */ {
/*  16 */   private static final Logger LOG = Logger.getLogger(TempoLogin.class);
/*  17 */   private static final String XPATH_ABSOLUTE_LOGIN_SUBMIT_BUTTON = Settings.getByConstant("xpathAbsoluteLoginSubmitButton");
/*  18 */   private static final String XPATH_ABSOLUTE_LOGIN_AGREE_BUTTON = Settings.getByConstant("xpathAbsoluteLoginAgreeButton");
/*  19 */   private static final String XPATH_ABSOLUTE_LOGOUT_LINK = Settings.getByConstant("xpathAbsoluteLogoutLink");
/*     */ 
/*  21 */   private static final String XPATH_ABSOLUTE_SITE_LOGOUT_LINK = Settings.getByConstant("xpathAbsoluteSiteLogoutLink");
/*  22 */   private static final String XPATH_ABSOLUTE_SITE_USER_PROFILE_LINK = Settings.getByConstant("xpathAbsoluteSiteUserProfileLink");
/*     */ 
/*     */   public static TempoLogin getInstance(Settings settings) {
/*  25 */     return new TempoLogin(settings);
/*     */   }
/*     */ 
/*     */   private TempoLogin(Settings settings) {
/*  29 */     super(settings);
/*     */   }
/*     */ 
/*     */   public void logout() {
/*  33 */     if (LOG.isDebugEnabled()) LOG.debug("LOG OUT");
/*     */ 
/*  35 */     ((JavascriptExecutor)this.settings.getDriver()).executeScript("document.evaluate(\"" + XPATH_ABSOLUTE_LOGOUT_LINK + "\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()", new Object[0]);
/*     */   }
/*     */ 
/*     */   public void waitFor(String[] params)
/*     */   {
/*  40 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR LOGIN");
/*     */ 
/*  44 */     for (int i = 0; i < 6; i++)
/*     */       try {
/*  46 */         waitForTempoLogoutLink(5);
/*     */       }
/*     */       catch (Exception e) {
/*     */         try {
/*  50 */           waitForSitesLogoutLink(5);
/*     */         }
/*     */         catch (Exception ex) {
/*  53 */           if (i == 5)
/*  54 */             throw ExceptionBuilder.build(ex, this.settings, new String[] { "Logout link" });
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   private void waitForTempoLogoutLink(int timeout)
/*     */   {
/*  62 */     new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(By.xpath(XPATH_ABSOLUTE_LOGOUT_LINK)));
/*     */   }
/*     */ 
/*     */   private void waitForSitesLogoutLink(int timeout) {
/*  66 */     WebElement userProfile = this.settings.getDriver().findElement(By.xpath(XPATH_ABSOLUTE_SITE_USER_PROFILE_LINK));
/*  67 */     userProfile.click();
/*     */ 
/*  69 */     new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(
/*  70 */       ExpectedConditions.presenceOfElementLocated(By.xpath(XPATH_ABSOLUTE_SITE_LOGOUT_LINK)));
/*     */ 
/*  71 */     new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.presenceOfElementLocated(By.xpath(XPATH_ABSOLUTE_SITE_LOGOUT_LINK)));
/*     */   }
/*     */ 
/*     */   public void login(String url, String userName, String password) {
/*  75 */     if (LOG.isDebugEnabled()) LOG.debug("LOGIN [" + userName + "]");
/*     */     try
/*     */     {
/*  78 */       WebElement userNameElement = this.settings.getDriver().findElement(By.id("un"));
/*  79 */       userNameElement.clear();
/*  80 */       userNameElement.sendKeys(new CharSequence[] { userName });
/*     */ 
/*  82 */       WebElement passwordElement = this.settings.getDriver().findElement(By.id("pw"));
/*  83 */       passwordElement.clear();
/*  84 */       passwordElement.sendKeys(new CharSequence[] { password });
/*     */ 
/*  87 */       WebElement submitButton = this.settings.getDriver().findElement(By.xpath(XPATH_ABSOLUTE_LOGIN_SUBMIT_BUTTON));
/*  88 */       submitButton.click();
/*     */ 
/*  90 */       waitFor(new String[0]);
/*     */     } catch (Exception e) {
/*  92 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Login page", userName });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void loginWithTerms(String url, String userName, String password) {
/*     */     try {
/*  98 */       WebElement agreeButton = this.settings.getDriver().findElement(By.xpath(XPATH_ABSOLUTE_LOGIN_AGREE_BUTTON));
/*  99 */       agreeButton.click();
/*     */     } catch (Exception e) {
/* 101 */       LOG.error("Terms", e);
/* 102 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Terms" });
/*     */     }
/*     */ 
/* 105 */     waitForLogin();
/* 106 */     login(url, userName, password);
/*     */   }
/*     */ 
/*     */   public void waitForLogin() {
/*     */     try {
/* 111 */       new WebDriverWait(this.settings.getDriver(), 30L).until(ExpectedConditions.presenceOfElementLocated(By.xpath(XPATH_ABSOLUTE_LOGIN_SUBMIT_BUTTON)));
/* 112 */       WebElement submitButton = this.settings.getDriver().findElement(By.xpath(XPATH_ABSOLUTE_LOGIN_SUBMIT_BUTTON));
/*     */ 
/* 114 */       scrollIntoView(submitButton, Boolean.valueOf(true));
/*     */     } catch (Exception e) {
/* 116 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Login" });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void waitForTerms() {
/*     */     try {
/* 122 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(XPATH_ABSOLUTE_LOGIN_AGREE_BUTTON)));
/* 123 */       WebElement agreeButton = this.settings.getDriver().findElement(By.xpath(XPATH_ABSOLUTE_LOGIN_AGREE_BUTTON));
/*     */ 
/* 125 */       scrollIntoView(agreeButton, Boolean.valueOf(true));
/*     */     } catch (Exception e) {
/* 127 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Login" });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void navigateToLoginPage(String url)
/*     */   {
/*     */     try {
/* 134 */       new WebDriverWait(this.settings.getDriver(), 1L).until(ExpectedConditions.presenceOfElementLocated(By.xpath(XPATH_ABSOLUTE_LOGOUT_LINK)));
/*     */     } catch (Exception e) {
/* 136 */       this.settings.getDriver().get(url);
/* 137 */       return;
/*     */     }
/* 139 */     logout();
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.tempo.TempoLogin
 * JD-Core Version:    0.6.2
 */