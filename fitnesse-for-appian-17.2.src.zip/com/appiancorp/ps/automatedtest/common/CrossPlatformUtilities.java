/*   */ package com.appiancorp.ps.automatedtest.common;
/*   */ 
/*   */ import org.openqa.selenium.Keys;
/*   */ import org.openqa.selenium.WebElement;
/*   */ 
/*   */ public class CrossPlatformUtilities
/*   */ {
/*   */   public static void selectAll(WebElement selectedField)
/*   */   {
/* 8 */     if (Settings.getIsMacOs().booleanValue()) {
/* 9 */       selectedField.sendKeys(new CharSequence[] { Keys.ESCAPE });
/* 10 */       selectedField.sendKeys(new CharSequence[] { Keys.chord(new CharSequence[] { Keys.SHIFT, Keys.END }) });
/* 11 */       selectedField.sendKeys(new CharSequence[] { Keys.chord(new CharSequence[] { Keys.SHIFT, Keys.HOME }) });
/*   */     } else {
/* 13 */       selectedField.sendKeys(new CharSequence[] { Keys.chord(new CharSequence[] { Keys.CONTROL, "a" }) });
/*   */     }
/*   */   }
/*   */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.common.CrossPlatformUtilities
 * JD-Core Version:    0.6.2
 */