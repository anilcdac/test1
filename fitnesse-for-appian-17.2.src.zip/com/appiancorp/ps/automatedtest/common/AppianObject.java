/*     */ package com.appiancorp.ps.automatedtest.common;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import com.appiancorp.ps.automatedtest.exception.WaitForWorkingTestException;
/*     */ import java.net.URLEncoder;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.lang3.time.DateUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.By;
/*     */ import org.openqa.selenium.JavascriptExecutor;
/*     */ import org.openqa.selenium.TimeoutException;
/*     */ import org.openqa.selenium.WebDriver;
/*     */ import org.openqa.selenium.WebDriver.TargetLocator;
/*     */ import org.openqa.selenium.WebElement;
/*     */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*     */ import org.openqa.selenium.support.ui.WebDriverWait;
/*     */ 
/*     */ public class AppianObject
/*     */ {
/*  25 */   private static final Logger LOG = Logger.getLogger(AppianObject.class);
/*     */   protected Settings settings;
/*     */   public static final String DATE_ENTRY_FORMAT = "yyyy-MM-dd";
/*     */   public static final String TIME_ENTRY_FORMAT = "HH:mm";
/*     */   public static final String DATETIME_ENTRY_FORMAT = "yyyy-MM-dd HH:mm";
/*  32 */   private static final String XPATH_WORKING = Settings.getByConstant("xpathAbsoluteWorking");
/*     */ 
/*  34 */   private static final Pattern INDEX_PATTERN = Pattern.compile("(.*)?\\[([0-9]+)\\]");
/*     */   private static final String DATETIME_REGEX = "([0-9]{4}-[0-9]{2}-[0-9]{2}([0-9]{2}:[0-9]{2})?)";
/*     */   private static final String DATETIME_CALC_REGEX = "([0-9]{4}-[0-9]{2}-[0-9]{2}([0-9]{2}:[0-9]{2})?)?[+-][0-9]+(minute(s)?|hour(s)?|day(s)?|month(s)?|year(s)?)";
/*     */   private static final String TEST_VARIABLE_PREFIX = "tv!";
/*     */   private static final String TEST_VARIABLE_REGEX = "^tv!.*";
/*     */ 
/*     */   public static AppianObject getInstance(Settings settings)
/*     */   {
/*  41 */     return new AppianObject(settings);
/*     */   }
/*     */ 
/*     */   public AppianObject(Settings settings) {
/*  45 */     this.settings = settings;
/*     */   }
/*     */ 
/*     */   public static boolean isDatetime(String dateTimeString) {
/*  49 */     dateTimeString = dateTimeString.replaceAll("\\s", "");
/*  50 */     return dateTimeString.matches("([0-9]{4}-[0-9]{2}-[0-9]{2}([0-9]{2}:[0-9]{2})?)");
/*     */   }
/*     */ 
/*     */   public static boolean isTestVariable(String variable) {
/*  54 */     return variable.matches("^tv!.*");
/*     */   }
/*     */ 
/*  58 */   public String formatDatetime(String dateTimeString) { dateTimeString = dateTimeString.trim();
/*     */     Date d;
/*     */     try {
/*  61 */       d = parseDate(dateTimeString);
/*     */     }
/*     */     catch (ParseException e)
/*     */     {
/*     */       Date d;
/*  63 */       d = this.settings.getStartDatetime();
/*     */     }
/*     */ 
/*  66 */     return new SimpleDateFormat(this.settings.getDatetimeDisplayFormat()).format(d); }
/*     */ 
/*     */   public boolean isDatetimeCalculation(String dateTimeString)
/*     */   {
/*  70 */     dateTimeString = dateTimeString.replaceAll("\\s", "");
/*  71 */     return dateTimeString.matches("([0-9]{4}-[0-9]{2}-[0-9]{2}([0-9]{2}:[0-9]{2})?)?[+-][0-9]+(minute(s)?|hour(s)?|day(s)?|month(s)?|year(s)?)");
/*     */   }
/*     */ 
/*     */   public String formatDatetimeCalculation(String dateTimeString) {
/*  75 */     dateTimeString = dateTimeString.trim();
/*  76 */     int plusLocation = dateTimeString.indexOf("+");
/*     */     Date d;
/*  79 */     if (plusLocation > 0) {
/*     */       Date d;
/*     */       try { d = parseDate(dateTimeString.substring(0, plusLocation).trim()); }
/*     */       catch (ParseException e)
/*     */       {
/*     */         Date d;
/*  83 */         d = this.settings.getStartDatetime();
/*     */       }
/*     */     } else {
/*  86 */       d = this.settings.getStartDatetime();
/*     */     }
/*     */ 
/*  89 */     int addValue = Integer.parseInt(dateTimeString.substring(plusLocation, dateTimeString.length()).replaceAll("[^0-9]", ""));
/*  90 */     if (dateTimeString.contains("minute"))
/*  91 */       d = DateUtils.addMinutes(d, addValue);
/*  92 */     else if (dateTimeString.contains("hour"))
/*  93 */       d = DateUtils.addHours(d, addValue);
/*  94 */     else if (dateTimeString.contains("day"))
/*  95 */       d = DateUtils.addDays(d, addValue);
/*  96 */     else if (dateTimeString.contains("month"))
/*  97 */       d = DateUtils.addMonths(d, addValue);
/*  98 */     else if (dateTimeString.contains("year")) {
/*  99 */       d = DateUtils.addYears(d, addValue);
/*     */     }
/*     */ 
/* 102 */     return new SimpleDateFormat(this.settings.getDatetimeDisplayFormat()).format(d);
/*     */   }
/*     */ 
/*     */   public Date parseDate(String datetimeString) throws ParseException {
/* 106 */     return DateUtils.parseDateStrictly(datetimeString, new String[] { "yyyy-MM-dd", "yyyy-MM-dd HH:mm", this.settings
/* 109 */       .getDateFormat(), this.settings
/* 110 */       .getDateDisplayFormat(), this.settings
/* 111 */       .getDatetimeFormat(), this.settings
/* 112 */       .getDatetimeDisplayFormat() });
/*     */   }
/*     */ 
/*     */   public String substituteSpecialCharacters(String variable)
/*     */   {
/* 117 */     variable = variable.replaceAll("(\\r(\\n)?|\\n(\\r)?)", "\n");
/* 118 */     return variable;
/*     */   }
/*     */ 
/*     */   public String parseVariable(String variable)
/*     */   {
/* 123 */     variable = substituteSpecialCharacters(variable);
/*     */ 
/* 125 */     if (isDatetimeCalculation(variable))
/* 126 */       return formatDatetimeCalculation(variable);
/* 127 */     if (isDatetime(variable))
/* 128 */       return formatDatetime(variable);
/* 129 */     if (isTestVariable(variable)) {
/* 130 */       return this.settings.getTestVariable(variable.replace("tv!", ""));
/*     */     }
/* 132 */     return variable;
/*     */   }
/*     */ 
/*     */   public String getParam(int index, String[] params)
/*     */   {
/* 137 */     return parseVariable(params[index]);
/*     */   }
/*     */ 
/*     */   public static String escapeForXpath(String variable) {
/* 141 */     variable = variable.toLowerCase();
/* 142 */     if ((variable.contains("'")) || (variable.contains("\""))) {
/* 143 */       return "concat('" + variable.replace("'", "', \"'\", '") + "', '')";
/*     */     }
/* 145 */     return "'" + variable + "'";
/*     */   }
/*     */ 
/*     */   public static String xpathFormat(String template, Object[] params)
/*     */   {
/* 150 */     for (int i = 0; i < params.length; i++) {
/* 151 */       if ((params[i] instanceof String)) {
/* 152 */         params[i] = escapeForXpath((String)params[i]);
/*     */       }
/*     */     }
/*     */ 
/* 156 */     return String.format(template, params);
/*     */   }
/*     */ 
/*     */   public String runExpression(String expression)
/*     */   {
/*     */     try {
/* 162 */       String servletUrl = this.settings.getUrl() + "/plugins/servlet/appianautomatedtest?operation=runExpression&expression=" + 
/* 162 */         URLEncoder.encode(expression, "UTF-8");
/*     */ 
/* 164 */       String returnVal = "";
/*     */ 
/* 167 */       ((JavascriptExecutor)this.settings.getDriver()).executeScript("window.open('" + servletUrl + "','_blank');", new Object[0]);
/*     */ 
/* 170 */       Set handles = this.settings.getDriver().getWindowHandles();
/* 171 */       String popupHandle = "";
/* 172 */       for (String handle : handles) {
/* 173 */         if (!handle.equals(this.settings.getMasterWindowHandle()))
/* 174 */           popupHandle = handle;
/*     */       }
/* 176 */       this.settings.getDriver().switchTo().window(popupHandle);
/*     */ 
/* 178 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds())
/* 179 */         .until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//pre")));
/*     */ 
/* 180 */       returnVal = this.settings.getDriver().findElement(By.xpath("//pre")).getText();
/*     */ 
/* 182 */       LOG.debug("'" + expression + "' equals '" + returnVal + "'");
/*     */ 
/* 185 */       this.settings.getDriver().close();
/*     */ 
/* 187 */       Thread.sleep(500L);
/* 188 */       this.settings.getDriver().switchTo().window(this.settings.getMasterWindowHandle());
/* 189 */       this.settings.getDriver().switchTo().defaultContent();
/*     */ 
/* 191 */       return returnVal;
/*     */     } catch (Exception e) {
/* 193 */       LOG.error(e.getMessage());
/*     */     }
/* 195 */     return null;
/*     */   }
/*     */ 
/*     */   public void waitForWorking(int timeout) {
/*     */     try {
/* 200 */       Thread.sleep(550L);
/* 201 */       new WebDriverWait(this.settings.getDriver(), timeout).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(XPATH_WORKING)));
/* 202 */       Thread.sleep(200L);
/*     */     } catch (InterruptedException e) {
/* 204 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait for Working" });
/*     */     } catch (TimeoutException e) {
/* 206 */       throw new WaitForWorkingTestException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void waitForWorking() {
/* 211 */     waitForWorking(this.settings.getTimeoutSeconds());
/*     */   }
/*     */ 
/*     */   public void clickElement(WebElement element) {
/* 215 */     scrollIntoView(element);
/* 216 */     element.click();
/* 217 */     unfocus();
/*     */   }
/*     */ 
/*     */   public void scrollIntoView(WebElement webElement, Boolean alignToTop)
/*     */   {
/* 222 */     ((JavascriptExecutor)this.settings.getDriver()).executeScript("arguments[0].scrollIntoView(" + alignToTop.toString() + ");", new Object[] { webElement });
/*     */   }
/*     */ 
/*     */   public void scrollIntoView(WebElement webElement) {
/* 226 */     scrollIntoView(webElement, Boolean.valueOf(false));
/*     */   }
/*     */ 
/*     */   public void unfocus() {
/* 230 */     unfocus(Integer.valueOf(this.settings.getTimeoutSeconds()));
/*     */   }
/*     */ 
/*     */   public void unfocus(Integer timeout) {
/* 234 */     ((JavascriptExecutor)this.settings.getDriver()).executeScript("!!document.activeElement ? document.activeElement.blur() : 0", new Object[0]);
/*     */ 
/* 236 */     waitForWorking(timeout.intValue());
/*     */   }
/*     */ 
/*     */   public static boolean isFieldIndex(String fieldNameIndex) {
/* 240 */     return INDEX_PATTERN.matcher(fieldNameIndex).matches();
/*     */   }
/*     */ 
/*     */   public static String getFieldFromFieldIndex(String fieldNameIndex) {
/* 244 */     Matcher m = INDEX_PATTERN.matcher(fieldNameIndex);
/* 245 */     if (m.find()) {
/* 246 */       return m.group(1);
/*     */     }
/* 248 */     return "";
/*     */   }
/*     */ 
/*     */   public static int getIndexFromFieldIndex(String fieldNameIndex)
/*     */   {
/* 253 */     Matcher m = INDEX_PATTERN.matcher(fieldNameIndex);
/* 254 */     if (m.find()) {
/* 255 */       return Integer.parseInt(m.group(2));
/*     */     }
/* 257 */     return 1;
/*     */   }
/*     */ 
/*     */   public static String getXpathLocator(WebElement element)
/*     */   {
/* 262 */     Pattern p = Pattern.compile(".*xpath: (.*)");
/* 263 */     Matcher m = p.matcher(element.toString());
/*     */ 
/* 265 */     if (m.find()) {
/* 266 */       return m.group(1).substring(0, m.group(1).length() - 1);
/*     */     }
/* 268 */     return null;
/*     */   }
/*     */ 
/*     */   public static String getRegexResults(String regex, Integer group, String text)
/*     */   {
/* 273 */     Pattern p = Pattern.compile(regex);
/* 274 */     Matcher m = p.matcher(text.toString());
/*     */ 
/* 276 */     if (m.find()) {
/* 277 */       LOG.debug("REGEX [" + regex + "] RESULTS [" + m.group(group.intValue()) + "]");
/* 278 */       return m.group(group.intValue());
/*     */     }
/* 280 */     return "";
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.common.AppianObject
 * JD-Core Version:    0.6.2
 */