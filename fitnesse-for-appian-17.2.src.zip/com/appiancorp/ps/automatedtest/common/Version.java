/*     */ package com.appiancorp.ps.automatedtest.common;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class Version
/*     */   implements Comparable<Version>
/*     */ {
/*  18 */   public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd MMM yyyy");
/*     */   private static final String SEPARATOR = "._-";
/*  21 */   public static final Version NULL_VERSION = new Version(Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), "");
/*     */   private Integer a;
/*     */   private Integer b;
/*     */   private Integer c;
/*     */   private Integer d;
/*     */   private String actual;
/*     */ 
/*     */   public Version(String version)
/*     */   {
/*  30 */     Version v = parse(version, null);
/*  31 */     this.a = v.a;
/*  32 */     this.b = v.b;
/*  33 */     this.c = v.c;
/*  34 */     this.d = v.d;
/*     */   }
/*     */ 
/*     */   public Version(Integer a) {
/*  38 */     this(a, null, null, null, null);
/*     */   }
/*     */ 
/*     */   public Version(Integer a, Integer b) {
/*  42 */     this(a, b, null, null, null);
/*     */   }
/*     */ 
/*     */   public Version(Integer a, Integer b, Integer c) {
/*  46 */     this(a, b, c, null, null);
/*     */   }
/*     */ 
/*     */   public Version(Integer a, Integer b, Integer c, Integer d) {
/*  50 */     this(a, b, c, d, null);
/*     */   }
/*     */ 
/*     */   public Version(Integer a, Integer b, Integer c, Integer d, String actual) {
/*  54 */     this.a = a;
/*  55 */     this.b = b;
/*  56 */     this.c = c;
/*  57 */     this.d = d;
/*  58 */     this.actual = actual;
/*     */   }
/*     */ 
/*     */   public static Version parse(String version, String actual)
/*     */   {
/*  72 */     Integer a = null;
/*  73 */     Integer b = null;
/*  74 */     Integer c = null;
/*  75 */     Integer d = null;
/*     */ 
/*  77 */     if (version == null) {
/*  78 */       return NULL_VERSION;
/*     */     }
/*     */ 
/*  81 */     version = version.trim();
/*  82 */     if (version.length() == 0) {
/*  83 */       return NULL_VERSION;
/*     */     }
/*     */     try
/*     */     {
/*  87 */       StringTokenizer st = new StringTokenizer(version, "._-", false);
/*  88 */       a = new Integer(st.nextToken());
/*     */ 
/*  90 */       if (st.hasMoreTokens()) {
/*  91 */         b = new Integer(st.nextToken());
/*     */ 
/*  93 */         if (st.hasMoreTokens()) {
/*  94 */           c = new Integer(st.nextToken());
/*     */ 
/*  96 */           if (st.hasMoreTokens())
/*  97 */             d = new Integer(st.nextToken());
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (NoSuchElementException e) {
/* 102 */       IllegalArgumentException iae = new IllegalArgumentException("Invalid version \"" + version + "\": invalid format");
/* 103 */       iae.initCause(e);
/* 104 */       throw iae;
/*     */     } catch (NumberFormatException ne) {
/* 106 */       return new Version(a, b, c, d, actual);
/*     */     }
/*     */ 
/* 109 */     return new Version(a, b, c, d, actual);
/*     */   }
/*     */ 
/*     */   public String getActual() {
/* 113 */     return this.actual;
/*     */   }
/*     */ 
/*     */   public String toNumber() {
/* 117 */     return String.format("%d%d%d%d", new Object[] { this.a, Integer.valueOf(this.b == null ? 0 : this.b.intValue()), Integer.valueOf(this.c == null ? 0 : this.c.intValue()), Integer.valueOf(this.d == null ? 0 : this.d.intValue()) });
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 122 */     if (this.d != null)
/* 123 */       return String.format("%d.%d.%d.%d", new Object[] { this.a, this.b, this.c, this.d });
/* 124 */     if (this.c != null)
/* 125 */       return String.format("%d.%d.%d", new Object[] { this.a, this.b, this.c });
/* 126 */     if (this.b != null) {
/* 127 */       return String.format("%d.%d", new Object[] { this.a, this.b });
/*     */     }
/* 129 */     return String.format("%d", new Object[] { this.a });
/*     */   }
/*     */ 
/*     */   public int match(Version version)
/*     */   {
/* 145 */     if (version == null)
/* 146 */       return 0;
/* 147 */     if (this.a.equals(version.a)) {
/* 148 */       if ((this.b == null) || (version.b == null) || (this.b.equals(version.b))) {
/* 149 */         if ((this.c == null) || (version.c == null) || (this.c.equals(version.c))) {
/* 150 */           if ((this.d == null) || (version.d == null) || (this.d.equals(version.d))) {
/* 151 */             if ((this.actual == null) || (this.actual.equals(version.actual))) {
/* 152 */               return 5;
/*     */             }
/* 154 */             return 4;
/*     */           }
/* 156 */           return 3;
/*     */         }
/* 158 */         return 2;
/*     */       }
/* 160 */       return 1;
/*     */     }
/* 162 */     return 0;
/*     */   }
/*     */ 
/*     */   public static Integer getBestIndexFromList(Version version, List<Version> versions)
/*     */   {
/* 176 */     List vs = new ArrayList(versions);
/*     */ 
/* 179 */     Collections.sort(vs);
/* 180 */     Collections.reverse(vs);
/*     */ 
/* 183 */     int index = vs.size() - 1;
/*     */ 
/* 185 */     for (int i = 0; i < vs.size(); i++) {
/* 186 */       int compare = ((Version)vs.get(i)).compareTo(version);
/*     */ 
/* 189 */       if (compare <= 0) {
/* 190 */         index = i;
/* 191 */         break;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 196 */     return Integer.valueOf(versions.indexOf(vs.get(index)));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 201 */     int prime = 31;
/* 202 */     int result = 1;
/* 203 */     result = 31 * result + (this.a == null ? 0 : this.a.hashCode());
/* 204 */     result = 31 * result + (this.b == null ? 0 : this.b.hashCode());
/* 205 */     result = 31 * result + (this.c == null ? 0 : this.c.hashCode());
/* 206 */     result = 31 * result + (this.d == null ? 0 : this.d.hashCode());
/* 207 */     result = 31 * result + (this.actual == null ? 0 : this.actual.hashCode());
/* 208 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 213 */     if (this == obj)
/* 214 */       return true;
/* 215 */     if (obj == null)
/* 216 */       return false;
/* 217 */     if (getClass() != obj.getClass())
/* 218 */       return false;
/* 219 */     Version other = (Version)obj;
/* 220 */     if (this.a == null) {
/* 221 */       if (other.a != null)
/* 222 */         return false;
/* 223 */     } else if (!this.a.equals(other.a))
/* 224 */       return false;
/* 225 */     if (this.b == null) {
/* 226 */       if (other.b != null)
/* 227 */         return false;
/* 228 */     } else if (!this.b.equals(other.b))
/* 229 */       return false;
/* 230 */     if (this.c == null) {
/* 231 */       if (other.c != null)
/* 232 */         return false;
/* 233 */     } else if (!this.c.equals(other.c))
/* 234 */       return false;
/* 235 */     if (this.d == null) {
/* 236 */       if (other.d != null)
/* 237 */         return false;
/* 238 */     } else if (!this.d.equals(other.d))
/* 239 */       return false;
/* 240 */     if (this.actual == null) {
/* 241 */       if (other.actual != null)
/* 242 */         return false;
/* 243 */     } else if (!this.actual.equals(other.actual))
/* 244 */       return false;
/* 245 */     return true;
/*     */   }
/*     */ 
/*     */   public int compareTo(Version o)
/*     */   {
/* 250 */     if (equals(o)) {
/* 251 */       return 0;
/*     */     }
/* 253 */     int compareValue = 0;
/* 254 */     compareValue = this.a.compareTo(o.a);
/* 255 */     if ((compareValue == 0) && (this.b != null) && (o.b != null)) {
/* 256 */       compareValue = this.b.compareTo(o.b);
/*     */     }
/* 258 */     if ((compareValue == 0) && (this.c != null) && (o.c != null)) {
/* 259 */       compareValue = this.c.compareTo(o.c);
/*     */     }
/* 261 */     if ((compareValue == 0) && (this.d != null) && (o.d != null)) {
/* 262 */       compareValue = this.d.compareTo(o.d);
/*     */     }
/*     */ 
/* 267 */     return compareValue;
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.common.Version
 * JD-Core Version:    0.6.2
 */