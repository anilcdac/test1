/*    */ package com.appiancorp.ps.automatedtest.common;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonCreator;
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import java.util.List;
/*    */ 
/*    */ public class AppianVersion
/*    */ {
/*    */   private Version version;
/*    */   private List<LabelValue> byConstants;
/*    */ 
/*    */   @JsonCreator
/*    */   public AppianVersion(@JsonProperty("version") Version version, @JsonProperty("byConstants") List<LabelValue> byConstants)
/*    */   {
/* 16 */     this.version = version;
/* 17 */     this.byConstants = byConstants;
/*    */   }
/*    */ 
/*    */   public Version getVersion() {
/* 21 */     return this.version;
/*    */   }
/*    */ 
/*    */   public String getByConstant(String name) {
/* 25 */     for (LabelValue by : this.byConstants) {
/* 26 */       if (by.getLabel().equals(name)) {
/* 27 */         return by.getValue();
/*    */       }
/*    */     }
/*    */ 
/* 31 */     return null;
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.common.AppianVersion
 * JD-Core Version:    0.6.2
 */