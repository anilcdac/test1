/*     */ package com.appiancorp.ps.automatedtest.common;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.google.gson.Gson;
/*     */ import com.jayway.jsonpath.JsonPath;
/*     */ import com.jayway.jsonpath.Predicate;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.lang.SystemUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.openqa.selenium.WebDriver;
/*     */ 
/*     */ public class Settings
/*     */ {
/*  24 */   private static final Logger LOG = Logger.getLogger(Settings.class);
/*     */   private static List<AppianVersion> appianVersions;
/*     */   private static List<Version> allVersions;
/*     */   private static List<AppianLocale> appianLocales;
/*     */   private static Boolean isMacOs;
/*     */   private WebDriver driver;
/*     */   private String masterWindowHandle;
/*     */   private String url;
/*  33 */   private static Version version = new Version("7.10");
/*     */   private String locale;
/*  35 */   private int timeoutSeconds = 10;
/*  36 */   private int notPresentTimeoutSeconds = 1;
/*  37 */   private Date startDatetime = new Date();
/*  38 */   private int refreshTimes = 5;
/*  39 */   private int attemptTimes = 3;
/*     */ 
/*  41 */   private String dateFormat = "M/d/yyyy";
/*  42 */   private String dateDisplayFormat = "MMM d, yyyy";
/*  43 */   private String timeFormat = "h:mm aa";
/*  44 */   private String timeDisplayFormat = "h:mm aa";
/*  45 */   private String datetimeFormat = "M/d/yyyy h:mm aa";
/*  46 */   private String datetimeDisplayFormat = "MMM d, yyyy, h:mm aa";
/*     */ 
/*  48 */   private String dataSourceName = null;
/*     */   private String screenshotPath;
/*  51 */   private Boolean takeErrorScreenshots = Boolean.valueOf(false);
/*  52 */   private Boolean stopOnError = Boolean.valueOf(false);
/*  53 */   private int errorNumber = 1;
/*     */ 
/*  55 */   private Map<String, String> testVariables = new HashMap();
/*     */ 
/*     */   @JsonCreator
/*     */   public Settings(@JsonProperty("appianVersions") List<AppianVersion> appianVersions, @JsonProperty("appianLocales") List<AppianLocale> appianLocales)
/*     */   {
/*  61 */     appianVersions = appianVersions;
/*  62 */     appianLocales = appianLocales;
/*  63 */     allVersions = new ArrayList();
/*  64 */     for (AppianVersion av : appianVersions) {
/*  65 */       allVersions.add(av.getVersion());
/*     */     }
/*  67 */     isMacOs = Boolean.valueOf(SystemUtils.IS_OS_MAC);
/*     */   }
/*     */ 
/*     */   public static Boolean getIsMacOs() {
/*  71 */     return isMacOs;
/*     */   }
/*     */ 
/*     */   public static List<AppianVersion> getAppianVersions() {
/*  75 */     return appianVersions;
/*     */   }
/*     */ 
/*     */   public static List<AppianLocale> getAppianLocales() {
/*  79 */     return appianLocales;
/*     */   }
/*     */ 
/*     */   public static String getByConstant(String constant) {
/*  83 */     Integer index = Version.getBestIndexFromList(getVersion(), allVersions);
/*  84 */     AppianVersion appianVersion = (AppianVersion)appianVersions.get(index.intValue());
/*     */ 
/*  87 */     if (appianVersion.getVersion().match(getVersion()) <= 1) {
/*  88 */       throw new IllegalArgumentException(String.format("%s is not a recognized version", new Object[] { getVersion() }));
/*     */     }
/*     */ 
/*  91 */     while (index.intValue() >= 0) {
/*  92 */       String byConstant = appianVersion.getByConstant(constant);
/*  93 */       if (byConstant != null) return byConstant;
/*  94 */       Integer localInteger1 = index; Integer localInteger2 = index = Integer.valueOf(index.intValue() - 1);
/*  95 */       appianVersion = (AppianVersion)appianVersions.get(index.intValue());
/*     */     }
/*     */ 
/*  98 */     return null;
/*     */   }
/*     */ 
/*     */   public static Settings initialize() {
/* 102 */     InputStream in = null;
/*     */     try {
/* 104 */       in = Settings.class.getResource("/metadata.json").openStream();
/* 105 */       return (Settings)new ObjectMapper().readValue(in, Settings.class);
/*     */     }
/*     */     catch (Exception e) {
/* 108 */       LOG.error("Error processing metadata.json resource", e);
/*     */     } finally {
/* 110 */       IOUtils.closeQuietly(in);
/*     */     }
/*     */ 
/* 113 */     return null;
/*     */   }
/*     */ 
/*     */   public void setDriver(WebDriver d) {
/* 117 */     this.driver = d;
/* 118 */     setMasterWindowHandle(d.getWindowHandle());
/*     */   }
/*     */ 
/*     */   public WebDriver getDriver() {
/* 122 */     return this.driver;
/*     */   }
/*     */ 
/*     */   public void setUrl(String u) {
/* 126 */     this.url = (u.endsWith("/") ? u.substring(0, u.length() - 1) : u);
/*     */   }
/*     */ 
/*     */   public String getUrl() {
/* 130 */     return this.url;
/*     */   }
/*     */ 
/*     */   public static void setVersion(String v) {
/* 134 */     version = new Version(v);
/*     */   }
/*     */ 
/*     */   public static Version getVersion() {
/* 138 */     return version;
/*     */   }
/*     */ 
/*     */   public void setLocale(String l) {
/* 142 */     l = getVersion().compareTo(new Version(Integer.valueOf(17), Integer.valueOf(1))) >= 0 ? l + "_17_1" : l;
/* 143 */     for (AppianLocale al : getAppianLocales())
/* 144 */       if (al.getLocale().equals(l)) {
/* 145 */         setDateFormat(al.getDateFormat());
/* 146 */         setDateDisplayFormat(al.getDateDisplayFormat());
/* 147 */         setTimeFormat(al.getTimeFormat());
/* 148 */         setTimeDisplayFormat(al.getTimeDisplayFormat());
/* 149 */         setDatetimeFormat(al.getDatetimeFormat());
/* 150 */         setDatetimeDisplayFormat(al.getDatetimeDisplayFormat());
/*     */       }
/*     */   }
/*     */ 
/*     */   public String getLocale()
/*     */   {
/* 156 */     return this.locale;
/*     */   }
/*     */ 
/*     */   public void setDateFormat(String df) {
/* 160 */     this.dateFormat = df;
/*     */   }
/*     */ 
/*     */   public String getDateFormat() {
/* 164 */     return this.dateFormat;
/*     */   }
/*     */ 
/*     */   public void setDateDisplayFormat(String df) {
/* 168 */     this.dateDisplayFormat = df;
/*     */   }
/*     */ 
/*     */   public String getDateDisplayFormat() {
/* 172 */     return this.dateDisplayFormat;
/*     */   }
/*     */ 
/*     */   public void setTimeFormat(String tf) {
/* 176 */     this.timeFormat = tf;
/*     */   }
/*     */ 
/*     */   public String getTimeFormat() {
/* 180 */     return this.timeFormat;
/*     */   }
/*     */ 
/*     */   public void setTimeDisplayFormat(String tf) {
/* 184 */     this.timeDisplayFormat = tf;
/*     */   }
/*     */ 
/*     */   public String getTimeDisplayFormat() {
/* 188 */     return this.timeDisplayFormat;
/*     */   }
/*     */ 
/*     */   public void setDatetimeFormat(String dtf) {
/* 192 */     this.datetimeFormat = dtf;
/*     */   }
/*     */ 
/*     */   public String getDatetimeFormat() {
/* 196 */     return this.datetimeFormat;
/*     */   }
/*     */ 
/*     */   public void setDatetimeDisplayFormat(String dtf) {
/* 200 */     this.datetimeDisplayFormat = dtf;
/*     */   }
/*     */ 
/*     */   public String getDatetimeDisplayFormat() {
/* 204 */     return this.datetimeDisplayFormat;
/*     */   }
/*     */ 
/*     */   public void setTimeoutSeconds(int t) {
/* 208 */     this.timeoutSeconds = t;
/*     */   }
/*     */ 
/*     */   public int getTimeoutSeconds() {
/* 212 */     return this.timeoutSeconds;
/*     */   }
/*     */ 
/*     */   public void setNotPresentTimeoutSeconds(int t) {
/* 216 */     this.notPresentTimeoutSeconds = t;
/*     */   }
/*     */ 
/*     */   public int getNotPresentTimeoutSeconds() {
/* 220 */     return this.notPresentTimeoutSeconds;
/*     */   }
/*     */ 
/*     */   public void setStartDatetime(Date s) {
/* 224 */     this.startDatetime = s;
/*     */   }
/*     */ 
/*     */   public Date getStartDatetime() {
/* 228 */     return this.startDatetime;
/*     */   }
/*     */ 
/*     */   public void setMasterWindowHandle(String w) {
/* 232 */     this.masterWindowHandle = w;
/*     */   }
/*     */ 
/*     */   public String getMasterWindowHandle() {
/* 236 */     return this.masterWindowHandle;
/*     */   }
/*     */ 
/*     */   public void setDataSourceName(String ds) {
/* 240 */     this.dataSourceName = ds;
/*     */   }
/*     */ 
/*     */   public String getDataSourceName() {
/* 244 */     return this.dataSourceName;
/*     */   }
/*     */ 
/*     */   public void setAttemptTimes(Integer at) {
/* 248 */     this.attemptTimes = at.intValue();
/*     */   }
/*     */ 
/*     */   public Integer getAttemptTimes() {
/* 252 */     return Integer.valueOf(this.attemptTimes);
/*     */   }
/*     */ 
/*     */   public void setRefreshTimes(Integer rt) {
/* 256 */     this.refreshTimes = rt.intValue();
/*     */   }
/*     */ 
/*     */   public Integer getRefreshTimes() {
/* 260 */     return Integer.valueOf(this.refreshTimes);
/*     */   }
/*     */ 
/*     */   public void setScreenshotPath(String sp) {
/* 264 */     this.screenshotPath = sp;
/*     */   }
/*     */ 
/*     */   public String getScreenshotPath() {
/* 268 */     return this.screenshotPath;
/*     */   }
/*     */ 
/*     */   public void setTakeErrorScreenshots(Boolean es) {
/* 272 */     this.takeErrorScreenshots = es;
/*     */   }
/*     */ 
/*     */   public Boolean isTakeErrorScreenshots() {
/* 276 */     return this.takeErrorScreenshots;
/*     */   }
/*     */ 
/*     */   public void setStopOnError(Boolean es) {
/* 280 */     this.stopOnError = es;
/*     */   }
/*     */ 
/*     */   public Boolean isStopOnError() {
/* 284 */     return this.stopOnError;
/*     */   }
/*     */ 
/*     */   public void setErrorNumber(int e) {
/* 288 */     this.errorNumber = e;
/*     */   }
/*     */ 
/*     */   public int getErrorNumber() {
/* 292 */     return this.errorNumber;
/*     */   }
/*     */ 
/*     */   public void setTestVariableWith(String key, String val) {
/* 296 */     this.testVariables.put(key, val);
/*     */   }
/*     */ 
/*     */   public String getTestVariable(String variable) {
/* 300 */     if (variable.contains(".")) {
/* 301 */       String variableKey = StringUtils.substringBefore(variable, ".");
/* 302 */       String variableName = StringUtils.substringAfter(variable, ".");
/* 303 */       LOG.debug("Variable Key: " + variableKey + " and Variable Name: " + variableName);
/* 304 */       Object result = JsonPath.read((String)this.testVariables.get(variableKey), "$." + variableName, new Predicate[0]);
/*     */ 
/* 307 */       if ((result instanceof LinkedHashMap)) {
/* 308 */         Gson gson = new Gson();
/* 309 */         String json = gson.toJson(result, LinkedHashMap.class);
/*     */ 
/* 311 */         return json;
/*     */       }
/* 313 */       return result.toString();
/*     */     }
/*     */ 
/* 316 */     return (String)this.testVariables.get(variable);
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.common.Settings
 * JD-Core Version:    0.6.2
 */