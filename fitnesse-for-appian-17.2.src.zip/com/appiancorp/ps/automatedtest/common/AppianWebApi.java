/*    */ package com.appiancorp.ps.automatedtest.common;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import java.io.DataOutputStream;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URL;
/*    */ import org.apache.commons.codec.binary.Base64;
/*    */ import org.apache.commons.io.IOUtils;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ 
/*    */ public class AppianWebApi
/*    */ {
/*    */   protected Settings settings;
/*    */ 
/*    */   public static AppianWebApi getInstance(Settings settings)
/*    */   {
/* 18 */     return new AppianWebApi(settings);
/*    */   }
/*    */ 
/*    */   public AppianWebApi(Settings settings) {
/* 22 */     this.settings = settings;
/*    */   }
/*    */ 
/*    */   public String callWebApi(String webApi, String body, String username, String password) {
/* 26 */     HttpURLConnection conn = null;
/*    */     try {
/* 28 */       URL url = new URL(this.settings.getUrl() + "/webapi/" + webApi);
/* 29 */       conn = (HttpURLConnection)url.openConnection();
/* 30 */       byte[] encoded = Base64.encodeBase64(new String(username + ":" + password).getBytes());
/* 31 */       conn.setRequestProperty("Authorization", "Basic " + new String(encoded));
/*    */       DataOutputStream wr;
/* 33 */       if (StringUtils.isNotBlank(body)) {
/* 34 */         conn.setDoOutput(true);
/* 35 */         conn.setRequestMethod("POST");
/* 36 */         conn.setRequestProperty("Content-Type", "text/plain; charset=UTF-8");
/* 37 */         wr = new DataOutputStream(conn.getOutputStream());
/* 38 */         wr.write(body.getBytes());
/* 39 */         wr.flush();
/* 40 */         wr.close();
/*    */       } else {
/* 42 */         conn.setRequestMethod("GET");
/* 43 */         conn.setDoOutput(false);
/*    */       }
/*    */ 
/* 46 */       if (conn.getResponseCode() != 200) {
/* 47 */         throw new Exception("Web API request failed:" + conn.getResponseCode());
/*    */       }
/* 49 */       return IOUtils.toString(conn.getInputStream());
/*    */     }
/*    */     catch (Exception e) {
/* 52 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Call Web API" });
/*    */     } finally {
/* 54 */       if (conn != null) conn.disconnect();
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.common.AppianWebApi
 * JD-Core Version:    0.6.2
 */