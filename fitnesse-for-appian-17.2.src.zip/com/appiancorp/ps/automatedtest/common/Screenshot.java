/*    */ package com.appiancorp.ps.automatedtest.common;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.properties.Captureable;
/*    */ import com.google.common.base.Throwables;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import org.apache.commons.io.FileUtils;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.OutputType;
/*    */ import org.openqa.selenium.TakesScreenshot;
/*    */ 
/*    */ public class Screenshot extends AppianObject
/*    */   implements Captureable
/*    */ {
/* 16 */   private static final Logger LOG = Logger.getLogger(AppianObject.class);
/*    */ 
/*    */   public static Screenshot getInstance(Settings settings) {
/* 19 */     return new Screenshot(settings);
/*    */   }
/*    */ 
/*    */   private Screenshot(Settings settings) {
/* 23 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String capture(String[] params)
/*    */   {
/* 28 */     String fileName = params[0];
/*    */ 
/* 30 */     File srcFile = (File)((TakesScreenshot)this.settings.getDriver()).getScreenshotAs(OutputType.FILE);
/*    */     try {
/* 32 */       FileUtils.copyFile(srcFile, new File(this.settings.getScreenshotPath() + fileName + ".png"));
/* 33 */       return this.settings.getScreenshotPath() + fileName + ".png";
/*    */     } catch (IOException e) {
/* 35 */       LOG.error(Throwables.getStackTraceAsString(e));
/* 36 */       throw new RuntimeException(e.getMessage());
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.common.Screenshot
 * JD-Core Version:    0.6.2
 */