package com.appiancorp.ps.automatedtest.common;

public class Constants
{
  public static final String AUTOMATED_TESTING_HOME = "automated.testing.home";
  public static final String CHROME_BROWSER_HOME = "chrome.browser.home";
  public static final String FIREFOX_BROWSER_HOME = "firefox.browser.home";
  public static final String CHROME_DRIVER_HOME = "chrome.driver.home";
  public static final String CHROME_DRIVER = "chromedriver.exe";
  public static final String IE_DRIVER_HOME = "ie.driver.home";
  public static final String IE_DRIVER = "IEDriverServer_32.exe";
  public static final String DRIVERS_LOCATION = "/lib/drivers/";
}

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.common.Constants
 * JD-Core Version:    0.6.2
 */