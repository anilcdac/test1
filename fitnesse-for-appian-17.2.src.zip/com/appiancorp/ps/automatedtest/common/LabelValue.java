/*    */ package com.appiancorp.ps.automatedtest.common;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonCreator;
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ 
/*    */ public class LabelValue
/*    */ {
/*    */   private String label;
/*    */   private String value;
/*    */ 
/*    */   @JsonCreator
/*    */   public LabelValue(@JsonProperty("label") String label, @JsonProperty("value") String value)
/*    */   {
/* 14 */     this.label = label;
/* 15 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String getLabel() {
/* 19 */     return this.label;
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 23 */     return this.value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 28 */     return "{label: \"" + this.label + "\", value: \"" + this.value + "\"}";
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.common.LabelValue
 * JD-Core Version:    0.6.2
 */