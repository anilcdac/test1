/*    */ package com.appiancorp.ps.automatedtest.common;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonCreator;
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ 
/*    */ public class AppianLocale
/*    */ {
/*    */   private String locale;
/*    */   private String dateFormat;
/*    */   private String dateDisplayFormat;
/*    */   private String timeFormat;
/*    */   private String timeDisplayFormat;
/*    */   private String datetimeFormat;
/*    */   private String datetimeDisplayFormat;
/*    */ 
/*    */   @JsonCreator
/*    */   public AppianLocale(@JsonProperty("locale") String locale, @JsonProperty("dateFormat") String dateFormat, @JsonProperty("dateDisplayFormat") String dateDisplayFormat, @JsonProperty("timeFormat") String timeFormat, @JsonProperty("timeDisplayFormat") String timeDisplayFormat, @JsonProperty("datetimeFormat") String datetimeFormat, @JsonProperty("datetimeDisplayFormat") String datetimeDisplayFormat)
/*    */   {
/* 24 */     this.locale = locale;
/* 25 */     this.dateFormat = dateFormat;
/* 26 */     this.dateDisplayFormat = dateDisplayFormat;
/* 27 */     this.timeFormat = timeFormat;
/* 28 */     this.timeDisplayFormat = timeDisplayFormat;
/* 29 */     this.datetimeFormat = datetimeFormat;
/* 30 */     this.datetimeDisplayFormat = datetimeDisplayFormat;
/*    */   }
/*    */ 
/*    */   public String getLocale() {
/* 34 */     return this.locale;
/*    */   }
/*    */ 
/*    */   public String getDateFormat() {
/* 38 */     return this.dateFormat;
/*    */   }
/*    */ 
/*    */   public String getDateDisplayFormat() {
/* 42 */     return this.dateDisplayFormat;
/*    */   }
/*    */ 
/*    */   public String getTimeFormat() {
/* 46 */     return this.timeFormat;
/*    */   }
/*    */ 
/*    */   public String getTimeDisplayFormat() {
/* 50 */     return this.timeDisplayFormat;
/*    */   }
/*    */ 
/*    */   public String getDatetimeFormat() {
/* 54 */     return this.datetimeFormat;
/*    */   }
/*    */ 
/*    */   public String getDatetimeDisplayFormat() {
/* 58 */     return this.datetimeDisplayFormat;
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.common.AppianLocale
 * JD-Core Version:    0.6.2
 */