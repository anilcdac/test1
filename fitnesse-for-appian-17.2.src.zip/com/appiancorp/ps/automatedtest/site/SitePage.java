/*    */ package com.appiancorp.ps.automatedtest.site;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*    */ import com.appiancorp.ps.automatedtest.properties.Clickable;
/*    */ import com.appiancorp.ps.automatedtest.properties.Navigateable;
/*    */ import com.appiancorp.ps.automatedtest.properties.WaitFor;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.By;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ import org.openqa.selenium.WebElement;
/*    */ import org.openqa.selenium.support.ui.ExpectedConditions;
/*    */ import org.openqa.selenium.support.ui.WebDriverWait;
/*    */ 
/*    */ public class SitePage extends AppianObject
/*    */   implements WaitFor, Clickable, Navigateable
/*    */ {
/* 18 */   private static final Logger LOG = Logger.getLogger(SitePage.class);
/* 19 */   private static final String XPATH_ABSOLUTE_SITE_PAGE_LINK = Settings.getByConstant("xpathAbsoluteSitePageLink");
/* 20 */   private static final String XPATH_ABSOLUTE_SITE_LOGOUT_LINK = Settings.getByConstant("xpathAbsoluteSiteLogoutLink");
/* 21 */   private static final String XPATH_ABSOLUTE_SITE_USER_PROFILE_LINK = Settings.getByConstant("xpathAbsoluteSiteUserProfileLink");
/*    */ 
/*    */   public static SitePage getInstance(Settings settings) {
/* 24 */     return new SitePage(settings);
/*    */   }
/*    */ 
/*    */   private SitePage(Settings settings) {
/* 28 */     super(settings);
/*    */   }
/*    */ 
/*    */   public String getXpath(String[] params)
/*    */   {
/* 33 */     String sitePage = getParam(0, params);
/*    */ 
/* 35 */     return xpathFormat(XPATH_ABSOLUTE_SITE_PAGE_LINK, new Object[] { sitePage });
/*    */   }
/*    */ 
/*    */   public void click(String[] params)
/*    */   {
/* 40 */     String sitePage = getParam(0, params);
/*    */ 
/* 42 */     if (LOG.isDebugEnabled()) LOG.debug("CLICK [" + sitePage + "]");
/*    */     try
/*    */     {
/* 45 */       WebElement menu = this.settings.getDriver().findElement(By.xpath(getXpath(params)));
/* 46 */       clickElement(menu);
/*    */     } catch (Exception e) {
/* 48 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Site Page", sitePage });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void waitFor(String[] params)
/*    */   {
/* 54 */     String sitePage = getParam(0, params);
/*    */ 
/* 56 */     if (LOG.isDebugEnabled()) LOG.debug("WAIT FOR [" + sitePage + "]");
/*    */     try
/*    */     {
/* 59 */       new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(ExpectedConditions.presenceOfElementLocated(By.xpath(getXpath(params))));
/*    */     } catch (Exception e) {
/* 61 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Site Page", sitePage });
/*    */     }
/*    */   }
/*    */ 
/*    */   public void navigateTo(String[] params)
/*    */   {
/* 67 */     String siteUrl = getParam(0, params);
/* 68 */     String pageUrl = getParam(1, params);
/*    */ 
/* 70 */     if (LOG.isDebugEnabled()) LOG.debug("NAVIGATE TO SITE [" + siteUrl + "] PAGE [" + pageUrl + "]");
/*    */ 
/* 72 */     String url = this.settings.getUrl() + "/sites/" + siteUrl + "/page/" + pageUrl;
/* 73 */     this.settings.getDriver().get(url);
/*    */   }
/*    */ 
/*    */   public void logout() {
/* 77 */     if (LOG.isDebugEnabled()) LOG.debug("LOG OUT");
/*    */ 
/* 79 */     WebElement userProfile = this.settings.getDriver().findElement(By.xpath(XPATH_ABSOLUTE_SITE_USER_PROFILE_LINK));
/* 80 */     userProfile.click();
/*    */ 
/* 82 */     new WebDriverWait(this.settings.getDriver(), this.settings.getTimeoutSeconds()).until(
/* 83 */       ExpectedConditions.presenceOfElementLocated(By.xpath(XPATH_ABSOLUTE_SITE_LOGOUT_LINK)));
/*    */ 
/* 85 */     WebElement logoutLink = this.settings.getDriver().findElement(By.xpath(XPATH_ABSOLUTE_SITE_LOGOUT_LINK));
/* 86 */     logoutLink.click();
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.site.SitePage
 * JD-Core Version:    0.6.2
 */