/*    */ package com.appiancorp.ps.automatedtest.site;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.properties.Navigateable;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.openqa.selenium.WebDriver;
/*    */ 
/*    */ public class Site extends AppianObject
/*    */   implements Navigateable
/*    */ {
/* 11 */   private static final Logger LOG = Logger.getLogger(Site.class);
/*    */ 
/*    */   public static Site getInstance(Settings settings) {
/* 14 */     return new Site(settings);
/*    */   }
/*    */ 
/*    */   private Site(Settings settings) {
/* 18 */     super(settings);
/*    */   }
/*    */ 
/*    */   public void navigateTo(String[] params)
/*    */   {
/* 23 */     String siteUrl = params[0];
/*    */ 
/* 25 */     if (LOG.isDebugEnabled()) LOG.debug("NAVIGATE TO SITE [" + siteUrl + "]");
/*    */ 
/* 27 */     String url = this.settings.getUrl() + "/sites/" + siteUrl;
/* 28 */     this.settings.getDriver().get(url);
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.site.Site
 * JD-Core Version:    0.6.2
 */