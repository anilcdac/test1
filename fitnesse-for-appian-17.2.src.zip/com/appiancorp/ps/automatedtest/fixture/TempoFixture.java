/*      */ package com.appiancorp.ps.automatedtest.fixture;
/*      */ 
/*      */ import com.appiancorp.ps.automatedtest.common.Settings;
/*      */ import com.appiancorp.ps.automatedtest.tempo.TempoError;
/*      */ import com.appiancorp.ps.automatedtest.tempo.TempoLogin;
/*      */ import com.appiancorp.ps.automatedtest.tempo.TempoMenu;
/*      */ import com.appiancorp.ps.automatedtest.tempo.TempoSearch;
/*      */ import com.appiancorp.ps.automatedtest.tempo.action.TempoAction;
/*      */ import com.appiancorp.ps.automatedtest.tempo.action.TempoActionApplicationFilter;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoButton;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoChart;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoCheckboxFieldOption;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoField;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoFieldFactory;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoFieldValidation;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoFormInstructions;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoFormTitle;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGrid;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridAddRow;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridCell;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridColumn;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridNavigation;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridRow;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridRowCount;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridSelectAll;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoGridTotalCount;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoLinkField;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoLinkFieldUrl;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoMilestoneFieldStep;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoRadioFieldOption;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoSaveChanges;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoSection;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoSectionField;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoSectionToggle;
/*      */ import com.appiancorp.ps.automatedtest.tempo.interfaces.TempoSectionValidation;
/*      */ import com.appiancorp.ps.automatedtest.tempo.news.TempoNewsItem;
/*      */ import com.appiancorp.ps.automatedtest.tempo.news.TempoNewsItemComment;
/*      */ import com.appiancorp.ps.automatedtest.tempo.news.TempoNewsItemMoreInfo;
/*      */ import com.appiancorp.ps.automatedtest.tempo.news.TempoNewsItemMoreInfoLabelValue;
/*      */ import com.appiancorp.ps.automatedtest.tempo.news.TempoNewsItemTag;
/*      */ import com.appiancorp.ps.automatedtest.tempo.record.TempoRecord;
/*      */ import com.appiancorp.ps.automatedtest.tempo.record.TempoRecordGridColumn;
/*      */ import com.appiancorp.ps.automatedtest.tempo.record.TempoRecordGridNavigation;
/*      */ import com.appiancorp.ps.automatedtest.tempo.record.TempoRecordRelatedAction;
/*      */ import com.appiancorp.ps.automatedtest.tempo.record.TempoRecordType;
/*      */ import com.appiancorp.ps.automatedtest.tempo.record.TempoRecordTypeUserFilter;
/*      */ import com.appiancorp.ps.automatedtest.tempo.record.TempoRecordView;
/*      */ import com.appiancorp.ps.automatedtest.tempo.report.TempoReport;
/*      */ import com.appiancorp.ps.automatedtest.tempo.task.TempoTask;
/*      */ import com.appiancorp.ps.automatedtest.tempo.task.TempoTaskDeadline;
/*      */ import com.appiancorp.ps.automatedtest.tempo.task.TempoTaskReport;
/*      */ import org.apache.log4j.Logger;
/*      */ 
/*      */ public class TempoFixture extends BaseFixture
/*      */ {
/*   63 */   private static final Logger LOG = Logger.getLogger(TempoFixture.class);
/*      */ 
/*      */   public void clickOnMenu(String tempoMenu)
/*      */   {
/*   78 */     TempoMenu.getInstance(this.settings).waitFor(new String[] { tempoMenu });
/*   79 */     TempoMenu.getInstance(this.settings).click(new String[] { tempoMenu });
/*      */   }
/*      */ 
/*      */   public void searchFor(String searchTerm)
/*      */   {
/*   91 */     TempoSearch.getInstance(this.settings).waitFor(new String[] { searchTerm });
/*   92 */     TempoSearch.getInstance(this.settings).populate(new String[] { searchTerm });
/*      */   }
/*      */ 
/*      */   public void logout()
/*      */   {
/*  100 */     TempoLogin.getInstance(this.settings).waitFor(new String[0]);
/*  101 */     TempoLogin.getInstance(this.settings).logout();
/*      */   }
/*      */ 
/*      */   public boolean verifyNewsFeedContainingTextIsPresent(String newsText)
/*      */   {
/*  119 */     TempoNewsItem.getInstance(this.settings).refreshAndWaitFor(new String[] { newsText });
/*  120 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyNewsFeedContainingTextIsNotPresent(String newsText)
/*      */   {
/*  136 */     return !TempoNewsItem.getInstance(this.settings).waitForReturn(this.settings.getNotPresentTimeoutSeconds(), new String[] { newsText });
/*      */   }
/*      */ 
/*      */   public void toggleMoreInfoForNewsFeedContainingText(String newsText)
/*      */   {
/*  148 */     TempoNewsItemMoreInfo.getInstance(this.settings).waitFor(new String[] { newsText });
/*  149 */     TempoNewsItemMoreInfo.getInstance(this.settings).click(new String[] { newsText });
/*      */   }
/*      */ 
/*      */   public void deleteNewsPost(String newsText)
/*      */   {
/*  161 */     TempoNewsItem.getInstance(this.settings).waitFor(new String[] { newsText });
/*  162 */     TempoNewsItem.getInstance(this.settings).clear(new String[] { newsText });
/*      */   }
/*      */ 
/*      */   public void deleteAllNewsPosts()
/*      */   {
/*  172 */     TempoNewsItem.getInstance(this.settings).clearAll(new String[0]);
/*      */   }
/*      */ 
/*      */   public boolean verifyNewsFeedContainingTextAndMoreInfoWithLabelAndValueIsPresent(String newsText, String label, String value)
/*      */   {
/*  190 */     TempoNewsItemMoreInfoLabelValue.getInstance(this.settings).refreshAndWaitFor(new String[] { newsText });
/*  191 */     TempoNewsItemMoreInfoLabelValue.getInstance(this.settings).waitFor(new String[] { newsText, label, value });
/*  192 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyNewsFeedContainingTextTaggedWithIsPresent(String newsText, String newsTag)
/*      */   {
/*  207 */     TempoNewsItemTag.getInstance(this.settings).refreshAndWaitFor(new String[] { newsText, newsTag });
/*  208 */     TempoNewsItemTag.getInstance(this.settings).waitFor(new String[] { newsText, newsTag });
/*  209 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyNewsFeedContainingTextCommentedWithIsPresent(String newsText, String newsComment)
/*      */   {
/*  224 */     TempoNewsItemComment.getInstance(this.settings).refreshAndWaitFor(new String[] { newsText, newsComment });
/*  225 */     return true;
/*      */   }
/*      */ 
/*      */   public String getRegexGroupFromNewsFeedContainingText(String regex, Integer group, String newsText)
/*      */   {
/*  244 */     TempoNewsItem.getInstance(this.settings).refreshAndWaitFor(new String[] { newsText });
/*  245 */     return TempoNewsItem.getInstance(this.settings).regexCapture(regex, group, new String[] { newsText });
/*      */   }
/*      */ 
/*      */   public String getRegexGroupFromNewsFeedContainingTextCommentedWith(String regex, Integer group, String newsText, String newsComment)
/*      */   {
/*  267 */     TempoNewsItemComment.getInstance(this.settings).refreshAndWaitFor(new String[] { newsText, newsComment });
/*  268 */     return TempoNewsItemComment.getInstance(this.settings).regexCapture(regex, group, new String[] { newsText, newsComment });
/*      */   }
/*      */ 
/*      */   public void clickOnNewsFeedRecordTag(String newsText, String recordTag)
/*      */   {
/*  282 */     TempoNewsItemTag.getInstance(this.settings).refreshAndWaitFor(new String[] { newsText, recordTag });
/*  283 */     TempoNewsItemTag.getInstance(this.settings).click(new String[] { newsText, recordTag });
/*      */   }
/*      */ 
/*      */   public void clickOnTask(String taskName)
/*      */   {
/*  300 */     TempoTask.getInstance(this.settings).refreshAndWaitFor(new String[] { taskName });
/*  301 */     TempoTask.getInstance(this.settings).click(new String[] { taskName });
/*      */   }
/*      */ 
/*      */   public String getRegexGroupFromTaskNameContainingText(String regex, Integer group, String taskText)
/*      */   {
/*  318 */     TempoTask.getInstance(this.settings).refreshAndWaitFor(new String[] { taskText });
/*  319 */     return TempoTask.getInstance(this.settings).regexCapture(regex, group, new String[] { taskText });
/*      */   }
/*      */ 
/*      */   public boolean verifyTaskIsPresent(String taskName)
/*      */   {
/*  332 */     TempoTask.getInstance(this.settings).refreshAndWaitFor(new String[] { taskName });
/*  333 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyTaskIsNotPresent(String taskName)
/*      */   {
/*  348 */     return !TempoTask.getInstance(this.settings).waitForReturn(this.settings.getNotPresentTimeoutSeconds(), new String[] { taskName });
/*      */   }
/*      */ 
/*      */   public boolean verifyTaskHasDeadlineOf(String taskName, String deadline)
/*      */   {
/*  363 */     TempoTaskDeadline.getInstance(this.settings).waitFor(new String[] { taskName, deadline });
/*  364 */     return true;
/*      */   }
/*      */ 
/*      */   public void clickOnTaskReport(String taskReport)
/*      */   {
/*  376 */     TempoTaskReport.getInstance(this.settings).waitFor(new String[] { taskReport });
/*  377 */     TempoTaskReport.getInstance(this.settings).click(new String[] { taskReport });
/*      */   }
/*      */ 
/*      */   public void clickOnRecordType(String typeName)
/*      */   {
/*  390 */     TempoRecordType.getInstance(this.settings).waitFor(new String[] { typeName });
/*  391 */     TempoRecordType.getInstance(this.settings).click(new String[] { typeName });
/*      */   }
/*      */ 
/*      */   public void clickOnRecordTypeUserFilter(String userFilter)
/*      */   {
/*  404 */     TempoRecordTypeUserFilter.getInstance(this.settings).waitFor(new String[] { userFilter });
/*  405 */     TempoRecordTypeUserFilter.getInstance(this.settings).click(new String[] { userFilter });
/*      */   }
/*      */ 
/*      */   public boolean verifyRecordTypeUserFilterIsPresent(String userFilter)
/*      */   {
/*  418 */     TempoRecordTypeUserFilter.getInstance(this.settings).waitFor(new String[] { userFilter });
/*  419 */     return true;
/*      */   }
/*      */ 
/*      */   public void clickOnRecord(String recordName)
/*      */   {
/*  432 */     TempoRecord.getInstance(this.settings).refreshAndWaitFor(new String[] { recordName });
/*  433 */     TempoRecord.getInstance(this.settings).click(new String[] { recordName });
/*      */   }
/*      */ 
/*      */   public String getRegexGroupFromRecordNameContainingText(String regex, Integer group, String recordText)
/*      */   {
/*  451 */     TempoRecord.getInstance(this.settings).refreshAndWaitFor(new String[] { recordText });
/*  452 */     return TempoRecord.getInstance(this.settings).regexCapture(regex, group, new String[] { recordText });
/*      */   }
/*      */ 
/*      */   public boolean verifyRecordIsPresent(String recordName)
/*      */   {
/*  465 */     TempoRecord.getInstance(this.settings).waitFor(new String[] { recordName });
/*  466 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyRecordIsNotPresent(String recordName)
/*      */   {
/*  481 */     return !TempoRecord.getInstance(this.settings).waitForReturn(this.settings.getNotPresentTimeoutSeconds(), new String[] { recordName });
/*      */   }
/*      */ 
/*      */   public void clickOnRecordView(String viewName)
/*      */   {
/*  494 */     TempoRecordView.getInstance(this.settings).waitFor(new String[] { viewName });
/*  495 */     TempoRecordView.getInstance(this.settings).click(new String[] { viewName });
/*      */   }
/*      */ 
/*      */   public void clickOnRecordRelatedAction(String relatedActionName)
/*      */   {
/*  508 */     TempoRecordRelatedAction.getInstance(this.settings).refreshAndWaitFor(new String[] { relatedActionName });
/*  509 */     TempoRecordRelatedAction.getInstance(this.settings).click(new String[] { relatedActionName });
/*      */   }
/*      */ 
/*      */   public boolean verifyRecordRelatedActionIsPresent(String relatedActionName)
/*      */   {
/*  522 */     TempoRecordRelatedAction.getInstance(this.settings).refreshAndWaitFor(new String[] { relatedActionName });
/*  523 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyRecordRelatedActionIsNotPresent(String relatedActionName)
/*      */   {
/*  540 */     return !TempoRecord.getInstance(this.settings).waitForReturn(this.settings.getNotPresentTimeoutSeconds(), new String[] { relatedActionName });
/*      */   }
/*      */ 
/*      */   public void sortRecordGridByColumn(String columnName)
/*      */   {
/*  553 */     TempoRecordGridColumn.getInstance(this.settings).waitFor(new String[] { columnName });
/*  554 */     TempoRecordGridColumn.getInstance(this.settings).click(new String[] { columnName });
/*      */   }
/*      */ 
/*      */   public void clickOnRecordGridNavigation(String navOption)
/*      */   {
/*  567 */     TempoRecordGridNavigation.getInstance(this.settings).waitFor(new String[] { navOption });
/*  568 */     TempoRecordGridNavigation.getInstance(this.settings).click(new String[] { navOption });
/*      */   }
/*      */ 
/*      */   public void clickOnReport(String reportName)
/*      */   {
/*  585 */     TempoReport.getInstance(this.settings).waitFor(new String[] { reportName });
/*  586 */     TempoReport.getInstance(this.settings).click(new String[] { reportName });
/*      */   }
/*      */ 
/*      */   public boolean verifyReportIsPresent(String reportName)
/*      */   {
/*  599 */     TempoReport.getInstance(this.settings).waitFor(new String[] { reportName });
/*  600 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyReportIsNotPresent(String reportName)
/*      */   {
/*  615 */     TempoReport.getInstance(this.settings).waitForReturn(this.settings.getNotPresentTimeoutSeconds(), new String[] { reportName });
/*  616 */     return true;
/*      */   }
/*      */ 
/*      */   public void clickOnAction(String actionName)
/*      */   {
/*  633 */     TempoAction.getInstance(this.settings).waitFor(new String[] { actionName });
/*  634 */     TempoAction.getInstance(this.settings).click(new String[] { actionName });
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public boolean verifyActionCompleted()
/*      */   {
/*  647 */     TempoAction.getInstance(this.settings).complete(new String[0]);
/*  648 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyActionIsPresent(String actionName)
/*      */   {
/*  661 */     TempoAction.getInstance(this.settings).waitFor(new String[] { actionName });
/*  662 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyActionIsNotPresent(String actionName)
/*      */   {
/*  677 */     return !TempoAction.getInstance(this.settings).waitForReturn(this.settings.getNotPresentTimeoutSeconds(), new String[] { actionName });
/*      */   }
/*      */ 
/*      */   public void clickOnApplicationFilter(String appFilter)
/*      */   {
/*  690 */     TempoActionApplicationFilter.getInstance(this.settings).waitFor(new String[] { appFilter });
/*  691 */     TempoActionApplicationFilter.getInstance(this.settings).click(new String[] { appFilter });
/*      */   }
/*      */ 
/*      */   public boolean verifyApplicationFilterIsPresent(String applicationName)
/*      */   {
/*  704 */     TempoAction.getInstance(this.settings).waitFor(new String[] { applicationName });
/*  705 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyApplicationFilterIsNotPresent(String applicationName)
/*      */   {
/*  721 */     return !TempoAction.getInstance(this.settings).waitForReturn(this.settings.getNotPresentTimeoutSeconds(), new String[] { applicationName });
/*      */   }
/*      */ 
/*      */   public String getFormTitle()
/*      */   {
/*  740 */     TempoFormTitle.getInstance(this.settings).waitFor(new String[0]);
/*  741 */     return TempoFormTitle.getInstance(this.settings).capture(new String[0]);
/*      */   }
/*      */ 
/*      */   public String getRegexGroupFromFormTitle(String regex, Integer group)
/*      */   {
/*  756 */     TempoFormTitle.getInstance(this.settings).waitFor(new String[0]);
/*  757 */     return TempoFormTitle.getInstance(this.settings).regexCapture(regex, group, new String[0]);
/*      */   }
/*      */ 
/*      */   public String getFormInstructions()
/*      */   {
/*  772 */     TempoFormInstructions.getInstance(this.settings).waitFor(new String[0]);
/*  773 */     return TempoFormInstructions.getInstance(this.settings).capture(new String[0]);
/*      */   }
/*      */ 
/*      */   public void populateFieldWith(String fieldName, String[] fieldValues)
/*      */   {
/*  787 */     TempoField.getInstance(this.settings).waitFor(new String[] { fieldName });
/*  788 */     TempoFieldFactory.getInstance(this.settings).populateMultiple(fieldValues, new String[] { fieldName });
/*      */   }
/*      */ 
/*      */   public void populateFieldWith(String fieldType, String fieldName, String[] fieldValues)
/*      */   {
/*  804 */     TempoFieldFactory.getInstance(this.settings).waitFor(new String[] { fieldType, fieldName });
/*  805 */     TempoFieldFactory.getInstance(this.settings).populateMultiple(fieldValues, new String[] { fieldType, fieldName });
/*      */   }
/*      */ 
/*      */   public void populateFieldWithValue(String fieldName, String fieldValue)
/*      */   {
/*  819 */     populateFieldWith(fieldName, new String[] { fieldValue });
/*      */   }
/*      */ 
/*      */   public void populateFieldInSectionWith(String fieldName, String sectionName, String[] fieldValues)
/*      */   {
/*  835 */     TempoSection.getInstance(this.settings).waitFor(new String[] { fieldName, sectionName });
/*  836 */     TempoSectionField.getInstance(this.settings).populateMultiple(fieldValues, new String[] { fieldName, sectionName });
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public void expandSection(String sectionName)
/*      */   {
/*  850 */     TempoSectionToggle.getInstance(this.settings).waitFor(new String[] { sectionName });
/*  851 */     TempoSectionToggle.getInstance(this.settings).click(new String[] { sectionName });
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public void collapseSection(String sectionName)
/*      */   {
/*  865 */     TempoSectionToggle.getInstance(this.settings).waitFor(new String[] { sectionName });
/*  866 */     TempoSectionToggle.getInstance(this.settings).click(new String[] { sectionName });
/*      */   }
/*      */ 
/*      */   public void toggleSectionVisibility(String sectionName)
/*      */   {
/*  879 */     TempoSectionToggle.getInstance(this.settings).waitFor(new String[] { sectionName });
/*  880 */     TempoSectionToggle.getInstance(this.settings).click(new String[] { sectionName });
/*      */   }
/*      */ 
/*      */   public void clearField(String fieldName)
/*      */   {
/*  893 */     TempoField.getInstance(this.settings).waitFor(new String[] { fieldName });
/*  894 */     TempoFieldFactory.getInstance(this.settings).clear(new String[] { fieldName });
/*      */   }
/*      */ 
/*      */   public void clearFieldOf(String fieldName, String[] fieldValues)
/*      */   {
/*  909 */     TempoField.getInstance(this.settings).waitFor(new String[] { fieldName });
/*  910 */     TempoFieldFactory.getInstance(this.settings).clearOf(fieldValues, new String[] { fieldName });
/*      */   }
/*      */ 
/*      */   public String getFieldValue(String fieldName)
/*      */   {
/*  931 */     TempoField.getInstance(this.settings).waitFor(new String[] { fieldName });
/*  932 */     return TempoFieldFactory.getInstance(this.settings).capture(new String[] { fieldName });
/*      */   }
/*      */ 
/*      */   public String getRegexGroupFromFieldValue(String regex, Integer group, String fieldName)
/*      */   {
/*  949 */     TempoField.getInstance(this.settings).waitFor(new String[] { fieldName });
/*  950 */     return TempoFieldFactory.getInstance(this.settings).regexCapture(regex, group, new String[] { fieldName });
/*      */   }
/*      */ 
/*      */   public String getFieldInSectionValue(String fieldName, String sectionName)
/*      */   {
/*  974 */     TempoSection.getInstance(this.settings).waitFor(new String[] { fieldName, sectionName });
/*  975 */     return TempoSectionField.getInstance(this.settings).capture(new String[] { fieldName, sectionName });
/*      */   }
/*      */ 
/*      */   public String getRegexGroupFromFieldInSectionValue(String regex, Integer group, String fieldName, String sectionName)
/*      */   {
/*  995 */     TempoSectionField.getInstance(this.settings).waitFor(new String[] { fieldName, sectionName });
/*  996 */     return TempoSectionField.getInstance(this.settings).regexCapture(regex, group, new String[] { fieldName, sectionName });
/*      */   }
/*      */ 
/*      */   public boolean verifyFieldContains(String fieldName, String[] fieldValues)
/*      */   {
/* 1015 */     TempoField.getInstance(this.settings).waitFor(new String[] { fieldName });
/* 1016 */     return TempoFieldFactory.getInstance(this.settings).containsMultiple(fieldValues, new String[] { fieldName });
/*      */   }
/*      */ 
/*      */   public boolean verifyFieldContainsValue(String fieldName, String fieldValue)
/*      */   {
/* 1032 */     return verifyFieldContains(fieldName, new String[] { fieldValue });
/*      */   }
/*      */ 
/*      */   public boolean verifyFieldInSectionContains(String fieldName, String sectionName, String[] fieldValues)
/*      */   {
/* 1054 */     TempoSection.getInstance(this.settings).waitFor(new String[] { fieldName, sectionName });
/* 1055 */     return TempoSectionField.getInstance(this.settings).containsMultiple(fieldValues, new String[] { fieldName, sectionName });
/*      */   }
/*      */ 
/*      */   public boolean verifyFieldContainsValidationMessage(String fieldName, String[] validationMessages)
/*      */   {
/* 1070 */     TempoFieldValidation.getInstance(this.settings).waitForMultiple(validationMessages, new String[] { fieldName });
/* 1071 */     return true;
/*      */   }
/*      */ 
/*      */   public String getFieldValidationMessage(String fieldName)
/*      */   {
/* 1089 */     TempoField.getInstance(this.settings).waitFor(new String[] { fieldName });
/* 1090 */     return TempoFieldValidation.getInstance(this.settings).capture(new String[] { fieldName });
/*      */   }
/*      */ 
/*      */   public boolean verifyFieldIsPresent(String fieldName)
/*      */   {
/* 1103 */     TempoField.getInstance(this.settings).waitFor(new String[] { fieldName });
/* 1104 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyFieldIsNotPresent(String fieldName)
/*      */   {
/* 1117 */     return !TempoField.getInstance(this.settings).waitForReturn(this.settings.getNotPresentTimeoutSeconds(), new String[] { fieldName });
/*      */   }
/*      */ 
/*      */   public void populateGridColumnRowWith(String gridName, String columnName, String rowNum, String[] fieldValues)
/*      */   {
/* 1146 */     TempoGridCell.getInstance(this.settings).waitFor(new String[] { gridName, columnName, rowNum });
/* 1147 */     TempoGridCell.getInstance(this.settings).populateMultiple(fieldValues, new String[] { gridName, columnName, rowNum });
/*      */   }
/*      */ 
/*      */   public void populateGridColumnRowWithValue(String gridName, String columnName, String rowNum, String fieldValue)
/*      */   {
/* 1166 */     populateGridColumnRowWith(gridName, columnName, rowNum, new String[] { fieldValue });
/*      */   }
/*      */ 
/*      */   public void clickOnGridColumnRow(String gridName, String columnName, String rowNum)
/*      */   {
/* 1183 */     TempoGridCell.getInstance(this.settings).waitFor(new String[] { gridName, columnName, rowNum });
/* 1184 */     TempoGridCell.getInstance(this.settings).click(new String[] { gridName, columnName, rowNum });
/*      */   }
/*      */ 
/*      */   public String getGridColumnRowValue(String gridName, String columnName, String rowNum)
/*      */   {
/* 1208 */     TempoGridCell.getInstance(this.settings).waitFor(new String[] { gridName, columnName, rowNum });
/* 1209 */     return TempoGridCell.getInstance(this.settings).capture(new String[] { gridName, columnName, rowNum });
/*      */   }
/*      */ 
/*      */   public String getRegexGroupFromGridColumnRowValue(String regex, Integer group, String gridName, String columnName, String rowNum)
/*      */   {
/* 1231 */     TempoGrid.getInstance(this.settings).waitFor(new String[] { gridName, columnName, rowNum });
/* 1232 */     return TempoGridCell.getInstance(this.settings).regexCapture(regex, group, new String[] { gridName, columnName, rowNum });
/*      */   }
/*      */ 
/*      */   public boolean verifyGridColumnRowContains(String gridName, String columnName, String rowNum, String[] fieldValues)
/*      */   {
/* 1253 */     TempoGridCell.getInstance(this.settings).waitFor(new String[] { gridName, columnName, rowNum });
/* 1254 */     return TempoGridCell.getInstance(this.settings).containsMultiple(fieldValues, new String[] { gridName, columnName, rowNum });
/*      */   }
/*      */ 
/*      */   public boolean verifyGridColumnRowContainsValue(String gridName, String columnName, String rowNum, String fieldValue)
/*      */   {
/* 1276 */     return verifyGridColumnRowContains(gridName, columnName, rowNum, new String[] { fieldValue });
/*      */   }
/*      */ 
/*      */   public void selectGridRow(String gridName, String rowNum)
/*      */   {
/* 1291 */     TempoGrid.getInstance(this.settings).waitFor(new String[] { gridName, rowNum });
/* 1292 */     TempoGridRow.getInstance(this.settings).click(new String[] { gridName, rowNum });
/*      */   }
/*      */ 
/*      */   public boolean verifyGridRowIsSelected(String gridName, String rowNum)
/*      */   {
/* 1307 */     TempoGrid.getInstance(this.settings).waitFor(new String[] { gridName, rowNum });
/* 1308 */     return TempoGridRow.getInstance(this.settings).contains(new String[] { gridName, rowNum });
/*      */   }
/*      */ 
/*      */   public Integer countGridRows(String gridName)
/*      */   {
/* 1322 */     TempoGrid.getInstance(this.settings).waitFor(new String[] { gridName });
/* 1323 */     return TempoGridRow.getInstance(this.settings).count(new String[] { gridName });
/*      */   }
/*      */ 
/*      */   public int getGridTotalCount(String gridName)
/*      */   {
/* 1339 */     TempoGrid.getInstance(this.settings).waitFor(new String[] { gridName });
/* 1340 */     return TempoGridTotalCount.getInstance(this.settings).capture(new String[] { gridName }).intValue();
/*      */   }
/*      */ 
/*      */   public int getGridRowCount(String gridName)
/*      */   {
/* 1356 */     TempoGrid.getInstance(this.settings).waitFor(new String[] { gridName });
/* 1357 */     return TempoGridRowCount.getInstance(this.settings).capture(new String[] { gridName }).intValue();
/*      */   }
/*      */ 
/*      */   public void clickOnGridAddRowLink(String gridName)
/*      */   {
/* 1369 */     TempoGrid.getInstance(this.settings).waitFor(new String[] { gridName });
/* 1370 */     TempoGridAddRow.getInstance(this.settings).click(new String[] { gridName });
/*      */   }
/*      */ 
/*      */   public void clickOnGridNavigation(String gridName, String navOption)
/*      */   {
/* 1387 */     TempoGrid.getInstance(this.settings).waitFor(new String[] { gridName });
/* 1388 */     TempoGridNavigation.getInstance(this.settings).click(new String[] { gridName, navOption });
/*      */   }
/*      */ 
/*      */   public void selectAllRowsInGrid(String gridName)
/*      */   {
/* 1401 */     TempoGridSelectAll.getInstance(this.settings).waitFor(new String[] { gridName });
/* 1402 */     TempoGridSelectAll.getInstance(this.settings).click(new String[] { gridName });
/*      */   }
/*      */ 
/*      */   public void sortGridByColumn(String gridName, String columnName)
/*      */   {
/* 1417 */     TempoGrid.getInstance(this.settings).waitFor(new String[] { gridName });
/* 1418 */     TempoGridColumn.getInstance(this.settings).click(new String[] { gridName, columnName });
/*      */   }
/*      */ 
/*      */   public void clickOnLink(String linkName)
/*      */   {
/* 1430 */     TempoLinkField.getInstance(this.settings).waitFor(new String[] { linkName });
/* 1431 */     TempoLinkField.getInstance(this.settings).click(new String[] { linkName });
/*      */   }
/*      */ 
/*      */   public boolean verifyLinkIsPresent(String linkName)
/*      */   {
/* 1445 */     TempoLinkField.getInstance(this.settings).waitFor(new String[] { linkName });
/* 1446 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyLinkURLContains(String linkName, String URLText)
/*      */   {
/* 1461 */     TempoLinkField.getInstance(this.settings).waitFor(new String[] { linkName });
/* 1462 */     return TempoLinkFieldUrl.getInstance(this.settings).contains(new String[] { linkName, URLText });
/*      */   }
/*      */ 
/*      */   public String getLinkURL(String linkName)
/*      */   {
/* 1477 */     return TempoLinkFieldUrl.getInstance(this.settings).capture(new String[] { linkName });
/*      */   }
/*      */ 
/*      */   public void clickOnButton(String buttonName)
/*      */   {
/* 1489 */     TempoButton.getInstance(this.settings).waitFor(new String[] { buttonName });
/* 1490 */     TempoButton.getInstance(this.settings).click(new String[] { buttonName });
/*      */   }
/*      */ 
/*      */   public boolean verifyButtonIsPresent(String buttonName)
/*      */   {
/* 1504 */     TempoButton.getInstance(this.settings).waitFor(new String[] { buttonName });
/* 1505 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyButtonIsNotPresent(String buttonName)
/*      */   {
/* 1522 */     return !TempoButton.getInstance(this.settings).waitForReturn(this.settings.getNotPresentTimeoutSeconds(), new String[] { buttonName });
/*      */   }
/*      */ 
/*      */   public void clickOnSaveChanges()
/*      */   {
/* 1531 */     TempoSaveChanges.getInstance(this.settings).waitFor(new String[0]);
/* 1532 */     TempoSaveChanges.getInstance(this.settings).click(new String[0]);
/*      */   }
/*      */ 
/*      */   public void clickOnMilestoneStep(String milestone, String step)
/*      */   {
/* 1546 */     TempoFieldFactory.getInstance(this.settings).waitFor(new String[] { "MILESTONE", milestone });
/* 1547 */     TempoMilestoneFieldStep.getInstance(this.settings).click(new String[] { milestone, step });
/*      */   }
/*      */ 
/*      */   public boolean verifyMilestoneStepIs(String milestone, String[] step)
/*      */   {
/* 1562 */     TempoFieldFactory.getInstance(this.settings).waitFor(new String[] { milestone });
/* 1563 */     TempoFieldFactory.getInstance(this.settings).containsMultiple(step, new String[] { milestone });
/* 1564 */     return true;
/*      */   }
/*      */ 
/*      */   public String getMilestoneStep(String milestone)
/*      */   {
/* 1577 */     TempoFieldFactory.getInstance(this.settings).waitFor(new String[] { milestone });
/* 1578 */     return TempoFieldFactory.getInstance(this.settings).capture(new String[] { milestone });
/*      */   }
/*      */ 
/*      */   public void clickOnRadioOption(String optionName)
/*      */   {
/* 1590 */     TempoRadioFieldOption.getInstance(this.settings).waitFor(new String[] { optionName });
/* 1591 */     TempoRadioFieldOption.getInstance(this.settings).click(new String[] { optionName });
/*      */   }
/*      */ 
/*      */   public void clickOnCheckboxOption(String optionName)
/*      */   {
/* 1604 */     TempoCheckboxFieldOption.getInstance(this.settings).waitFor(new String[] { optionName });
/* 1605 */     TempoCheckboxFieldOption.getInstance(this.settings).click(new String[] { optionName });
/*      */   }
/*      */ 
/*      */   public boolean verifySectionContainsValidationMessage(String sectionName, String[] validationMessages)
/*      */   {
/* 1620 */     TempoSectionValidation.getInstance(this.settings).waitForMultiple(validationMessages, new String[] { sectionName });
/* 1621 */     return true;
/*      */   }
/*      */ 
/*      */   public String getSectionValidationMessage(String sectionName)
/*      */   {
/* 1639 */     TempoSection.getInstance(this.settings).waitFor(new String[] { sectionName });
/* 1640 */     return TempoSectionValidation.getInstance(this.settings).capture(new String[] { sectionName });
/*      */   }
/*      */ 
/*      */   public boolean verifyChartIsPresent(String chartLabel)
/*      */   {
/* 1654 */     TempoChart.getInstance(this.settings).waitFor(new String[] { chartLabel });
/* 1655 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean verifyChartIsNotPresent(String chartLabel)
/*      */   {
/* 1671 */     return !TempoChart.getInstance(this.settings).waitForReturn(new String[] { chartLabel });
/*      */   }
/*      */ 
/*      */   public boolean errorIsPresent()
/*      */   {
/* 1680 */     return TempoError.getInstance(this.settings).waitForReturn(new String[0]);
/*      */   }
/*      */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.fixture.TempoFixture
 * JD-Core Version:    0.6.2
 */