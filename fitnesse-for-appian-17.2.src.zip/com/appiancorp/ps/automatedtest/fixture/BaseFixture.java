/*     */ package com.appiancorp.ps.automatedtest.fixture;
/*     */ 
/*     */ import com.appiancorp.ps.automatedtest.common.AppianObject;
/*     */ import com.appiancorp.ps.automatedtest.common.AppianWebApi;
/*     */ import com.appiancorp.ps.automatedtest.common.Screenshot;
/*     */ import com.appiancorp.ps.automatedtest.common.Settings;
/*     */ import com.appiancorp.ps.automatedtest.exception.ExceptionBuilder;
/*     */ import com.appiancorp.ps.automatedtest.tempo.TempoLogin;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.net.URL;
/*     */ import java.net.URLDecoder;
/*     */ import java.net.URLEncoder;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.io.Charsets;
/*     */ import org.apache.commons.io.FilenameUtils;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.apache.commons.lang3.RandomStringUtils;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.commons.lang3.time.DateUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.json.JSONArray;
/*     */ import org.openqa.selenium.JavascriptExecutor;
/*     */ import org.openqa.selenium.WebDriver;
/*     */ import org.openqa.selenium.WebDriver.Navigation;
/*     */ import org.openqa.selenium.WebDriver.TargetLocator;
/*     */ import org.openqa.selenium.chrome.ChromeDriver;
/*     */ import org.openqa.selenium.chrome.ChromeOptions;
/*     */ import org.openqa.selenium.firefox.FirefoxBinary;
/*     */ import org.openqa.selenium.firefox.FirefoxDriver;
/*     */ import org.openqa.selenium.firefox.FirefoxProfile;
/*     */ import org.openqa.selenium.ie.InternetExplorerDriver;
/*     */ import org.openqa.selenium.remote.DesiredCapabilities;
/*     */ 
/*     */ public class BaseFixture
/*     */ {
/*  56 */   private static final Logger LOG = Logger.getLogger(BaseFixture.class);
/*     */ 
/*  58 */   private Properties props = new Properties();
/*     */   protected Settings settings;
/*     */ 
/*     */   public BaseFixture()
/*     */   {
/*  64 */     this.settings = Settings.initialize();
/*  65 */     loadProperties();
/*     */   }
/*     */ 
/*     */   public void setWebDriver(WebDriver webDriver)
/*     */   {
/*  75 */     this.settings.setDriver(webDriver);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setupSeleniumWebDriverWithBrowser(String browser)
/*     */   {
/*  88 */     setupWithBrowser(browser);
/*     */   }
/*     */ 
/*     */   public void setupWithBrowser(String browser)
/*     */   {
/* 100 */     if (browser.equals("FIREFOX")) {
/* 101 */       FirefoxProfile prof = new FirefoxProfile();
/* 102 */       prof.setPreference("browser.startup.homepage_override.mstone", "ignore");
/* 103 */       prof.setPreference("startup.homepage_welcome_url.additional", "about:blank");
/* 104 */       if (!StringUtils.isBlank(this.props.getProperty("firefox.browser.home"))) {
/* 105 */         File pathToBinary = new File(this.props.getProperty("firefox.browser.home"));
/* 106 */         FirefoxBinary ffBinary = new FirefoxBinary(pathToBinary);
/* 107 */         this.settings.setDriver(new FirefoxDriver(ffBinary, prof));
/*     */       } else {
/* 109 */         this.settings.setDriver(new FirefoxDriver(prof));
/*     */       }
/* 111 */     } else if (browser.equals("CHROME"))
/*     */     {
/*     */       String driverHome;
/*     */       String driverHome;
/* 114 */       if (StringUtils.isNotBlank(this.props.getProperty("chrome.driver.home")))
/* 115 */         driverHome = this.props.getProperty("chrome.driver.home");
/*     */       else {
/* 117 */         driverHome = this.props.getProperty("automated.testing.home") + "/lib/drivers/" + "chromedriver.exe";
/*     */       }
/*     */ 
/* 121 */       System.setProperty("webdriver.chrome.driver", driverHome);
/*     */ 
/* 123 */       System.setProperty("webdriver.chrome.args", "--disable-logging");
/* 124 */       System.setProperty("webdriver.chrome.silentOutput", "true");
/*     */ 
/* 126 */       ChromeOptions co = new ChromeOptions();
/* 127 */       co.addArguments(new String[] { "--disable-extensions" });
/* 128 */       co.addArguments(new String[] { "no-sandbox" });
/* 129 */       if (StringUtils.isNotBlank(this.props.getProperty("chrome.browser.home"))) {
/* 130 */         co.setBinary(this.props.getProperty("chrome.browser.home"));
/* 131 */         co.addArguments(new String[] { "--disable-extensions" });
/* 132 */         co.addArguments(new String[] { "no-sandbox" });
/* 133 */         this.settings.setDriver(new ChromeDriver(co));
/*     */       } else {
/* 135 */         this.settings.setDriver(new ChromeDriver(co));
/*     */       }
/* 137 */     } else if (browser.equals("IE")) {
/* 138 */       System.setProperty("webdriver.ie.driver", this.props.getProperty("automated.testing.home") + "/lib/drivers/" + "IEDriverServer_32.exe");
/*     */ 
/* 140 */       System.setProperty("webdriver.ie.driver.silent", "true");
/* 141 */       DesiredCapabilities dCaps = new DesiredCapabilities();
/* 142 */       dCaps.setCapability("ie.ensureCleanSession", true);
/* 143 */       this.settings.setDriver(new InternetExplorerDriver(dCaps));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setAppianUrlTo(String url)
/*     */   {
/* 164 */     this.settings.setUrl(url);
/*     */   }
/*     */ 
/*     */   public void setAppianVersionTo(String version)
/*     */   {
/* 177 */     Settings.setVersion(version);
/*     */   }
/*     */ 
/*     */   public void setAppianLocaleTo(String locale)
/*     */   {
/* 190 */     this.settings.setLocale(locale);
/*     */   }
/*     */ 
/*     */   public void setStartDatetime()
/*     */   {
/* 199 */     this.settings.setStartDatetime(new Date());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setDataSourceNameTo(String dataSourceName)
/*     */   {
/* 210 */     this.settings.setDataSourceName(dataSourceName);
/*     */   }
/*     */ 
/*     */   public void setTimeoutSecondsTo(Integer ts)
/*     */   {
/* 221 */     this.settings.setTimeoutSeconds(ts.intValue());
/*     */   }
/*     */ 
/*     */   public void setScreenshotPathTo(String path)
/*     */   {
/* 232 */     this.settings.setScreenshotPath(path);
/*     */   }
/*     */ 
/*     */   public void setStopOnErrorTo(Boolean bool)
/*     */   {
/* 245 */     this.settings.setStopOnError(bool);
/*     */   }
/*     */ 
/*     */   public void setTakeErrorScreenshotsTo(Boolean bool)
/*     */   {
/* 258 */     if (this.settings.getScreenshotPath() == null) {
/* 259 */       this.settings.setScreenshotPath(this.props.getProperty("automated.testing.home") + "/screenshots");
/*     */     }
/* 261 */     this.settings.setTakeErrorScreenshots(bool);
/*     */   }
/*     */ 
/*     */   public void open(String url)
/*     */   {
/* 273 */     this.settings.getDriver().get(url);
/*     */   }
/*     */ 
/*     */   public void takeScreenshot(String fileName)
/*     */   {
/* 285 */     Screenshot.getInstance(this.settings).capture(new String[] { fileName });
/*     */   }
/*     */ 
/*     */   public void loginIntoWithUsernameAndPassword(String url, String userName, String password)
/*     */   {
/* 301 */     TempoLogin.getInstance(this.settings).navigateToLoginPage(url);
/* 302 */     TempoLogin.getInstance(this.settings).waitForLogin();
/* 303 */     TempoLogin.getInstance(this.settings).login(url, userName, password);
/*     */   }
/*     */ 
/*     */   public void loginWithUsernameAndPassword(String userName, String password)
/*     */   {
/* 318 */     loginIntoWithUsernameAndPassword(this.settings.getUrl(), userName, password);
/*     */   }
/*     */ 
/*     */   public void loginIntoWithUsername(String url, String username)
/*     */   {
/* 331 */     String password = this.props.getProperty(username);
/*     */ 
/* 333 */     loginIntoWithUsernameAndPassword(url, username, password);
/*     */   }
/*     */ 
/*     */   public void loginWithUsername(String username)
/*     */   {
/* 344 */     loginIntoWithUsername(this.settings.getUrl(), username);
/*     */   }
/*     */ 
/*     */   public void loginIntoWithRole(String url, String role)
/*     */   {
/* 357 */     String usernamePassword = this.props.getProperty(role);
/* 358 */     String username = StringUtils.substringBefore(usernamePassword, "|");
/* 359 */     String password = StringUtils.substringAfter(usernamePassword, "|");
/*     */ 
/* 361 */     loginIntoWithUsernameAndPassword(url, username, password);
/*     */   }
/*     */ 
/*     */   public void loginWithRole(String role)
/*     */   {
/* 372 */     loginIntoWithRole(this.settings.getUrl(), role);
/*     */   }
/*     */ 
/*     */   public void loginWithTermsWithUsernameAndPassword(String userName, String password)
/*     */   {
/* 387 */     TempoLogin.getInstance(this.settings).navigateToLoginPage(this.settings.getUrl());
/* 388 */     TempoLogin.getInstance(this.settings).waitForTerms();
/* 389 */     TempoLogin.getInstance(this.settings).loginWithTerms(this.settings.getUrl(), userName, password);
/*     */   }
/*     */ 
/*     */   public void loginWithTermsWithUsername(String userName)
/*     */   {
/* 401 */     TempoLogin.getInstance(this.settings).navigateToLoginPage(this.settings.getUrl());
/* 402 */     TempoLogin.getInstance(this.settings).waitForTerms();
/* 403 */     String password = getProps().getProperty(userName);
/* 404 */     TempoLogin.getInstance(this.settings).loginWithTerms(this.settings.getUrl(), userName, password);
/*     */   }
/*     */ 
/*     */   public void loginWithTermsWithRole(String role)
/*     */   {
/* 416 */     TempoLogin.getInstance(this.settings).navigateToLoginPage(this.settings.getUrl());
/* 417 */     TempoLogin.getInstance(this.settings).waitForTerms();
/* 418 */     String usernamePassword = this.props.getProperty(role);
/* 419 */     String username = StringUtils.substringBefore(usernamePassword, "|");
/* 420 */     String password = StringUtils.substringAfter(usernamePassword, "|");
/*     */ 
/* 422 */     TempoLogin.getInstance(this.settings).loginWithTerms(this.settings.getUrl(), username, password);
/*     */   }
/*     */ 
/*     */   public void waitFor(String period)
/*     */   {
/* 437 */     int periodNum = Integer.parseInt(period.replaceAll("[^0-9]", ""));
/* 438 */     int noOfSeconds = 0;
/* 439 */     if (period.contains("hour"))
/* 440 */       noOfSeconds = periodNum * 60 * 24;
/* 441 */     else if (period.contains("minute"))
/* 442 */       noOfSeconds = periodNum * 60;
/*     */     else {
/* 444 */       noOfSeconds = periodNum;
/*     */     }
/*     */     try
/*     */     {
/* 448 */       int i = 0;
/*     */ 
/* 450 */       while (i < noOfSeconds)
/*     */       {
/* 454 */         Thread.sleep(1000L);
/* 455 */         i++;
/*     */       }
/*     */     }
/*     */     catch (InterruptedException e) {
/* 459 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait Until" });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void waitForSeconds(Integer period)
/*     */   {
/* 472 */     waitFor(period + " seconds");
/*     */   }
/*     */ 
/*     */   public void waitForMinutes(Integer period)
/*     */   {
/* 484 */     waitFor(period + " minutes");
/*     */   }
/*     */ 
/*     */   public void waitForHours(Integer period)
/*     */   {
/* 496 */     waitFor(period + " hours");
/*     */   }
/*     */ 
/*     */   public void waitForWorking()
/*     */   {
/* 505 */     AppianObject.getInstance(this.settings).waitForWorking();
/*     */   }
/*     */ 
/*     */   public void waitUntil(String datetime)
/*     */   {
/* 518 */     datetime = AppianObject.getInstance(this.settings).formatDatetimeCalculation(datetime);
/*     */     try
/*     */     {
/* 521 */       Date endDatetime = DateUtils.parseDate(datetime, new String[] { this.settings.getDatetimeDisplayFormat() });
/* 522 */       Date nowDatetime = new Date();
/*     */ 
/* 524 */       while (endDatetime.after(nowDatetime)) {
/* 525 */         Thread.sleep(1000L);
/* 526 */         nowDatetime = new Date();
/*     */       }
/*     */     } catch (Exception e) {
/* 529 */       throw ExceptionBuilder.build(e, this.settings, new String[] { "Wait Until" });
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getWebApiWithUsername(String webApiEndpoint, String username)
/*     */   {
/* 546 */     String password = this.props.getProperty(username);
/* 547 */     return AppianWebApi.getInstance(this.settings).callWebApi(webApiEndpoint, "", username, password);
/*     */   }
/*     */ 
/*     */   public String getWebApiWithRole(String webApiEndpoint, String role)
/*     */   {
/* 563 */     String usernamePassword = this.props.getProperty(role);
/* 564 */     String username = StringUtils.substringBefore(usernamePassword, "|");
/* 565 */     String password = StringUtils.substringAfter(usernamePassword, "|");
/*     */ 
/* 567 */     return AppianWebApi.getInstance(this.settings).callWebApi(webApiEndpoint, "", username, password);
/*     */   }
/*     */ 
/*     */   public String postWebApiWithBodyWithUsername(String webApiEndpoint, String body, String username)
/*     */   {
/* 585 */     String password = this.props.getProperty(username);
/* 586 */     return AppianWebApi.getInstance(this.settings).callWebApi(webApiEndpoint, body, username, password);
/*     */   }
/*     */ 
/*     */   public String postWebApiWithBodyWithRole(String webApiEndpoint, String body, String role)
/*     */   {
/* 604 */     String usernamePassword = this.props.getProperty(role);
/* 605 */     String username = StringUtils.substringBefore(usernamePassword, "|");
/* 606 */     String password = StringUtils.substringAfter(usernamePassword, "|");
/*     */ 
/* 608 */     return AppianWebApi.getInstance(this.settings).callWebApi(webApiEndpoint, body, username, password);
/*     */   }
/*     */ 
/*     */   public void setTestVariableWith(String key, String val)
/*     */   {
/* 622 */     this.settings.setTestVariableWith(key, val);
/*     */   }
/*     */ 
/*     */   public String getTestVariable(String variableName)
/*     */   {
/* 635 */     return this.settings.getTestVariable(variableName.replace("tv!", ""));
/*     */   }
/*     */ 
/*     */   public void refresh()
/*     */   {
/* 644 */     this.settings.getDriver().navigate().refresh();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean startProcessWithProcessModelUuId(String processModelUuid) {
/*     */     try {
/* 650 */       this.settings.getDriver().get(this.settings
/* 651 */         .getUrl() + "/suite/plugins/servlet/appianautomatedtest?operation=startProcessWithPMUuId&pmUuid=" + 
/* 652 */         URLEncoder.encode(processModelUuid, "UTF-8"));
/*     */ 
/* 653 */       String pageSource = this.settings.getDriver().getPageSource();
/* 654 */       if (pageSource.contains("Exceptions occur")) {
/* 655 */         return false;
/*     */       }
/* 657 */       LOG.debug("PROCESS ID: " + pageSource);
/* 658 */       return true;
/*     */     }
/*     */     catch (Exception e) {
/* 661 */       e.printStackTrace();
/*     */     }
/* 663 */     return false;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean waitUntilTaskOfProcessModelUuidStartedRecentlyIsCompleted(String taskName, String pmUuid) {
/* 668 */     WebDriver driver = this.settings.getDriver();
/*     */ 
/* 670 */     boolean completed = false;
/*     */     try
/*     */     {
/* 673 */       int i = 0;
/* 674 */       String seconds = "120";
/* 675 */       while (!completed) {
/* 676 */         if (i > 120) {
/* 677 */           return false;
/*     */         }
/*     */ 
/* 680 */         Thread.sleep(5000L);
/*     */ 
/* 682 */         Set windows = this.settings.getDriver().getWindowHandles();
/* 683 */         String mainHandle = this.settings.getDriver().getWindowHandle();
/*     */ 
/* 685 */         ((JavascriptExecutor)driver).executeScript("window.open();", new Object[0]);
/*     */ 
/* 687 */         Set completeWindow = driver.getWindowHandles();
/* 688 */         completeWindow.removeAll(windows);
/* 689 */         String completeHandle = (String)completeWindow.toArray()[0];
/*     */ 
/* 691 */         driver.switchTo().window(completeHandle);
/* 692 */         driver.get(this.settings.getUrl() + "/suite/plugins/servlet/appianautomatedtest?operation=queryIsTaskCompletedWithinSeconds&pmUuid=" + 
/* 693 */           URLEncoder.encode(pmUuid, "UTF-8") + 
/* 693 */           "&taskName=" + URLEncoder.encode(taskName, "UTF-8") + "&seconds=" + 
/* 694 */           URLEncoder.encode(seconds, "UTF-8"));
/*     */ 
/* 696 */         String pageSource = driver.getPageSource();
/* 697 */         driver.close();
/* 698 */         driver.switchTo().window(mainHandle);
/*     */ 
/* 700 */         if (pageSource.contains("Task is completed")) {
/* 701 */           completed = true;
/*     */         }
/*     */ 
/* 704 */         i++;
/*     */       }
/*     */     } catch (Exception e) {
/* 707 */       e.printStackTrace();
/* 708 */       return false;
/*     */     }
/*     */ 
/* 711 */     return completed;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean verifyDataInDatabaseWithQueryAndFields(String sqlQuery, String fields) {
/* 716 */     WebDriver driver = this.settings.getDriver();
/*     */     try
/*     */     {
/* 719 */       Set windows = driver.getWindowHandles();
/* 720 */       String mainHandle = driver.getWindowHandle();
/*     */ 
/* 722 */       ((JavascriptExecutor)driver).executeScript("window.open();", new Object[0]);
/*     */ 
/* 724 */       Set verifyWindow = driver.getWindowHandles();
/* 725 */       verifyWindow.removeAll(windows);
/* 726 */       String verifyHandle = (String)verifyWindow.toArray()[0];
/*     */ 
/* 728 */       driver.switchTo().window(verifyHandle);
/* 729 */       driver.get(this.settings.getUrl() + "/suite/plugins/servlet/appianautomatedtest?operation=verifyDataInDataBase&dataSource=" + 
/* 730 */         URLEncoder.encode(this.settings
/* 730 */         .getDataSourceName(), "UTF-8") + "&sqlQuery=" + URLEncoder.encode(sqlQuery, "UTF-8") + "&fields=" + 
/* 731 */         URLEncoder.encode(fields, "UTF-8"));
/*     */ 
/* 733 */       String pageSource = driver.getPageSource();
/* 734 */       String jsonSource = pageSource.substring(pageSource.indexOf("["), pageSource.indexOf("]") + 1);
/*     */ 
/* 736 */       driver.close();
/* 737 */       driver.switchTo().window(mainHandle);
/*     */ 
/* 739 */       JSONArray resultArr = new JSONArray(jsonSource);
/*     */ 
/* 741 */       return resultArr.length() > 0;
/*     */     } catch (Exception e) {
/* 743 */       e.printStackTrace();
/*     */     }
/* 745 */     return false;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean verifyConstantHasValueOf(String constantName, String expectedConstantValue) {
/* 750 */     WebDriver driver = this.settings.getDriver();
/*     */     try
/*     */     {
/* 753 */       Set windows = driver.getWindowHandles();
/* 754 */       String mainHandle = driver.getWindowHandle();
/*     */ 
/* 756 */       ((JavascriptExecutor)driver).executeScript("window.open();", new Object[0]);
/*     */ 
/* 758 */       Set verifyWindow = driver.getWindowHandles();
/* 759 */       verifyWindow.removeAll(windows);
/* 760 */       String verifyHandle = (String)verifyWindow.toArray()[0];
/*     */ 
/* 762 */       driver.switchTo().window(verifyHandle);
/* 763 */       driver.get(this.settings.getUrl() + "/suite/plugins/servlet/appianautomatedtest?operation=verifyConstantHasValueOf&constantName=" + 
/* 764 */         URLEncoder.encode(constantName, "UTF-8") + 
/* 764 */         "&expectedConstantValue=" + URLEncoder.encode(expectedConstantValue, "UTF-8"));
/*     */ 
/* 766 */       String pageSource = driver.getPageSource();
/* 767 */       driver.close();
/* 768 */       driver.switchTo().window(mainHandle);
/*     */ 
/* 770 */       return pageSource.contains("Constant value is verified");
/*     */     } catch (Exception e) {
/* 772 */       e.printStackTrace();
/*     */     }
/* 774 */     return false;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void tearDownSeleniumWebDriver()
/*     */   {
/* 784 */     tearDown();
/*     */   }
/*     */ 
/*     */   public void tearDown()
/*     */   {
/* 793 */     this.settings.getDriver().quit();
/*     */   }
/*     */ 
/*     */   public String getRandomString(int length)
/*     */   {
/* 807 */     return RandomStringUtils.randomAlphanumeric(length);
/*     */   }
/*     */ 
/*     */   public String getRandomAlphabetString(int length)
/*     */   {
/* 822 */     return RandomStringUtils.randomAlphabetic(length);
/*     */   }
/*     */ 
/*     */   public int getRandomIntegerFromTo(int min, int max)
/*     */   {
/* 838 */     if (min > max) {
/* 839 */       throw ExceptionBuilder.build(new IllegalArgumentException("Min cannot exceed the Max"), this.settings, new String[] { "Get Random Int" });
/*     */     }
/* 841 */     Random random = new Random();
/* 842 */     long range = max - min;
/* 843 */     long fraction = ()(range * random.nextDouble());
/* 844 */     return (int)(fraction + min);
/*     */   }
/*     */ 
/*     */   public double getRandomDecimalFromTo(double min, double max)
/*     */   {
/* 860 */     if (min > max) {
/* 861 */       throw ExceptionBuilder.build(new IllegalArgumentException("Min cannot exceed the Max"), this.settings, new String[] { "Get Random Decimal" });
/*     */     }
/* 863 */     Random random = new Random();
/* 864 */     double range = max - min;
/* 865 */     double fraction = range * random.nextDouble();
/* 866 */     return fraction + min;
/*     */   }
/*     */ 
/*     */   public double getRandomDecimalFromToWith(double min, double max, int decimalPlaces)
/*     */   {
/* 884 */     if (min > max) {
/* 885 */       throw ExceptionBuilder.build(new IllegalArgumentException("Min cannot exceed the Max"), this.settings, new String[] { "Get Random Decimal" });
/*     */     }
/* 887 */     Random random = new Random();
/* 888 */     double range = max - min;
/* 889 */     double fraction = range * random.nextDouble();
/* 890 */     BigDecimal total = new BigDecimal(fraction + min);
/* 891 */     BigDecimal trimmed = total.setScale(decimalPlaces, RoundingMode.HALF_DOWN);
/* 892 */     return trimmed.doubleValue();
/*     */   }
/*     */ 
/*     */   public Settings getSettings() {
/* 896 */     return this.settings;
/*     */   }
/*     */ 
/*     */   private void loadProperties()
/*     */   {
/* 901 */     InputStream inputStream = null;
/*     */     try
/*     */     {
/* 905 */       List files = IOUtils.readLines(BaseFixture.class.getClassLoader()
/* 906 */         .getResourceAsStream("configs/"), 
/* 906 */         Charsets.UTF_8);
/* 907 */       for (String file : files) {
/* 908 */         inputStream = BaseFixture.class.getClassLoader().getResourceAsStream("configs/" + file);
/* 909 */         this.props.load(inputStream);
/*     */       }
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*     */     }
/*     */     try {
/* 916 */       if (inputStream == null) {
/* 917 */         File jarPath = new File(BaseFixture.class.getProtectionDomain().getCodeSource().getLocation().getPath());
/* 918 */         String propertiesPath = jarPath.getParentFile().getAbsolutePath();
/* 919 */         File folder = new File(URLDecoder.decode(propertiesPath + "/../../configs", "UTF-8"));
/*     */ 
/* 921 */         for (File file : folder.listFiles())
/* 922 */           if (FilenameUtils.getExtension(file.getPath()).equals("properties")) {
/* 923 */             inputStream = new FileInputStream(file.getAbsolutePath());
/* 924 */             this.props.load(inputStream);
/*     */           }
/*     */       }
/*     */     }
/*     */     catch (Exception localException1) {
/*     */     }
/*     */   }
/*     */ 
/*     */   public Properties getProps() {
/* 933 */     return this.props;
/*     */   }
/*     */ 
/*     */   public void setProp(Properties prop) {
/* 937 */     this.props = prop;
/*     */   }
/*     */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.fixture.BaseFixture
 * JD-Core Version:    0.6.2
 */