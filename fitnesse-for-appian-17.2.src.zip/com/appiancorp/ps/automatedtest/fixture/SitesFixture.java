/*    */ package com.appiancorp.ps.automatedtest.fixture;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import com.appiancorp.ps.automatedtest.common.Version;
/*    */ import com.appiancorp.ps.automatedtest.site.Site;
/*    */ import com.appiancorp.ps.automatedtest.site.SitePage;
/*    */ 
/*    */ public class SitesFixture extends TempoFixture
/*    */ {
/*    */   public void navigateToSite(String siteUrl)
/*    */   {
/* 23 */     Site.getInstance(this.settings).navigateTo(new String[] { siteUrl });
/*    */   }
/*    */ 
/*    */   public void navigateToSitePage(String siteUrl, String pageUrl)
/*    */   {
/* 37 */     SitePage.getInstance(this.settings).navigateTo(new String[] { siteUrl, pageUrl });
/*    */   }
/*    */ 
/*    */   public void clickOnSitePage(String sitePage)
/*    */   {
/* 49 */     SitePage.getInstance(this.settings).waitFor(new String[] { sitePage });
/* 50 */     SitePage.getInstance(this.settings).click(new String[] { sitePage });
/*    */   }
/*    */ 
/*    */   public void logout()
/*    */   {
/* 59 */     if (Settings.getVersion().compareTo(new Version(Integer.valueOf(17), Integer.valueOf(1))) < 0)
/* 60 */       super.logout();
/*    */     else
/* 62 */       SitePage.getInstance(this.settings).logout();
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.fixture.SitesFixture
 * JD-Core Version:    0.6.2
 */