package com.appiancorp.ps.automatedtest.properties;

import org.openqa.selenium.WebElement;

public abstract interface FieldLayoutCaptureable
{
  public abstract String capture(WebElement paramWebElement, String[] paramArrayOfString);
}

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.properties.FieldLayoutCaptureable
 * JD-Core Version:    0.6.2
 */