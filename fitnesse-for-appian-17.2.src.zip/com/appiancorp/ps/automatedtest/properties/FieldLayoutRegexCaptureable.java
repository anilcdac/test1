package com.appiancorp.ps.automatedtest.properties;

import org.openqa.selenium.WebElement;

public abstract interface FieldLayoutRegexCaptureable
{
  public abstract String regexCapture(WebElement paramWebElement, String paramString, Integer paramInteger, String[] paramArrayOfString)
    throws Exception;
}

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.properties.FieldLayoutRegexCaptureable
 * JD-Core Version:    0.6.2
 */