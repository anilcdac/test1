package com.appiancorp.ps.automatedtest.properties;

public abstract interface PopulateableMultiple
{
  public abstract void populateMultiple(String[] paramArrayOfString1, String[] paramArrayOfString2);
}

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.properties.PopulateableMultiple
 * JD-Core Version:    0.6.2
 */