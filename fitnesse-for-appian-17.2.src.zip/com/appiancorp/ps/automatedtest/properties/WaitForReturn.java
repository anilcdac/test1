package com.appiancorp.ps.automatedtest.properties;

public abstract interface WaitForReturn extends WaitFor
{
  public abstract boolean waitForReturn(int paramInt, String[] paramArrayOfString);

  public abstract boolean waitForReturn(String[] paramArrayOfString);
}

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.properties.WaitForReturn
 * JD-Core Version:    0.6.2
 */