package com.appiancorp.ps.automatedtest.properties;

public abstract interface WaitFor
{
  public abstract void waitFor(String[] paramArrayOfString);

  public abstract String getXpath(String[] paramArrayOfString);
}

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.properties.WaitFor
 * JD-Core Version:    0.6.2
 */