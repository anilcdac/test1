package com.appiancorp.ps.automatedtest.properties;

public abstract interface VerifiableMultiple
{
  public abstract boolean containsMultiple(String[] paramArrayOfString1, String[] paramArrayOfString2);
}

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.properties.VerifiableMultiple
 * JD-Core Version:    0.6.2
 */