package com.appiancorp.ps.automatedtest.properties;

import org.openqa.selenium.WebElement;

public abstract interface FieldLayoutWaitForReturn extends FieldLayoutWaitFor
{
  public abstract boolean waitForReturn(int paramInt, WebElement paramWebElement, String[] paramArrayOfString);

  public abstract boolean waitForReturn(WebElement paramWebElement, String[] paramArrayOfString);
}

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.properties.FieldLayoutWaitForReturn
 * JD-Core Version:    0.6.2
 */