package com.appiancorp.ps.automatedtest.properties;

import org.openqa.selenium.WebElement;

public abstract interface FieldLayoutVerifiable
{
  public abstract boolean contains(WebElement paramWebElement, String[] paramArrayOfString)
    throws Exception;
}

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.properties.FieldLayoutVerifiable
 * JD-Core Version:    0.6.2
 */