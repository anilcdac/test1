package com.appiancorp.ps.automatedtest.properties;

public abstract interface Clearable
{
  public abstract void clear(String[] paramArrayOfString);
}

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.properties.Clearable
 * JD-Core Version:    0.6.2
 */