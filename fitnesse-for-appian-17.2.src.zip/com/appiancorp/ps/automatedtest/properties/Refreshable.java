package com.appiancorp.ps.automatedtest.properties;

public abstract interface Refreshable extends WaitForReturn
{
  public abstract void refreshAndWaitFor(String[] paramArrayOfString);
}

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.properties.Refreshable
 * JD-Core Version:    0.6.2
 */