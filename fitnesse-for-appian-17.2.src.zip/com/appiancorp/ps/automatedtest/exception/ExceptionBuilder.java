/*    */ package com.appiancorp.ps.automatedtest.exception;
/*    */ 
/*    */ import com.appiancorp.ps.automatedtest.common.Screenshot;
/*    */ import com.appiancorp.ps.automatedtest.common.Settings;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class ExceptionBuilder
/*    */ {
/*  9 */   private static final Logger LOG = Logger.getLogger(ExceptionBuilder.class);
/*    */ 
/*    */   public static RuntimeException build(Exception e, Settings s, String[] vals) {
/* 12 */     LOG.error(String.join(" - ", vals), e);
/*    */     try
/*    */     {
/* 15 */       if (s.isTakeErrorScreenshots().booleanValue()) {
/* 16 */         Screenshot.getInstance(s).capture(new String[] { String.format("%3d", new Object[] { Integer.valueOf(s.getErrorNumber()) }) });
/* 17 */         s.setErrorNumber(s.getErrorNumber() + 1);
/*    */       }
/*    */     } catch (Exception ) {
/* 20 */       LOG.error("Screenshot error", e);
/*    */     }
/*    */ 
/* 23 */     switch (e.getClass().getCanonicalName()) {
/*    */     case "org.openqa.selenium.NoSuchElementException":
/* 25 */       if (s.isStopOnError().booleanValue()) {
/* 26 */         return new ObjectNotFoundStopTestException(vals);
/*    */       }
/* 28 */       return new ObjectNotFoundTestException(vals);
/*    */     case "org.openqa.selenium.TimeoutException":
/* 32 */       if (s.isStopOnError().booleanValue()) {
/* 33 */         return new TimeoutStopTestException(vals);
/*    */       }
/* 35 */       return new TimeoutTestException(vals);
/*    */     case "org.openqa.selenium.StaleElementReferenceException":
/* 39 */       if (s.isStopOnError().booleanValue()) {
/* 40 */         return new StaleElementStopTestException(vals);
/*    */       }
/* 42 */       return new StaleElementTestException(vals);
/*    */     case "java.lang.IllegalArgumentException":
/* 46 */       if (s.isStopOnError().booleanValue()) {
/* 47 */         return new IllegalArgumentStopTestException(vals);
/*    */       }
/* 49 */       return new IllegalArgumentTestException(vals);
/*    */     case "org.openqa.selenium.remote.UnreachableBrowserException":
/* 53 */       if (s.isStopOnError().booleanValue()) {
/* 54 */         return new UnreachableBrowserStopTestException(vals);
/*    */       }
/* 56 */       return new UnreachableBrowserTestException(vals);
/*    */     case "com.appiancorp.ps.automatedtest.exception.WaitForWorkingTestException":
/* 60 */       if (s.isStopOnError().booleanValue()) {
/* 61 */         return new WaitForWorkingStopTestException(vals);
/*    */       }
/* 63 */       return new WaitForWorkingTestException(vals);
/*    */     }
/*    */ 
/* 67 */     if (s.isStopOnError().booleanValue()) {
/* 68 */       return new GenericStopTestException(vals);
/*    */     }
/* 70 */     e.printStackTrace();
/* 71 */     return new GenericTestException(vals);
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.exception.ExceptionBuilder
 * JD-Core Version:    0.6.2
 */