/*    */ package com.appiancorp.ps.automatedtest.exception;
/*    */ 
/*    */ public class WaitForWorkingTestException extends RuntimeException
/*    */ {
/*    */   public WaitForWorkingTestException(RuntimeException e)
/*    */   {
/*  7 */     super(e);
/*    */   }
/*    */ 
/*    */   public WaitForWorkingTestException(String[] vals) {
/* 11 */     super("message:<<Working... remained for longer than timeout period, investigate performance and test timeout parameter.>>");
/*    */   }
/*    */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.exception.WaitForWorkingTestException
 * JD-Core Version:    0.6.2
 */