/*   */ package com.appiancorp.ps.automatedtest.exception;
/*   */ 
/*   */ public class GenericTestException extends RuntimeException
/*   */ {
/*   */   public GenericTestException(String[] vals)
/*   */   {
/* 7 */     super("message:<<An error has occurred: " + String.join(" - ", vals) + ">>");
/*   */   }
/*   */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.exception.GenericTestException
 * JD-Core Version:    0.6.2
 */