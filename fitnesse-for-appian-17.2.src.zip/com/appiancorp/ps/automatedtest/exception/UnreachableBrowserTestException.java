/*   */ package com.appiancorp.ps.automatedtest.exception;
/*   */ 
/*   */ public class UnreachableBrowserTestException extends RuntimeException
/*   */ {
/*   */   public UnreachableBrowserTestException(String[] vals)
/*   */   {
/* 7 */     super("message:<<Browser is unreachable, please restart test>>");
/*   */   }
/*   */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.exception.UnreachableBrowserTestException
 * JD-Core Version:    0.6.2
 */