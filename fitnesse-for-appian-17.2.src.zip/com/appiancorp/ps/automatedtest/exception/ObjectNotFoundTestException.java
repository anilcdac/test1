/*   */ package com.appiancorp.ps.automatedtest.exception;
/*   */ 
/*   */ public class ObjectNotFoundTestException extends RuntimeException
/*   */ {
/*   */   public ObjectNotFoundTestException(String[] vals)
/*   */   {
/* 7 */     super("message:<<Object not found: " + String.join(" - ", vals) + ">>");
/*   */   }
/*   */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.exception.ObjectNotFoundTestException
 * JD-Core Version:    0.6.2
 */