/*   */ package com.appiancorp.ps.automatedtest.exception;
/*   */ 
/*   */ public class IllegalArgumentTestException extends RuntimeException
/*   */ {
/*   */   public IllegalArgumentTestException(String[] vals)
/*   */   {
/* 7 */     super("message:<<Invalid argument: " + String.join(" - ", vals) + ">>");
/*   */   }
/*   */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.exception.IllegalArgumentTestException
 * JD-Core Version:    0.6.2
 */