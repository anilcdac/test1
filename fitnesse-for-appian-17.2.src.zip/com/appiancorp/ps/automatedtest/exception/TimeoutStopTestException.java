/*   */ package com.appiancorp.ps.automatedtest.exception;
/*   */ 
/*   */ public class TimeoutStopTestException extends ObjectNotFoundTestException
/*   */ {
/*   */   public TimeoutStopTestException(String[] vals)
/*   */   {
/* 7 */     super(vals);
/*   */   }
/*   */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.exception.TimeoutStopTestException
 * JD-Core Version:    0.6.2
 */