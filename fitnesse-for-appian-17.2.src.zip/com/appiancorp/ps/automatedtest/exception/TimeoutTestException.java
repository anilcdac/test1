/*   */ package com.appiancorp.ps.automatedtest.exception;
/*   */ 
/*   */ public class TimeoutTestException extends RuntimeException
/*   */ {
/*   */   public TimeoutTestException(String[] vals)
/*   */   {
/* 7 */     super("message:<<Timeout period reached: " + String.join(" - ", vals) + ">>");
/*   */   }
/*   */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.exception.TimeoutTestException
 * JD-Core Version:    0.6.2
 */