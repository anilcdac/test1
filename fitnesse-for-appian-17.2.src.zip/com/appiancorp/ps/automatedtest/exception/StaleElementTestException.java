/*   */ package com.appiancorp.ps.automatedtest.exception;
/*   */ 
/*   */ public class StaleElementTestException extends RuntimeException
/*   */ {
/*   */   public StaleElementTestException(String[] vals)
/*   */   {
/* 7 */     super("message:<<Element is no longer attached to the DOM: " + String.join(" - ", vals) + ">>");
/*   */   }
/*   */ }

/* Location:           /Users/Anilkumar/Desktop/fitnesse-for-appian-17.2.jar
 * Qualified Name:     com.appiancorp.ps.automatedtest.exception.StaleElementTestException
 * JD-Core Version:    0.6.2
 */